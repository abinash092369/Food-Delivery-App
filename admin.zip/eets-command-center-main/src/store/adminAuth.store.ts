import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { AdminRole, AdminUser } from "@/types/admin";

type Page =
  | "dashboard" | "users" | "orders" | "restaurants" | "delivery"
  | "analytics" | "coupons" | "fraud" | "settings";

interface AdminAuthState {
  user: AdminUser | null;
  token: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  hasRole: (...roles: AdminRole[]) => boolean;
  can: (page: Page) => boolean;
}

const DEMO: Record<string, AdminUser> = {
  super: { id: "a1", name: "Sara Admin", email: "super@eets.app", role: "SUPER_ADMIN", avatar: "https://i.pravatar.cc/80?u=super" },
  admin: { id: "a2", name: "Alex Admin", email: "admin@eets.app", role: "ADMIN", avatar: "https://i.pravatar.cc/80?u=admin" },
  support: { id: "a3", name: "Sam Support", email: "support@eets.app", role: "SUPPORT", avatar: "https://i.pravatar.cc/80?u=support" },
};

const ACCESS: Record<AdminRole, Set<Page>> = {
  SUPER_ADMIN: new Set<Page>(["dashboard", "users", "orders", "restaurants", "delivery", "analytics", "coupons", "fraud", "settings"]),
  ADMIN: new Set<Page>(["dashboard", "users", "orders", "restaurants", "delivery", "analytics", "coupons"]),
  SUPPORT: new Set<Page>(["users", "orders"]),
};

export const useAdminAuth = create<AdminAuthState>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      login: async (email, _password) => {
        await new Promise((r) => setTimeout(r, 400));
        const key = email.startsWith("admin")
          ? "admin"
          : email.startsWith("support")
          ? "support"
          : "super";
        const user = { ...DEMO[key], email };
        set({ user, token: `demo.${user.role}.token` });
      },
      logout: () => set({ user: null, token: null }),
      hasRole: (...roles) => {
        const u = get().user;
        return !!u && roles.includes(u.role);
      },
      can: (page) => {
        const u = get().user;
        if (!u) return false;
        return ACCESS[u.role].has(page);
      },
    }),
    { name: "eets-admin-auth" },
  ),
);