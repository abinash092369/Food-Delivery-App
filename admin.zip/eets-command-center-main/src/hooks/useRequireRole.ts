import { useAdminAuth } from "@/store/adminAuth.store";
import { useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import type { AdminRole } from "@/types/admin";

export function useRequireRole(...roles: AdminRole[]) {
  const user = useAdminAuth((s) => s.user);
  const navigate = useNavigate();
  useEffect(() => {
    if (!user) { navigate({ to: "/admin/login" }); return; }
    if (roles.length && !roles.includes(user.role)) {
      navigate({ to: "/admin/dashboard" });
    }
  }, [user, navigate, roles]);
}

export function useCan(page: Parameters<ReturnType<typeof useAdminAuth.getState>["can"]>[0]) {
  return useAdminAuth((s) => s.can(page));
}
