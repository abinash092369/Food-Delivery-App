import type {
  PlatformUser,
  AdminRestaurant,
  AdminOrder,
  DeliveryPartner,
  Coupon,
  FraudAlert,
  OrderStatus,
} from "@/types/admin";

const rand = (min: number, max: number) =>
  Math.floor(Math.random() * (max - min + 1)) + min;

const NAMES = ["Aarav", "Vihaan", "Aditya", "Vivaan", "Arjun", "Sai", "Krishna", "Ishaan", "Aanya", "Diya", "Saanvi", "Aadhya", "Myra", "Anika", "Riya", "Ananya"];
const SURNAMES = ["Sharma", "Verma", "Patel", "Reddy", "Iyer", "Khan", "Singh", "Nair", "Bose", "Gupta", "Kapoor", "Mehta"];
const CITIES = ["Bangalore", "Mumbai", "Delhi", "Hyderabad", "Pune", "Chennai"];
const RESTAURANTS = [
  "Spice Orchid", "Tokyo Bowl", "Napoli Pizzeria", "Green Leaf Kitchen", "Burger Bros", "Dragon Wok",
  "Curry Leaf", "Pasta Cartel", "Sushi Garden", "Taco Republic", "Pita Pocket", "Bombay Brasserie",
];
const CUISINES = ["North Indian", "Italian", "Chinese", "Japanese", "Mexican", "Continental", "South Indian"];

const fullName = () =>
  `${NAMES[rand(0, NAMES.length - 1)]} ${SURNAMES[rand(0, SURNAMES.length - 1)]}`;

const isoDaysAgo = (d: number) =>
  new Date(Date.now() - d * 86400000).toISOString();

export const mockUsers: PlatformUser[] = Array.from({ length: 48 }, (_, i) => {
  const name = fullName();
  return {
    id: `u${1000 + i}`,
    name,
    email: `${name.toLowerCase().replace(" ", ".")}@mail.com`,
    phone: `+91 9${rand(100000000, 999999999)}`,
    avatar: `https://i.pravatar.cc/80?u=${i}`,
    orders: rand(0, 80),
    joinedAt: isoDaysAgo(rand(1, 400)),
    status: i % 17 === 0 ? "banned" : i % 11 === 0 ? "unverified" : "active",
    totalSpend: rand(0, 50000),
    city: CITIES[rand(0, CITIES.length - 1)],
  };
});

export const mockRestaurants: AdminRestaurant[] = Array.from({ length: 24 }, (_, i) => {
  const name = RESTAURANTS[i % RESTAURANTS.length] + (i >= RESTAURANTS.length ? ` ${i}` : "");
  return {
    id: `r${100 + i}`,
    name,
    logo: `https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=120&q=80&u=${i}`,
    owner: fullName(),
    ownerEmail: `owner${i}@biz.com`,
    cuisine: CUISINES[rand(0, CUISINES.length - 1)],
    city: CITIES[rand(0, CITIES.length - 1)],
    address: `${rand(10, 999)} ${["MG Road", "Brigade Rd", "Park St", "Linking Rd"][rand(0, 3)]}`,
    rating: +(3.5 + Math.random() * 1.5).toFixed(1),
    orders: rand(50, 5000),
    revenue: rand(50000, 2000000),
    status: i < 6 ? "pending" : i % 13 === 0 ? "suspended" : "active",
    submittedAt: isoDaysAgo(rand(1, 60)),
  };
});

const STATUSES: OrderStatus[] = ["pending", "preparing", "on_the_way", "delivered", "cancelled"];

export const mockOrders: AdminOrder[] = Array.from({ length: 120 }, (_, i) => {
  const itemsCount = rand(1, 4);
  const items = Array.from({ length: itemsCount }, () => ({
    name: ["Biryani", "Pizza", "Burger", "Sushi", "Pasta", "Noodles", "Curry"][rand(0, 6)],
    qty: rand(1, 3),
    price: rand(100, 600),
  }));
  const amount = items.reduce((s, x) => s + x.price * x.qty, 0);
  const rest = mockRestaurants[rand(0, mockRestaurants.length - 1)];
  const user = mockUsers[rand(0, mockUsers.length - 1)];
  const status = STATUSES[i < 8 ? 0 : i < 16 ? 1 : i < 24 ? 2 : i % 7 === 0 ? 4 : 3];
  const createdAt = new Date(Date.now() - rand(0, 30) * 86400000 - rand(0, 86400000)).toISOString();
  return {
    id: `ORD${10000 + i}`,
    customerId: user.id,
    customerName: user.name,
    restaurantId: rest.id,
    restaurantName: rest.name,
    items,
    amount,
    status,
    paymentMethod: (["card", "upi", "cod", "wallet"] as const)[rand(0, 3)],
    address: `${rand(10, 999)} ${user.city}`,
    createdAt,
    deliveredAt: status === "delivered" ? new Date(new Date(createdAt).getTime() + rand(20, 60) * 60000).toISOString() : undefined,
  };
});

export const mockDelivery: DeliveryPartner[] = Array.from({ length: 30 }, (_, i) => ({
  id: `d${200 + i}`,
  name: fullName(),
  phone: `+91 9${rand(100000000, 999999999)}`,
  city: CITIES[rand(0, CITIES.length - 1)],
  vehicle: (["bike", "scooter", "bicycle"] as const)[rand(0, 2)],
  rating: +(3.8 + Math.random() * 1.2).toFixed(1),
  deliveries: rand(20, 2000),
  status: (["online", "offline", "busy", "offline"] as const)[rand(0, 3)],
  joinedAt: isoDaysAgo(rand(10, 600)),
}));

export const mockCoupons: Coupon[] = [
  { id: "c1", code: "WELCOME50", type: "percentage", value: 50, maxDiscount: 100, minOrder: 199, usageLimit: 10000, usagePerUser: 1, used: 4823, validFrom: isoDaysAgo(30), validTo: isoDaysAgo(-30), active: true, restaurants: "all" },
  { id: "c2", code: "FREEDEL", type: "free_delivery", value: 0, minOrder: 399, usageLimit: 50000, usagePerUser: 5, used: 12480, validFrom: isoDaysAgo(60), validTo: isoDaysAgo(-90), active: true, restaurants: "all" },
  { id: "c3", code: "LUNCH100", type: "flat", value: 100, minOrder: 299, usageLimit: 20000, usagePerUser: 3, used: 8211, validFrom: isoDaysAgo(15), validTo: isoDaysAgo(-15), active: true, restaurants: "all" },
  { id: "c4", code: "BIRYANI20", type: "percentage", value: 20, maxDiscount: 80, minOrder: 249, usageLimit: 5000, usagePerUser: 2, used: 1240, validFrom: isoDaysAgo(5), validTo: isoDaysAgo(-20), active: true, restaurants: ["r100", "r106"] },
  { id: "c5", code: "EXPIRED10", type: "flat", value: 50, minOrder: 199, usageLimit: 1000, usagePerUser: 1, used: 980, validFrom: isoDaysAgo(120), validTo: isoDaysAgo(30), active: false, restaurants: "all" },
];

export const mockFraud: FraudAlert[] = Array.from({ length: 14 }, (_, i) => {
  const order = mockOrders[i];
  const reasons = [
    "Multiple orders from same address with different accounts",
    "5+ cancellations in 24h",
    "Payment failure rate > 50%",
    "Suspicious refund pattern",
    "Device fingerprint mismatch",
  ];
  return {
    id: `f${i + 1}`,
    orderId: order.id,
    customerId: order.customerId,
    customerName: order.customerName,
    reason: reasons[i % reasons.length],
    risk: (["low", "medium", "high"] as const)[i % 3],
    detectedAt: order.createdAt,
    status: i % 5 === 0 ? "investigating" : "open",
    amount: order.amount,
  };
});

export const revenueSeries = (days: number) =>
  Array.from({ length: days }, (_, i) => {
    const date = new Date(Date.now() - (days - 1 - i) * 86400000);
    const gross = rand(45000, 120000);
    const refunds = rand(500, 4000);
    return {
      date: date.toISOString().slice(5, 10),
      gross,
      net: gross - refunds,
      refunds,
    };
  });

export const ordersByStatus = () =>
  STATUSES.map((s) => ({
    name: s,
    value: mockOrders.filter((o) => o.status === s).length,
  }));

export const newUsersSeries = (days: number) =>
  Array.from({ length: days }, (_, i) => ({
    date: new Date(Date.now() - (days - 1 - i) * 86400000).toISOString().slice(5, 10),
    users: rand(20, 220),
  }));

export const newRestaurantsSeries = (weeks: number) =>
  Array.from({ length: weeks }, (_, i) => ({
    week: `W${i + 1}`,
    count: rand(2, 18),
  }));

export const revenueByRestaurant = () =>
  [...mockRestaurants]
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 10)
    .map((r) => ({ name: r.name, revenue: r.revenue }));

export const aovTrend = (days: number) =>
  Array.from({ length: days }, (_, i) => ({
    date: new Date(Date.now() - (days - 1 - i) * 86400000).toISOString().slice(5, 10),
    aov: rand(280, 520),
  }));

export const funnelData = () => [
  { stage: "Search", value: 12480 },
  { stage: "Restaurant view", value: 8240 },
  { stage: "Cart", value: 4120 },
  { stage: "Checkout", value: 2860 },
  { stage: "Order", value: 2104 },
];

export const heatmapData = () => {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  return days.map((d) => ({
    day: d,
    hours: Array.from({ length: 24 }, (_, h) => {
      const peak = h >= 12 && h <= 14 ? 1.5 : h >= 19 && h <= 22 ? 2 : 0.6;
      return Math.round(rand(2, 40) * peak);
    }),
  }));
};

export const liveOrderTick = (): AdminOrder => {
  const rest = mockRestaurants[rand(0, mockRestaurants.length - 1)];
  const user = mockUsers[rand(0, mockUsers.length - 1)];
  return {
    id: `ORD${20000 + rand(0, 9999)}`,
    customerId: user.id,
    customerName: user.name,
    restaurantId: rest.id,
    restaurantName: rest.name,
    items: [{ name: "Combo", qty: 1, price: rand(200, 800) }],
    amount: rand(200, 1200),
    status: "pending",
    paymentMethod: "upi",
    address: user.city,
    createdAt: new Date().toISOString(),
  };
};