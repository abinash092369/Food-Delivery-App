import { format, formatDistanceToNow, parseISO } from "date-fns";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { liveOrderTick } from "./admin-mock";
import type { AdminOrder } from "@/types/admin";

export const inr = (n: number) =>
  `₹${n.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`;

export const fmtDate = (iso: string) => format(parseISO(iso), "dd MMM yyyy");
export const fmtDateTime = (iso: string) => format(parseISO(iso), "dd MMM, HH:mm");
export const fmtRel = (iso: string) =>
  formatDistanceToNow(parseISO(iso), { addSuffix: true });

export function exportToExcel<T extends Record<string, unknown>>(rows: T[], filename: string) {
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
  const buf = XLSX.write(wb, { type: "array", bookType: "xlsx" });
  saveAs(new Blob([buf], { type: "application/octet-stream" }), `${filename}.xlsx`);
}

export async function exportElementToPng(el: HTMLElement, filename: string) {
  const canvas = await html2canvas(el, { backgroundColor: "#162847", scale: 2 });
  canvas.toBlob((blob) => blob && saveAs(blob, `${filename}.png`));
}

export async function exportElementToPdf(el: HTMLElement, filename: string) {
  const canvas = await html2canvas(el, { backgroundColor: "#162847", scale: 2 });
  const img = canvas.toDataURL("image/png");
  const pdf = new jsPDF({ orientation: "landscape", unit: "px", format: [canvas.width, canvas.height] });
  pdf.addImage(img, "PNG", 0, 0, canvas.width, canvas.height);
  pdf.save(`${filename}.pdf`);
}

export const statusTone: Record<string, string> = {
  pending: "bg-warning/15 text-warning border-warning/30",
  preparing: "bg-chart-2/20 text-blue-300 border-blue-400/30",
  on_the_way: "bg-primary/15 text-primary border-primary/30",
  delivered: "bg-positive/15 text-positive border-positive/30",
  cancelled: "bg-destructive/15 text-destructive border-destructive/30",
  active: "bg-positive/15 text-positive border-positive/30",
  banned: "bg-destructive/15 text-destructive border-destructive/30",
  unverified: "bg-warning/15 text-warning border-warning/30",
  suspended: "bg-destructive/15 text-destructive border-destructive/30",
  online: "bg-positive/15 text-positive border-positive/30",
  offline: "bg-muted text-muted-foreground border-border",
  busy: "bg-warning/15 text-warning border-warning/30",
  open: "bg-warning/15 text-warning border-warning/30",
  investigating: "bg-chart-2/20 text-blue-300 border-blue-400/30",
  dismissed: "bg-muted text-muted-foreground border-border",
  low: "bg-positive/15 text-positive border-positive/30",
  medium: "bg-warning/15 text-warning border-warning/30",
  high: "bg-destructive/15 text-destructive border-destructive/30",
};

export const statusLabel = (s: string) =>
  s.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

type Listener = (o: AdminOrder) => void;
class LiveOrderBus {
  private listeners = new Set<Listener>();
  private timer: ReturnType<typeof setInterval> | null = null;
  subscribe(cb: Listener) {
    this.listeners.add(cb);
    if (!this.timer) {
      this.timer = setInterval(() => {
        const order = liveOrderTick();
        this.listeners.forEach((l) => l(order));
      }, 4000);
    }
    return () => {
      this.listeners.delete(cb);
      if (this.listeners.size === 0 && this.timer) {
        clearInterval(this.timer);
        this.timer = null;
      }
    };
  }
}
export const liveOrderBus = new LiveOrderBus();
