import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import { DataTable, type Column } from "@/components/shared/DataTable";
import { PageHeader } from "@/components/shared/PageHeader";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { ExportButton } from "@/components/shared/ExportButton";
import { deliveryApi } from "@/api/endpoints";
import type { DeliveryPartner } from "@/types/admin";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bike, Search, Star } from "lucide-react";

export const Route = createFileRoute("/admin/delivery")({ component: DeliveryPage });

function DeliveryPage() {
  const { data = [] } = useQuery({ queryKey: ["delivery"], queryFn: deliveryApi.list });
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");

  const filtered = useMemo(() => {
    let rows = data;
    if (q) {
      const s = q.toLowerCase();
      rows = rows.filter((d) => d.name.toLowerCase().includes(s) || d.city.toLowerCase().includes(s));
    }
    if (status !== "all") rows = rows.filter((d) => d.status === status);
    return rows;
  }, [data, q, status]);

  const columns: Column<DeliveryPartner>[] = [
    { key: "name", header: "Partner", render: (d) => (
      <div className="flex items-center gap-3">
        <div className="h-9 w-9 rounded-full bg-primary/15 text-primary flex items-center justify-center"><Bike className="h-4 w-4" /></div>
        <div>
          <Link to="/admin/delivery/$id" params={{ id: d.id }} className="font-medium hover:text-primary">{d.name}</Link>
          <p className="text-xs text-muted-foreground">{d.phone}</p>
        </div>
      </div>
    )},
    { key: "city", header: "City" },
    { key: "vehicle", header: "Vehicle", render: (d) => <span className="capitalize">{d.vehicle}</span> },
    { key: "rating", header: "Rating", render: (d) => <span className="inline-flex items-center gap-1"><Star className="h-3 w-3 fill-warning text-warning" />{d.rating.toFixed(1)}</span> },
    { key: "deliveries", header: "Deliveries", className: "tabular-nums" },
    { key: "status", header: "Status", render: (d) => <StatusBadge status={d.status} /> },
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="Delivery partners" description={`${data.length} riders on the platform.`} actions={
        <ExportButton rows={filtered as unknown as Record<string, unknown>[]} filename="eets-delivery" />
      } />
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name or city" className="pl-9 bg-card border-border" />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-40 bg-card border-border"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All status</SelectItem>
            <SelectItem value="online">Online</SelectItem>
            <SelectItem value="busy">Busy</SelectItem>
            <SelectItem value="offline">Offline</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <DataTable columns={columns} rows={filtered} rowKey={(d) => d.id} />
    </div>
  );
}
