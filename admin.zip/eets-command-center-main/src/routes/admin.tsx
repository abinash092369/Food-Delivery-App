import { createFileRoute, redirect } from "@tanstack/react-router";
import { AdminLayout } from "@/components/layout/AdminLayout";
import { useAdminAuth } from "@/store/adminAuth.store";

export const Route = createFileRoute("/admin")({
  beforeLoad: ({ location }) => {
    const { user } = useAdminAuth.getState();
    if (!user && location.pathname !== "/admin/login") {
      throw redirect({ to: "/admin/login" });
    }
    if (user && location.pathname === "/admin") {
      throw redirect({ to: "/admin/dashboard" });
    }
  },
  component: AdminGate,
});

function AdminGate() {
  const user = useAdminAuth((s) => s.user);
  if (!user) {
    // login renders inside this same route file via /admin/login
    // Outlet is handled by AdminLayout for authed users; bare outlet for login.
    return <BareOutlet />;
  }
  return <AdminLayout />;
}

import { Outlet } from "@tanstack/react-router";
function BareOutlet() {
  return <Outlet />;
}
