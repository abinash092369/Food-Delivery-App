import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useForm, type Resolver } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DataTable, type Column } from "@/components/shared/DataTable";
import { PageHeader } from "@/components/shared/PageHeader";
import { ExportButton } from "@/components/shared/ExportButton";
import { couponsApi } from "@/api/endpoints";
import type { Coupon } from "@/types/admin";
import { fmtDate } from "@/lib/admin-utils";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

const schema = z.object({
  code: z.string().min(3).max(20).regex(/^[A-Z0-9]+$/, "Uppercase letters/numbers only"),
  type: z.enum(["percentage", "flat", "free_delivery"]),
  value: z.coerce.number().min(0),
  maxDiscount: z.coerce.number().min(0).optional(),
  minOrder: z.coerce.number().min(0),
  usageLimit: z.coerce.number().min(1),
  usagePerUser: z.coerce.number().min(1),
  validFrom: z.string(),
  validTo: z.string(),
});
type FormInput = z.input<typeof schema>;
type FormData = z.output<typeof schema>;

export const Route = createFileRoute("/admin/coupons")({ component: CouponsPage });

function CouponsPage() {
  const { data = [], refetch } = useQuery({ queryKey: ["coupons"], queryFn: couponsApi.list });
  const [open, setOpen] = useState(false);
  const [list, setList] = useState<Coupon[]>([]);
  const rows = list.length ? list : data;

  const toggle = async (c: Coupon) => {
    const next = rows.map((x) => (x.id === c.id ? { ...x, active: !x.active } : x));
    setList(next);
    await couponsApi.update(c.id, { active: !c.active });
    toast.success(c.active ? "Deactivated" : "Activated");
  };

  const remove = async (id: string) => {
    setList(rows.filter((x) => x.id !== id));
    await couponsApi.remove(id);
    toast.success("Coupon deleted");
  };

  const columns: Column<Coupon>[] = [
    { key: "code", header: "Code", render: (c) => <span className="font-mono font-semibold text-primary">{c.code}</span> },
    { key: "type", header: "Type", render: (c) => <span className="capitalize text-sm">{c.type.replace("_", " ")}</span> },
    { key: "value", header: "Discount", render: (c) => c.type === "percentage" ? `${c.value}% off` : c.type === "flat" ? `₹${c.value} off` : "Free delivery" },
    { key: "min", header: "Min order", render: (c) => `₹${c.minOrder}` },
    { key: "usage", header: "Usage", render: (c) => `${c.used.toLocaleString()} / ${c.usageLimit.toLocaleString()}` },
    { key: "expiry", header: "Expiry", render: (c) => fmtDate(c.validTo) },
    { key: "active", header: "Active", render: (c) => <Switch checked={c.active} onCheckedChange={() => toggle(c)} /> },
    { key: "actions", header: "", className: "text-right", render: (c) => (
      <Button size="sm" variant="ghost" className="text-destructive" onClick={() => remove(c.id)}><Trash2 className="h-4 w-4" /></Button>
    )},
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="Coupons" description={`${rows.length} promo codes`} actions={<>
        <Button size="sm" onClick={() => setOpen(true)} className="bg-primary text-primary-foreground hover:bg-primary/90"><Plus className="h-4 w-4 mr-1" /> New coupon</Button>
        <ExportButton rows={rows as unknown as Record<string, unknown>[]} filename="eets-coupons" />
      </>} />
      <DataTable columns={columns} rows={rows} rowKey={(c) => c.id} />
      <CouponDialog open={open} onClose={() => setOpen(false)} onCreated={() => { setOpen(false); refetch(); }} />
    </div>
  );
}

function CouponDialog({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: () => void }) {
  const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<FormInput>({
    resolver: zodResolver(schema) as unknown as Resolver<FormInput>,
    defaultValues: { type: "percentage", validFrom: new Date().toISOString().slice(0, 10), validTo: new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10), usagePerUser: 1, usageLimit: 1000 },
  });
  const type = watch("type");

  const autoCode = () => {
    const code = Array.from({ length: 8 }, () => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[Math.floor(Math.random() * 32)]).join("");
    setValue("code", code);
  };

  const onSubmit = async (data: FormInput) => {
    await couponsApi.create(data);
    toast.success("Coupon created");
    reset();
    onCreated();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>Create coupon</DialogTitle></DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <Label>Code</Label>
            <div className="flex gap-2 mt-1.5">
              <Input {...register("code")} placeholder="WELCOME50" className="font-mono uppercase" />
              <Button type="button" variant="outline" onClick={autoCode}>Generate</Button>
            </div>
            {errors.code && <p className="text-xs text-destructive mt-1">{errors.code.message}</p>}
          </div>
          <div>
            <Label>Type</Label>
            <Select defaultValue="percentage" onValueChange={(v) => setValue("type", v as FormData["type"])}>
              <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="percentage">Percentage</SelectItem>
                <SelectItem value="flat">Flat ₹</SelectItem>
                <SelectItem value="free_delivery">Free delivery</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>{type === "percentage" ? "Percentage" : "Value (₹)"}</Label>
            <Input type="number" {...register("value")} className="mt-1.5" />
          </div>
          <div>
            <Label>Max discount cap (₹)</Label>
            <Input type="number" {...register("maxDiscount")} className="mt-1.5" />
          </div>
          <div>
            <Label>Min order (₹)</Label>
            <Input type="number" {...register("minOrder")} className="mt-1.5" />
          </div>
          <div>
            <Label>Usage limit</Label>
            <Input type="number" {...register("usageLimit")} className="mt-1.5" />
          </div>
          <div>
            <Label>Per user</Label>
            <Input type="number" {...register("usagePerUser")} className="mt-1.5" />
          </div>
          <div>
            <Label>Valid from</Label>
            <Input type="date" {...register("validFrom")} className="mt-1.5" />
          </div>
          <div>
            <Label>Valid to</Label>
            <Input type="date" {...register("validTo")} className="mt-1.5" />
          </div>
          <DialogFooter className="col-span-2 mt-2">
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" className="bg-primary text-primary-foreground">Create</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
