import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/shared/PageHeader";
import { Card } from "@/components/ui/card";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { inr } from "@/lib/admin-utils";
import { Activity, BarChart3, TrendingUp, Users } from "lucide-react";

export const Route = createFileRoute("/admin/analytics")({ component: AnalyticsHub });

function AnalyticsHub() {
  return (
    <div className="space-y-6">
      <PageHeader title="Analytics" description="Platform health, revenue and growth at a glance." />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard label="GMV (30d)" value={inr(28_400_000)} delta={9.2} icon={<TrendingUp className="h-5 w-5" />} />
        <MetricCard label="Net revenue" value={inr(4_120_000)} delta={6.4} icon={<BarChart3 className="h-5 w-5" />} />
        <MetricCard label="Avg order value" value={inr(389)} delta={-2.1} icon={<Activity className="h-5 w-5" />} />
        <MetricCard label="Retention rate" value="62.8%" delta={3.5} icon={<Users className="h-5 w-5" />} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <HubCard to="/admin/analytics/revenue" title="Revenue" desc="Daily revenue, top restaurants and AOV trend." />
        <HubCard to="/admin/analytics/orders" title="Orders" desc="Order density heatmap and status distribution." />
        <HubCard to="/admin/analytics/users" title="Users" desc="New users, conversion funnel and retention." />
      </div>
    </div>
  );
}

function HubCard({ to, title, desc }: { to: string; title: string; desc: string }) {
  return (
    <Link to={to}>
      <Card className="p-5 bg-card border-border hover:border-primary/40 transition-colors cursor-pointer">
        <h3 className="font-semibold">{title}</h3>
        <p className="text-sm text-muted-foreground mt-1">{desc}</p>
        <p className="text-xs text-primary mt-3">View report →</p>
      </Card>
    </Link>
  );
}
