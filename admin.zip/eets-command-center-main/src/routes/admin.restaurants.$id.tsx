import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { restaurantsApi, ordersApi } from "@/api/endpoints";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { fmtDate, inr } from "@/lib/admin-utils";
import { ArrowLeft, Star, MapPin, Utensils, Pause, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/restaurants/$id")({ component: RestaurantDetail });

function RestaurantDetail() {
  const { id } = Route.useParams();
  const restaurants = useQuery({ queryKey: ["restaurants"], queryFn: restaurantsApi.list });
  const orders = useQuery({ queryKey: ["orders"], queryFn: ordersApi.list });
  const r = restaurants.data?.find((x) => x.id === id);
  const restOrders = orders.data?.filter((o) => o.restaurantId === id) ?? [];

  if (!r) return <p className="text-muted-foreground">Restaurant not found.</p>;

  return (
    <div className="space-y-6">
      <Button asChild variant="ghost" size="sm" className="gap-2 -ml-2"><Link to="/admin/restaurants"><ArrowLeft className="h-4 w-4" /> All restaurants</Link></Button>

      <Card className="p-6 bg-card border-border">
        <div className="flex items-start gap-5">
          <div className="h-24 w-24 rounded-xl overflow-hidden bg-card-elevated shrink-0"><img src={r.logo} alt="" className="h-full w-full object-cover" /></div>
          <div className="flex-1">
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-2xl font-bold">{r.name}</h1>
              <StatusBadge status={r.status} />
            </div>
            <p className="text-muted-foreground text-sm mt-1 flex items-center gap-4 flex-wrap">
              <span className="flex items-center gap-1"><Star className="h-3.5 w-3.5 fill-warning text-warning" />{r.rating.toFixed(1)}</span>
              <span className="flex items-center gap-1"><Utensils className="h-3.5 w-3.5" />{r.cuisine}</span>
              <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{r.address}, {r.city}</span>
            </p>
            <p className="text-xs text-muted-foreground mt-1">Owner: {r.owner} · {r.ownerEmail}</p>
            <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-3">
              <Stat label="Total orders" value={r.orders.toLocaleString()} />
              <Stat label="Revenue" value={inr(r.revenue)} />
              <Stat label="Avg order" value={inr(r.orders ? Math.round(r.revenue / r.orders) : 0)} />
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <Button variant="outline" size="sm" onClick={async () => { await restaurantsApi.suspend(r.id); toast.success("Suspended"); }}>
              <Pause className="h-4 w-4 mr-1" /> Suspend
            </Button>
            <Button variant="ghost" size="sm" className="text-destructive" onClick={async () => { await restaurantsApi.remove(r.id); toast.success("Deleted"); }}>
              <Trash2 className="h-4 w-4 mr-1" /> Delete
            </Button>
          </div>
        </div>
      </Card>

      <Card className="p-6 bg-card border-border">
        <h2 className="font-semibold mb-4">Recent orders</h2>
        <div className="divide-y divide-border/60">
          {restOrders.slice(0, 12).map((o) => (
            <div key={o.id} className="flex items-center gap-4 py-3 text-sm">
              <span className="font-mono text-xs text-muted-foreground w-24">{o.id}</span>
              <span className="flex-1">{o.customerName}</span>
              <span className="tabular-nums">{inr(o.amount)}</span>
              <StatusBadge status={o.status} />
              <span className="text-xs text-muted-foreground w-28 text-right">{fmtDate(o.createdAt)}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-card-elevated/40 p-3">
      <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-1 font-semibold">{value}</p>
    </div>
  );
}
