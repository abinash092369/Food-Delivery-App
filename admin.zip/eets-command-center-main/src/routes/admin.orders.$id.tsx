import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/admin/orders/$id")({ component: OrderDetail });

function OrderDetail() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  useEffect(() => { navigate({ to: "/admin/orders" }); }, [navigate]);
  return <p className="text-muted-foreground">Opening <Link to="/admin/orders" className="text-primary">order {id}</Link>...</p>;
}
