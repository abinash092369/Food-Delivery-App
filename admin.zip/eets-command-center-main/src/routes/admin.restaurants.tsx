import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DataTable, type Column } from "@/components/shared/DataTable";
import { PageHeader } from "@/components/shared/PageHeader";
import { ExportButton } from "@/components/shared/ExportButton";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { restaurantsApi } from "@/api/endpoints";
import type { AdminRestaurant } from "@/types/admin";
import { inr } from "@/lib/admin-utils";
import { Search, Star, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/restaurants")({ component: RestaurantsPage });

function RestaurantsPage() {
  const { data = [], refetch } = useQuery({ queryKey: ["restaurants"], queryFn: restaurantsApi.list });
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("all");

  const filtered = useMemo(() => {
    let rows = data;
    if (q) {
      const s = q.toLowerCase();
      rows = rows.filter((r) => r.name.toLowerCase().includes(s) || r.owner.toLowerCase().includes(s));
    }
    if (status !== "all") rows = rows.filter((r) => r.status === status);
    return rows;
  }, [data, q, status]);

  const columns: Column<AdminRestaurant>[] = [
    {
      key: "name", header: "Restaurant",
      render: (r) => (
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-card-elevated overflow-hidden">
            <img src={r.logo} alt="" className="h-full w-full object-cover" />
          </div>
          <div>
            <Link to="/admin/restaurants/$id" params={{ id: r.id }} className="font-medium hover:text-primary">{r.name}</Link>
            <p className="text-xs text-muted-foreground">{r.cuisine}</p>
          </div>
        </div>
      ),
    },
    { key: "owner", header: "Owner", render: (r) => (<><p className="text-sm">{r.owner}</p><p className="text-xs text-muted-foreground">{r.ownerEmail}</p></>) },
    { key: "city", header: "City" },
    { key: "rating", header: "Rating", render: (r) => (<span className="inline-flex items-center gap-1"><Star className="h-3 w-3 fill-warning text-warning" />{r.rating.toFixed(1)}</span>) },
    { key: "orders", header: "Orders", className: "tabular-nums" },
    { key: "revenue", header: "Revenue", render: (r) => <span className="tabular-nums">{inr(r.revenue)}</span> },
    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
    {
      key: "actions", header: "", className: "text-right",
      render: (r) => (
        <Button size="sm" variant="ghost" className="text-destructive" onClick={async (e) => { e.stopPropagation(); await restaurantsApi.remove(r.id); toast.success("Restaurant deleted"); refetch(); }}>
          <Trash2 className="h-4 w-4" />
        </Button>
      ),
    },
  ];

  const pendingCount = data.filter((r) => r.status === "pending").length;

  return (
    <div className="space-y-4">
      <PageHeader
        title="Restaurants"
        description={`${data.length} restaurants · ${pendingCount} pending approval`}
        actions={<>
          <Button asChild variant="outline" size="sm"><Link to="/admin/restaurants/pending">Approval queue ({pendingCount})</Link></Button>
          <ExportButton rows={filtered as unknown as Record<string, unknown>[]} filename="eets-restaurants" />
        </>}
      />

      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name or owner" className="pl-9 bg-card border-border" />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-40 bg-card border-border"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="suspended">Suspended</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <DataTable columns={columns} rows={filtered} rowKey={(r) => r.id} />
    </div>
  );
}
