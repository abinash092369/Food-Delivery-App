import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/shared/PageHeader";
import { useAdminAuth } from "@/store/adminAuth.store";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/settings")({ component: SettingsPage });

function SettingsPage() {
  const can = useAdminAuth((s) => s.can("settings"));
  const nav = useNavigate();
  useEffect(() => { if (!can) nav({ to: "/admin/dashboard" }); }, [can, nav]);

  return (
    <div className="space-y-6">
      <PageHeader title="Platform settings" description="Global configuration · super admins only." />

      <Card className="p-6 bg-card border-border space-y-4">
        <h2 className="font-semibold">Operations</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Field label="Platform name"><Input defaultValue="eets" /></Field>
          <Field label="Support email"><Input defaultValue="help@eets.app" /></Field>
          <Field label="Default delivery radius (km)"><Input type="number" defaultValue={8} /></Field>
          <Field label="Platform commission (%)"><Input type="number" defaultValue={18} /></Field>
        </div>
      </Card>

      <Card className="p-6 bg-card border-border space-y-4">
        <h2 className="font-semibold">Feature flags</h2>
        <Flag label="Surge pricing" description="Enable dynamic pricing during peak hours." defaultChecked />
        <Flag label="Self-pickup orders" description="Let customers pick up orders directly from restaurants." />
        <Flag label="Live partner tracking" description="Show live rider location to customers." defaultChecked />
        <Flag label="Auto-refund failed payments" description="Refund automatically when payment capture fails." defaultChecked />
      </Card>

      <div className="flex justify-end">
        <Button onClick={() => toast.success("Settings saved")} className="bg-primary text-primary-foreground">Save changes</Button>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (<div><Label>{label}</Label><div className="mt-1.5">{children}</div></div>);
}
function Flag({ label, description, defaultChecked }: { label: string; description: string; defaultChecked?: boolean }) {
  return (
    <div className="flex items-center justify-between border-t border-border/60 first:border-0 pt-4 first:pt-0">
      <div><p className="font-medium text-sm">{label}</p><p className="text-xs text-muted-foreground">{description}</p></div>
      <Switch defaultChecked={defaultChecked} />
    </div>
  );
}
