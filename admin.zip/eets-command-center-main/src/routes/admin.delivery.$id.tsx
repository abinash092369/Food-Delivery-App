import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { deliveryApi } from "@/api/endpoints";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { ArrowLeft, Bike, Star } from "lucide-react";
import { fmtDate } from "@/lib/admin-utils";

export const Route = createFileRoute("/admin/delivery/$id")({ component: PartnerDetail });

function PartnerDetail() {
  const { id } = Route.useParams();
  const { data = [] } = useQuery({ queryKey: ["delivery"], queryFn: deliveryApi.list });
  const d = data.find((x) => x.id === id);
  if (!d) return <p className="text-muted-foreground">Partner not found.</p>;
  return (
    <div className="space-y-6">
      <Button asChild variant="ghost" size="sm" className="gap-2 -ml-2"><Link to="/admin/delivery"><ArrowLeft className="h-4 w-4" /> All partners</Link></Button>
      <Card className="p-6 bg-card border-border">
        <div className="flex items-start gap-5">
          <div className="h-16 w-16 rounded-full bg-primary/15 text-primary flex items-center justify-center"><Bike className="h-7 w-7" /></div>
          <div className="flex-1">
            <div className="flex items-center gap-3"><h1 className="text-2xl font-bold">{d.name}</h1><StatusBadge status={d.status} /></div>
            <p className="text-sm text-muted-foreground">{d.phone} · {d.city} · {d.vehicle}</p>
            <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
              <Stat label="Deliveries" value={d.deliveries.toLocaleString()} />
              <Stat label="Rating" value={`${d.rating.toFixed(1)} ★`} />
              <Stat label="Joined" value={fmtDate(d.joinedAt)} />
              <Stat label="Status" value={d.status} />
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-card-elevated/40 p-3">
      <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-1 font-semibold capitalize">{value}</p>
    </div>
  );
}
