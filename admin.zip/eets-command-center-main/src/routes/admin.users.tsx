import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { DataTable, type Column } from "@/components/shared/DataTable";
import { Pagination } from "@/components/shared/Pagination";
import { PageHeader } from "@/components/shared/PageHeader";
import { ExportButton } from "@/components/shared/ExportButton";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { usersApi } from "@/api/endpoints";
import { fmtDate } from "@/lib/admin-utils";
import type { PlatformUser } from "@/types/admin";
import { Ban, CheckCircle, Eye, Search } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/users")({ component: UsersPage });

function UsersPage() {
  const { data = [], refetch } = useQuery({ queryKey: ["users"], queryFn: usersApi.list });
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("all");
  const [sort, setSort] = useState<"joined" | "orders">("joined");
  const [page, setPage] = useState(1);
  const [banTarget, setBanTarget] = useState<PlatformUser | null>(null);
  const [reason, setReason] = useState("");
  const pageSize = 10;

  const filtered = useMemo(() => {
    let rows = data;
    if (q) {
      const s = q.toLowerCase();
      rows = rows.filter((u) => u.name.toLowerCase().includes(s) || u.email.toLowerCase().includes(s));
    }
    if (status !== "all") rows = rows.filter((u) => u.status === status);
    rows = [...rows].sort((a, b) =>
      sort === "joined"
        ? new Date(b.joinedAt).getTime() - new Date(a.joinedAt).getTime()
        : b.orders - a.orders,
    );
    return rows;
  }, [data, q, status, sort]);

  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  const columns: Column<PlatformUser>[] = [
    {
      key: "user", header: "User",
      render: (u) => (
        <div className="flex items-center gap-3">
          <Avatar className="h-9 w-9"><AvatarImage src={u.avatar} /><AvatarFallback>{u.name[0]}</AvatarFallback></Avatar>
          <div>
            <Link to="/admin/users/$id" params={{ id: u.id }} className="font-medium hover:text-primary">{u.name}</Link>
            <p className="text-xs text-muted-foreground">{u.email}</p>
          </div>
        </div>
      ),
    },
    { key: "phone", header: "Phone", render: (u) => <span className="text-muted-foreground">{u.phone}</span> },
    { key: "orders", header: "Orders", className: "tabular-nums" },
    { key: "joined", header: "Joined", render: (u) => fmtDate(u.joinedAt) },
    { key: "status", header: "Status", render: (u) => <StatusBadge status={u.status} /> },
    {
      key: "actions", header: "", className: "text-right",
      render: (u) => (
        <div className="flex items-center justify-end gap-1">
          <Button asChild size="sm" variant="ghost"><Link to="/admin/users/$id" params={{ id: u.id }}><Eye className="h-4 w-4" /></Link></Button>
          {u.status === "banned" ? (
            <Button size="sm" variant="ghost" className="text-positive" onClick={async (e) => { e.stopPropagation(); await usersApi.unban(u.id); toast.success("User unbanned"); refetch(); }}>
              <CheckCircle className="h-4 w-4" />
            </Button>
          ) : (
            <Button size="sm" variant="ghost" className="text-destructive" onClick={(e) => { e.stopPropagation(); setBanTarget(u); }}>
              <Ban className="h-4 w-4" />
            </Button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <PageHeader
        title="Users"
        description={`${filtered.length} customers on the platform.`}
        actions={<ExportButton rows={filtered as unknown as Record<string, unknown>[]} filename="eets-users" />}
      />

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder="Search name or email" className="pl-9 bg-card border-border" />
        </div>
        <Select value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
          <SelectTrigger className="w-40 bg-card border-border"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="banned">Banned</SelectItem>
            <SelectItem value="unverified">Unverified</SelectItem>
          </SelectContent>
        </Select>
        <Select value={sort} onValueChange={(v) => setSort(v as "joined" | "orders")}>
          <SelectTrigger className="w-40 bg-card border-border"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="joined">Newest first</SelectItem>
            <SelectItem value="orders">Most orders</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <DataTable columns={columns} rows={paged} rowKey={(u) => u.id} />
      <Pagination page={page} total={filtered.length} pageSize={pageSize} onChange={setPage} />

      <Dialog open={!!banTarget} onOpenChange={(o) => !o && setBanTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Ban {banTarget?.name}?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">The user will be notified and unable to place orders.</p>
          <Textarea placeholder="Reason for ban" value={reason} onChange={(e) => setReason(e.target.value)} />
          <DialogFooter>
            <Button variant="outline" onClick={() => setBanTarget(null)}>Cancel</Button>
            <Button
              variant="destructive"
              disabled={!reason.trim()}
              onClick={async () => {
                if (!banTarget) return;
                await usersApi.ban(banTarget.id, reason);
                toast.success("User banned");
                setBanTarget(null);
                setReason("");
                refetch();
              }}
            >Confirm ban</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
