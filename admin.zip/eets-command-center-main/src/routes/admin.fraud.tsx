import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/shared/PageHeader";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { fraudApi } from "@/api/endpoints";
import { useAdminAuth } from "@/store/adminAuth.store";
import { fmtDateTime, inr } from "@/lib/admin-utils";
import { ShieldAlert } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/fraud")({ component: FraudPage });

function FraudPage() {
  const can = useAdminAuth((s) => s.can("fraud"));
  const nav = useNavigate();
  useEffect(() => { if (!can) nav({ to: "/admin/dashboard" }); }, [can, nav]);

  const { data = [], refetch } = useQuery({ queryKey: ["fraud"], queryFn: fraudApi.list });

  return (
    <div className="space-y-4">
      <PageHeader title="Fraud detection" description={`${data.length} flagged activities`} />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-2">
        <RuleCard title="Duplicate addresses" body="Multiple accounts ordering to the same address." />
        <RuleCard title="Cancellation spikes" body="More than 5 cancellations within 24 hours." />
        <RuleCard title="Payment failures" body="Payment failure rate above 50% per account." />
      </div>

      <div className="space-y-3">
        {data.map((f) => (
          <Card key={f.id} className="p-5 bg-card border-border">
            <div className="flex items-start gap-4">
              <div className="rounded-lg bg-destructive/15 text-destructive p-2"><ShieldAlert className="h-5 w-5" /></div>
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-3 flex-wrap">
                  <span className="font-mono text-sm">{f.orderId}</span>
                  <StatusBadge status={f.risk} />
                  <StatusBadge status={f.status} />
                </div>
                <p className="text-sm">{f.reason}</p>
                <p className="text-xs text-muted-foreground">{f.customerName} · {inr(f.amount)} · {fmtDateTime(f.detectedAt)}</p>
              </div>
              <div className="flex gap-2 shrink-0">
                <Button size="sm" variant="outline" onClick={async () => { await fraudApi.dismiss(f.id); toast.success("Dismissed"); refetch(); }}>Dismiss</Button>
                <Button size="sm" className="bg-primary text-primary-foreground" onClick={async () => { await fraudApi.investigate(f.id); toast.success("Marked for investigation"); refetch(); }}>Investigate</Button>
                <Button size="sm" variant="destructive">Ban user</Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function RuleCard({ title, body }: { title: string; body: string }) {
  return (
    <Card className="p-4 bg-card border-border">
      <h3 className="text-sm font-semibold">{title}</h3>
      <p className="text-xs text-muted-foreground mt-1">{body}</p>
    </Card>
  );
}
