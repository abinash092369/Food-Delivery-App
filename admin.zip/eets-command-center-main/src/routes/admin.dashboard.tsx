import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { DollarSign, ShoppingBag, UserPlus, Store } from "lucide-react";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { RevenueChart } from "@/components/dashboard/RevenueChart";
import { OrdersDonut } from "@/components/dashboard/OrdersDonut";
import { LiveFeed } from "@/components/dashboard/LiveFeed";
import { PageHeader } from "@/components/shared/PageHeader";
import { DateRangePicker, type DateRange, rangeToDays } from "@/components/shared/DateRangePicker";
import { analyticsApi } from "@/api/endpoints";
import { inr } from "@/lib/admin-utils";

export const Route = createFileRoute("/admin/dashboard")({ component: Dashboard });

function Dashboard() {
  const [range, setRange] = useState<DateRange>("7d");
  const revenue = useQuery({
    queryKey: ["dash-revenue", range],
    queryFn: () => analyticsApi.revenue(rangeToDays(range)),
  });
  const orders = useQuery({ queryKey: ["dash-orders"], queryFn: () => analyticsApi.ordersStatus() });

  const todayRev = revenue.data?.[revenue.data.length - 1]?.gross ?? 84200;
  const activeOrders = orders.data?.filter((o) => ["pending", "preparing", "on_the_way"].includes(o.name)).reduce((s, o) => s + o.value, 0) ?? 24;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Dashboard"
        description="Real-time overview of the eets platform."
        actions={<DateRangePicker value={range} onChange={setRange} />}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard label="Revenue today" value={inr(todayRev)} delta={12.4} icon={<DollarSign className="h-5 w-5" />} />
        <MetricCard label="Active orders" value={String(activeOrders)} delta={-3.2} icon={<ShoppingBag className="h-5 w-5" />} />
        <MetricCard label="New users" value="148" delta={8.1} icon={<UserPlus className="h-5 w-5" />} />
        <MetricCard label="Active restaurants" value="312" delta={1.5} icon={<Store className="h-5 w-5" />} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        <div className="lg:col-span-3 rounded-xl border border-border bg-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Revenue over time</h3>
            <span className="text-xs text-muted-foreground">Gross · Net · Refunds</span>
          </div>
          <RevenueChart data={revenue.data ?? []} />
        </div>
        <div className="lg:col-span-2 rounded-xl border border-border bg-card p-5">
          <h3 className="font-semibold mb-4">Orders by status</h3>
          <OrdersDonut data={orders.data ?? []} />
        </div>
      </div>

      <LiveFeed />
    </div>
  );
}
