import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { DataTable, type Column } from "@/components/shared/DataTable";
import { Pagination } from "@/components/shared/Pagination";
import { PageHeader } from "@/components/shared/PageHeader";
import { ExportButton } from "@/components/shared/ExportButton";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { ordersApi } from "@/api/endpoints";
import { fmtDateTime, inr } from "@/lib/admin-utils";
import type { AdminOrder, OrderStatus } from "@/types/admin";
import { Search } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/orders")({ component: OrdersPage });

const STATUSES: OrderStatus[] = ["pending", "preparing", "on_the_way", "delivered", "cancelled"];

function OrdersPage() {
  const { data = [] } = useQuery({ queryKey: ["orders"], queryFn: ordersApi.list });
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("all");
  const [pay, setPay] = useState<string>("all");
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState<AdminOrder | null>(null);
  const pageSize = 12;

  const filtered = useMemo(() => {
    let rows = data;
    if (q) {
      const s = q.toLowerCase();
      rows = rows.filter((o) => o.id.toLowerCase().includes(s) || o.customerName.toLowerCase().includes(s) || o.restaurantName.toLowerCase().includes(s));
    }
    if (status !== "all") rows = rows.filter((o) => o.status === status);
    if (pay !== "all") rows = rows.filter((o) => o.paymentMethod === pay);
    return rows;
  }, [data, q, status, pay]);

  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  const columns: Column<AdminOrder>[] = [
    { key: "id", header: "Order", render: (o) => <span className="font-mono text-xs">{o.id}</span> },
    { key: "customer", header: "Customer", render: (o) => o.customerName },
    { key: "restaurant", header: "Restaurant", render: (o) => <span className="text-muted-foreground">{o.restaurantName}</span> },
    { key: "amount", header: "Amount", render: (o) => <span className="tabular-nums">{inr(o.amount)}</span> },
    { key: "pay", header: "Payment", render: (o) => <span className="uppercase text-xs text-muted-foreground">{o.paymentMethod}</span> },
    { key: "status", header: "Status", render: (o) => <StatusBadge status={o.status} /> },
    { key: "date", header: "Placed", render: (o) => <span className="text-xs text-muted-foreground">{fmtDateTime(o.createdAt)}</span> },
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="Orders" description={`${filtered.length} orders`} actions={
        <ExportButton rows={filtered as unknown as Record<string, unknown>[]} filename="eets-orders" />
      } />
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder="Search by order ID, customer or restaurant" className="pl-9 bg-card border-border" />
        </div>
        <Select value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
          <SelectTrigger className="w-40 bg-card border-border"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All status</SelectItem>
            {STATUSES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s.replace(/_/g, " ")}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={pay} onValueChange={(v) => { setPay(v); setPage(1); }}>
          <SelectTrigger className="w-40 bg-card border-border"><SelectValue placeholder="Payment" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Any payment</SelectItem>
            <SelectItem value="card">Card</SelectItem>
            <SelectItem value="upi">UPI</SelectItem>
            <SelectItem value="cod">Cash on delivery</SelectItem>
            <SelectItem value="wallet">Wallet</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <DataTable columns={columns} rows={paged} rowKey={(o) => o.id} onRowClick={setOpen} />
      <Pagination page={page} total={filtered.length} pageSize={pageSize} onChange={setPage} />

      <OrderDrawer order={open} onClose={() => setOpen(null)} />
    </div>
  );
}

function OrderDrawer({ order, onClose }: { order: AdminOrder | null; onClose: () => void }) {
  const [notes, setNotes] = useState(order?.notes ?? "");
  const [refundOpen, setRefundOpen] = useState(false);
  const [amount, setAmount] = useState(order?.amount ?? 0);
  const [reason, setReason] = useState("");

  return (
    <Sheet open={!!order} onOpenChange={(o) => !o && onClose()}>
      <SheetContent className="bg-card border-border w-full sm:max-w-lg overflow-y-auto">
        {order && (
          <>
            <SheetHeader>
              <SheetTitle className="flex items-center justify-between">
                <span className="font-mono text-base">{order.id}</span>
                <StatusBadge status={order.status} />
              </SheetTitle>
            </SheetHeader>

            <div className="mt-6 space-y-5 text-sm">
              <Section title="Customer">
                <p>{order.customerName}</p>
                <p className="text-muted-foreground text-xs">{order.address}</p>
              </Section>

              <Section title="Restaurant"><p>{order.restaurantName}</p></Section>

              <Section title="Items">
                <ul className="divide-y divide-border/50">
                  {order.items.map((it, i) => (
                    <li key={i} className="flex items-center justify-between py-2">
                      <span>{it.qty}× {it.name}</span>
                      <span className="tabular-nums">{inr(it.price * it.qty)}</span>
                    </li>
                  ))}
                </ul>
                <div className="flex items-center justify-between pt-3 font-semibold">
                  <span>Total</span><span className="tabular-nums">{inr(order.amount)}</span>
                </div>
                <p className="mt-1 text-xs text-muted-foreground uppercase">{order.paymentMethod}</p>
              </Section>

              <Section title="Timeline">
                <ol className="space-y-2">
                  <li className="text-xs"><span className="text-muted-foreground">Placed</span> · {fmtDateTime(order.createdAt)}</li>
                  {order.deliveredAt && <li className="text-xs"><span className="text-muted-foreground">Delivered</span> · {fmtDateTime(order.deliveredAt)}</li>}
                </ol>
              </Section>

              <Section title="Admin notes">
                <Textarea placeholder="Internal notes (not visible to customer)" value={notes} onChange={(e) => setNotes(e.target.value)} />
                <Button size="sm" className="mt-2" onClick={async () => { await ordersApi.saveNotes(order.id, notes); toast.success("Notes saved"); }}>Save notes</Button>
              </Section>

              {order.status !== "cancelled" && (
                <Button variant="outline" className="w-full border-destructive/40 text-destructive hover:bg-destructive/10" onClick={() => { setAmount(order.amount); setRefundOpen(true); }}>
                  Issue refund
                </Button>
              )}
            </div>

            <Dialog open={refundOpen} onOpenChange={setRefundOpen}>
              <DialogContent>
                <DialogHeader><DialogTitle>Refund order {order.id}</DialogTitle></DialogHeader>
                <div className="space-y-3">
                  <div>
                    <Label>Amount (₹)</Label>
                    <Input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value))} max={order.amount} min={0} />
                  </div>
                  <div>
                    <Label>Reason</Label>
                    <Textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Reason for refund" />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setRefundOpen(false)}>Cancel</Button>
                  <Button disabled={!reason.trim() || amount <= 0} onClick={async () => {
                    await ordersApi.refund(order.id, amount, reason);
                    toast.success("Refund issued");
                    setRefundOpen(false); setReason("");
                  }}>Confirm refund</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="text-xs uppercase tracking-wider text-muted-foreground mb-2">{title}</h3>
      {children}
    </div>
  );
}
