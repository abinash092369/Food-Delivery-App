import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { PageHeader } from "@/components/shared/PageHeader";
import { restaurantsApi } from "@/api/endpoints";
import { fmtDate } from "@/lib/admin-utils";
import { ArrowLeft, Check, MapPin, Utensils, X } from "lucide-react";
import type { AdminRestaurant } from "@/types/admin";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/restaurants/pending")({ component: PendingPage });

function PendingPage() {
  const { data = [], refetch } = useQuery({ queryKey: ["restaurants-pending"], queryFn: restaurantsApi.pending });
  const [reject, setReject] = useState<AdminRestaurant | null>(null);
  const [reason, setReason] = useState("");

  return (
    <div className="space-y-6">
      <Button asChild variant="ghost" size="sm" className="gap-2 -ml-2"><Link to="/admin/restaurants"><ArrowLeft className="h-4 w-4" /> All restaurants</Link></Button>
      <PageHeader title="Approval queue" description={`${data.length} restaurants awaiting review.`} />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {data.length === 0 && <p className="text-muted-foreground col-span-3 text-center py-12">All caught up.</p>}
        {data.map((r) => (
          <Card key={r.id} className="p-5 bg-card border-border space-y-4">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-lg overflow-hidden bg-card-elevated"><img src={r.logo} alt="" className="h-full w-full object-cover" /></div>
              <div>
                <h3 className="font-semibold">{r.name}</h3>
                <p className="text-xs text-muted-foreground">by {r.owner}</p>
              </div>
            </div>
            <div className="space-y-1.5 text-sm text-muted-foreground">
              <p className="flex items-center gap-2"><Utensils className="h-3.5 w-3.5" /> {r.cuisine}</p>
              <p className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5" /> {r.address}, {r.city}</p>
              <p className="text-xs">Submitted {fmtDate(r.submittedAt)}</p>
            </div>
            <div className="flex gap-2">
              <Button className="flex-1 bg-positive hover:bg-positive/90 text-background" onClick={async () => { await restaurantsApi.approve(r.id); toast.success(`${r.name} approved`); refetch(); }}>
                <Check className="h-4 w-4 mr-1" /> Approve
              </Button>
              <Button variant="outline" className="flex-1 border-destructive/40 text-destructive hover:bg-destructive/10" onClick={() => setReject(r)}>
                <X className="h-4 w-4 mr-1" /> Reject
              </Button>
            </div>
          </Card>
        ))}
      </div>

      <Dialog open={!!reject} onOpenChange={(o) => !o && setReject(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Reject {reject?.name}</DialogTitle></DialogHeader>
          <Textarea placeholder="Reason for rejection" value={reason} onChange={(e) => setReason(e.target.value)} />
          <DialogFooter>
            <Button variant="outline" onClick={() => setReject(null)}>Cancel</Button>
            <Button variant="destructive" disabled={!reason.trim()} onClick={async () => {
              if (!reject) return;
              await restaurantsApi.reject(reject.id, reason);
              toast.success("Rejected — owner notified");
              setReject(null); setReason(""); refetch();
            }}>Confirm reject</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
