import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { usersApi, ordersApi } from "@/api/endpoints";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { fmtDate, fmtDateTime, inr } from "@/lib/admin-utils";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/admin/users/$id")({ component: UserDetail });

function UserDetail() {
  const { id } = Route.useParams();
  const users = useQuery({ queryKey: ["users"], queryFn: usersApi.list });
  const orders = useQuery({ queryKey: ["orders"], queryFn: ordersApi.list });
  const user = users.data?.find((u) => u.id === id);
  const userOrders = orders.data?.filter((o) => o.customerId === id) ?? [];

  if (!user) return <p className="text-muted-foreground">User not found.</p>;

  return (
    <div className="space-y-6">
      <Button asChild variant="ghost" size="sm" className="gap-2 -ml-2"><Link to="/admin/users"><ArrowLeft className="h-4 w-4" /> All users</Link></Button>

      <Card className="p-6 bg-card border-border">
        <div className="flex items-start gap-5">
          <Avatar className="h-20 w-20"><AvatarImage src={user.avatar} /><AvatarFallback>{user.name[0]}</AvatarFallback></Avatar>
          <div className="flex-1">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold">{user.name}</h1>
              <StatusBadge status={user.status} />
            </div>
            <p className="text-muted-foreground text-sm">{user.email} · {user.phone} · {user.city}</p>
            <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
              <Stat label="Orders" value={String(user.orders)} />
              <Stat label="Total spend" value={inr(user.totalSpend)} />
              <Stat label="Joined" value={fmtDate(user.joinedAt)} />
              <Stat label="Avg order" value={inr(user.orders ? Math.round(user.totalSpend / user.orders) : 0)} />
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-6 bg-card border-border">
        <h2 className="font-semibold mb-4">Order history</h2>
        <div className="divide-y divide-border/60">
          {userOrders.length === 0 ? (
            <p className="text-muted-foreground text-sm py-6 text-center">No orders yet.</p>
          ) : userOrders.map((o) => (
            <div key={o.id} className="flex items-center gap-4 py-3">
              <span className="font-mono text-xs text-muted-foreground w-24">{o.id}</span>
              <span className="flex-1 text-sm">{o.restaurantName}</span>
              <span className="text-sm tabular-nums">{inr(o.amount)}</span>
              <StatusBadge status={o.status} />
              <span className="w-32 text-right text-xs text-muted-foreground">{fmtDateTime(o.createdAt)}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-card-elevated/40 p-3">
      <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-1 font-semibold">{value}</p>
    </div>
  );
}
