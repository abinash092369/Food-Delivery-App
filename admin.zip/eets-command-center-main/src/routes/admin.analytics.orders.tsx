import { createFileRoute, Link } from "@tanstack/react-router";
import { useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { PageHeader } from "@/components/shared/PageHeader";
import { OrdersDonut } from "@/components/dashboard/OrdersDonut";
import { Heatmap } from "@/components/analytics/Heatmap";
import { ExportButton } from "@/components/shared/ExportButton";
import { analyticsApi } from "@/api/endpoints";

export const Route = createFileRoute("/admin/analytics/orders")({ component: OrderAnalyticsPage });

function OrderAnalyticsPage() {
  const ref = useRef<HTMLDivElement | null>(null);
  const status = useQuery({ queryKey: ["a-orders"], queryFn: analyticsApi.ordersStatus });
  const heatmap = useQuery({ queryKey: ["a-heat"], queryFn: analyticsApi.heatmap });

  return (
    <div className="space-y-6">
      <Button asChild variant="ghost" size="sm" className="gap-2 -ml-2"><Link to="/admin/analytics"><ArrowLeft className="h-4 w-4" /> Analytics</Link></Button>
      <PageHeader title="Order trends" description="Volume by status and density across hour × day." actions={
        <ExportButton targetRef={ref} filename="eets-orders-analytics" />
      } />
      <div ref={ref} className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-5 bg-card border-border">
          <h3 className="font-semibold mb-4">Order status mix</h3>
          <OrdersDonut data={status.data ?? []} />
        </Card>
        <Card className="p-5 bg-card border-border">
          <h3 className="font-semibold mb-4">Density · hour × day</h3>
          <Heatmap data={heatmap.data} />
        </Card>
      </div>
    </div>
  );
}
