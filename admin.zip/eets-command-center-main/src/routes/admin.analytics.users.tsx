import { createFileRoute, Link } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { PageHeader } from "@/components/shared/PageHeader";
import { DateRangePicker, type DateRange, rangeToDays } from "@/components/shared/DateRangePicker";
import { ExportButton } from "@/components/shared/ExportButton";
import { Funnel } from "@/components/analytics/Funnel";
import { analyticsApi } from "@/api/endpoints";
import { newRestaurantsSeries } from "@/lib/admin-mock";

export const Route = createFileRoute("/admin/analytics/users")({ component: UserAnalyticsPage });

function UserAnalyticsPage() {
  const [range, setRange] = useState<DateRange>("30d");
  const ref = useRef<HTMLDivElement | null>(null);
  const users = useQuery({ queryKey: ["a-users", range], queryFn: () => analyticsApi.users(rangeToDays(range)) });
  const rests = newRestaurantsSeries(8);

  return (
    <div className="space-y-6">
      <Button asChild variant="ghost" size="sm" className="gap-2 -ml-2"><Link to="/admin/analytics"><ArrowLeft className="h-4 w-4" /> Analytics</Link></Button>
      <PageHeader title="User acquisition" description="New users, new restaurants and conversion funnel." actions={<>
        <DateRangePicker value={range} onChange={setRange} />
        <ExportButton targetRef={ref} filename="eets-users-analytics" />
      </>} />
      <div ref={ref} className="space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card className="p-5 bg-card border-border">
            <h3 className="font-semibold mb-4">New users per day</h3>
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={users.data ?? []}>
                <CartesianGrid stroke="rgba(143,168,200,0.1)" vertical={false} />
                <XAxis dataKey="date" stroke="#8FA8C8" fontSize={11} />
                <YAxis stroke="#8FA8C8" fontSize={11} />
                <Tooltip contentStyle={{ background: "#0A1628", border: "1px solid rgba(143,168,200,0.2)", borderRadius: 8, color: "#fff" }} />
                <Line type="monotone" dataKey="users" stroke="#00C9B1" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </Card>
          <Card className="p-5 bg-card border-border">
            <h3 className="font-semibold mb-4">New restaurants per week</h3>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={rests}>
                <CartesianGrid stroke="rgba(143,168,200,0.1)" vertical={false} />
                <XAxis dataKey="week" stroke="#8FA8C8" fontSize={11} />
                <YAxis stroke="#8FA8C8" fontSize={11} />
                <Tooltip contentStyle={{ background: "#0A1628", border: "1px solid rgba(143,168,200,0.2)", borderRadius: 8, color: "#fff" }} />
                <Bar dataKey="count" fill="#26D07C" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>
        <Card className="p-5 bg-card border-border">
          <h3 className="font-semibold mb-4">Conversion funnel</h3>
          <Funnel />
        </Card>
      </div>
    </div>
  );
}
