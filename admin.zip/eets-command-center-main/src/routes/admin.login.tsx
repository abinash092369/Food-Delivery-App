import { createFileRoute, redirect, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useAdminAuth } from "@/store/adminAuth.store";
import logo from "@/assets/eets-logo.png";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

const schema = z.object({
  email: z.string().email("Enter a valid email"),
  password: z.string().min(4, "Password is required"),
});
type FormData = z.infer<typeof schema>;

export const Route = createFileRoute("/admin/login")({
  beforeLoad: () => {
    const { user } = useAdminAuth.getState();
    if (user) throw redirect({ to: "/admin/dashboard" });
  },
  component: LoginPage,
});

function LoginPage() {
  const login = useAdminAuth((s) => s.login);
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { email: "super@eets.app", password: "demo1234" },
  });

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      await login(data.email, data.password);
      toast.success("Welcome back");
      navigate({ to: "/admin/dashboard" });
    } catch {
      toast.error("Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4"
      style={{ background: "radial-gradient(circle at 20% 0%, rgba(0,201,177,0.12), transparent 50%), #0F1F3D" }}>
      <Card className="w-full max-w-md p-8 bg-card border-border">
        <div className="flex items-center gap-3 mb-8">
          <img src={logo} alt="eets" className="h-8 w-auto" />
          <span className="text-xs uppercase tracking-[0.25em] text-primary">Admin Console</span>
        </div>
        <h1 className="text-2xl font-bold">Sign in</h1>
        <p className="text-sm text-muted-foreground mt-1">Use your admin credentials to continue.</p>
        <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4">
          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" {...register("email")} className="bg-background border-border mt-1.5" />
            {errors.email && <p className="text-xs text-destructive mt-1">{errors.email.message}</p>}
          </div>
          <div>
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" {...register("password")} className="bg-background border-border mt-1.5" />
            {errors.password && <p className="text-xs text-destructive mt-1">{errors.password.message}</p>}
          </div>
          <Button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Sign in"}
          </Button>
        </form>
        <div className="mt-6 rounded-md bg-card-elevated/40 border border-border p-3 text-xs text-muted-foreground space-y-1">
          <p className="font-medium text-foreground">Demo accounts</p>
          <p><span className="text-primary">super@eets.app</span> — SUPER_ADMIN (all access)</p>
          <p><span className="text-primary">admin@eets.app</span> — ADMIN (no settings/fraud)</p>
          <p><span className="text-primary">support@eets.app</span> — SUPPORT (users + orders)</p>
          <p className="opacity-70">Any password works.</p>
        </div>
      </Card>
    </div>
  );
}
