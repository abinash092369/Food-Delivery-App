import { createFileRoute, Link } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { PageHeader } from "@/components/shared/PageHeader";
import { DateRangePicker, type DateRange, rangeToDays } from "@/components/shared/DateRangePicker";
import { ExportButton } from "@/components/shared/ExportButton";
import { RevenueChart } from "@/components/dashboard/RevenueChart";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { analyticsApi } from "@/api/endpoints";
import { aovTrend, revenueByRestaurant } from "@/lib/admin-mock";

export const Route = createFileRoute("/admin/analytics/revenue")({ component: RevenuePage });

function RevenuePage() {
  const [range, setRange] = useState<DateRange>("30d");
  const ref = useRef<HTMLDivElement | null>(null);
  const revenue = useQuery({ queryKey: ["a-rev", range], queryFn: () => analyticsApi.revenue(rangeToDays(range)) });
  const aov = aovTrend(rangeToDays(range));
  const top = revenueByRestaurant();

  return (
    <div className="space-y-6">
      <Button asChild variant="ghost" size="sm" className="gap-2 -ml-2"><Link to="/admin/analytics"><ArrowLeft className="h-4 w-4" /> Analytics</Link></Button>
      <PageHeader title="Revenue deep-dive" description="Track gross/net revenue, AOV and top earners." actions={<>
        <DateRangePicker value={range} onChange={setRange} />
        <ExportButton targetRef={ref} rows={revenue.data as unknown as Record<string, unknown>[]} filename="eets-revenue" />
      </>} />

      <div ref={ref} className="space-y-4">
        <Card className="p-5 bg-card border-border">
          <h3 className="font-semibold mb-4">Daily revenue</h3>
          <RevenueChart data={revenue.data ?? []} />
        </Card>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card className="p-5 bg-card border-border">
            <h3 className="font-semibold mb-4">Top 10 restaurants by revenue</h3>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={top} layout="vertical" margin={{ left: 80, right: 10 }}>
                <CartesianGrid stroke="rgba(143,168,200,0.1)" horizontal={false} />
                <XAxis type="number" stroke="#8FA8C8" fontSize={11} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                <YAxis type="category" dataKey="name" stroke="#8FA8C8" fontSize={11} width={80} />
                <Tooltip contentStyle={{ background: "#0A1628", border: "1px solid rgba(143,168,200,0.2)", borderRadius: 8, color: "#fff" }} formatter={(v) => `₹${Number(v).toLocaleString("en-IN")}`} />
                <Bar dataKey="revenue" fill="#00C9B1" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
          <Card className="p-5 bg-card border-border">
            <h3 className="font-semibold mb-4">Average order value trend</h3>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={aov}>
                <CartesianGrid stroke="rgba(143,168,200,0.1)" vertical={false} />
                <XAxis dataKey="date" stroke="#8FA8C8" fontSize={11} />
                <YAxis stroke="#8FA8C8" fontSize={11} />
                <Tooltip contentStyle={{ background: "#0A1628", border: "1px solid rgba(143,168,200,0.2)", borderRadius: 8, color: "#fff" }} />
                <Line type="monotone" dataKey="aov" stroke="#FAC775" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </div>
      </div>
    </div>
  );
}
