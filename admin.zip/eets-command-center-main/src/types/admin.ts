export type AdminRole = "SUPER_ADMIN" | "ADMIN" | "SUPPORT";

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: AdminRole;
  avatar?: string;
}

export interface PlatformUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar?: string;
  orders: number;
  joinedAt: string;
  status: "active" | "banned" | "unverified";
  totalSpend: number;
  city: string;
}

export interface AdminRestaurant {
  id: string;
  name: string;
  logo: string;
  owner: string;
  ownerEmail: string;
  cuisine: string;
  city: string;
  address: string;
  rating: number;
  orders: number;
  revenue: number;
  status: "active" | "suspended" | "pending";
  submittedAt: string;
}

export type OrderStatus =
  | "pending"
  | "preparing"
  | "on_the_way"
  | "delivered"
  | "cancelled";

export interface AdminOrder {
  id: string;
  customerId: string;
  customerName: string;
  restaurantId: string;
  restaurantName: string;
  items: { name: string; qty: number; price: number }[];
  amount: number;
  status: OrderStatus;
  paymentMethod: "card" | "upi" | "cod" | "wallet";
  address: string;
  createdAt: string;
  deliveredAt?: string;
  notes?: string;
  refund?: { amount: number; reason: string };
}

export interface DeliveryPartner {
  id: string;
  name: string;
  phone: string;
  city: string;
  vehicle: "bike" | "scooter" | "bicycle";
  rating: number;
  deliveries: number;
  status: "online" | "offline" | "busy" | "suspended";
  joinedAt: string;
}

export interface Coupon {
  id: string;
  code: string;
  type: "percentage" | "flat" | "free_delivery";
  value: number;
  maxDiscount?: number;
  minOrder: number;
  usageLimit: number;
  usagePerUser: number;
  used: number;
  validFrom: string;
  validTo: string;
  active: boolean;
  restaurants: string[] | "all";
}

export interface FraudAlert {
  id: string;
  orderId: string;
  customerId: string;
  customerName: string;
  reason: string;
  risk: "low" | "medium" | "high";
  detectedAt: string;
  status: "open" | "dismissed" | "investigating";
  amount: number;
}