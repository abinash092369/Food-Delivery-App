import axios from "axios";
import { useAdminAuth } from "@/store/adminAuth.store";

export const apiClient = axios.create({
  baseURL: "http://localhost:8080/api/admin",
  timeout: 8000,
});

apiClient.interceptors.request.use((config) => {
  const { token, user } = useAdminAuth.getState();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  if (user) config.headers["X-Admin-Role"] = user.role;
  return config;
});

apiClient.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err?.response?.status === 401) useAdminAuth.getState().logout();
    return Promise.reject(err);
  },
);

export async function withFallback<T>(call: () => Promise<T>, fallback: T): Promise<T> {
  try {
    return await call();
  } catch {
    return fallback;
  }
}