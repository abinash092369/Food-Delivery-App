import { apiClient, withFallback } from "./client";
import {
  mockUsers, mockRestaurants, mockOrders, mockDelivery, mockCoupons, mockFraud,
  revenueSeries, newUsersSeries, ordersByStatus, heatmapData,
} from "@/lib/admin-mock";
import type {
  PlatformUser, AdminRestaurant, AdminOrder, DeliveryPartner, Coupon, FraudAlert,
} from "@/types/admin";

export const usersApi = {
  list: (): Promise<PlatformUser[]> =>
    withFallback<PlatformUser[]>(() => apiClient.get("/users").then((r) => r.data), mockUsers),
  ban: (id: string, reason: string) =>
    withFallback<{ ok: boolean }>(() => apiClient.post(`/users/${id}/ban`, { reason }).then((r) => r.data), { ok: true }),
  unban: (id: string) =>
    withFallback<{ ok: boolean }>(() => apiClient.post(`/users/${id}/unban`).then((r) => r.data), { ok: true }),
  remove: (id: string) =>
    withFallback<{ ok: boolean }>(() => apiClient.delete(`/users/${id}`).then((r) => r.data), { ok: true }),
};

export const restaurantsApi = {
  list: (): Promise<AdminRestaurant[]> =>
    withFallback<AdminRestaurant[]>(() => apiClient.get("/restaurants").then((r) => r.data), mockRestaurants),
  pending: (): Promise<AdminRestaurant[]> => withFallback<AdminRestaurant[]>(
    () => apiClient.get("/restaurants/pending").then((r) => r.data),
    mockRestaurants.filter((r) => r.status === "pending"),
  ),
  approve: (id: string) =>
    withFallback<{ ok: boolean }>(() => apiClient.post(`/restaurants/${id}/approve`).then((r) => r.data), { ok: true }),
  reject: (id: string, reason: string) =>
    withFallback<{ ok: boolean }>(() => apiClient.post(`/restaurants/${id}/reject`, { reason }).then((r) => r.data), { ok: true }),
  suspend: (id: string) =>
    withFallback<{ ok: boolean }>(() => apiClient.put(`/restaurants/${id}`, { status: "suspended" }).then((r) => r.data), { ok: true }),
  remove: (id: string) =>
    withFallback<{ ok: boolean }>(() => apiClient.delete(`/restaurants/${id}`).then((r) => r.data), { ok: true }),
};

export const ordersApi = {
  list: (): Promise<AdminOrder[]> =>
    withFallback<AdminOrder[]>(() => apiClient.get("/orders").then((r) => r.data), mockOrders),
  get: (id: string): Promise<AdminOrder | undefined> => withFallback<AdminOrder | undefined>(
    () => apiClient.get(`/orders/${id}`).then((r) => r.data),
    mockOrders.find((o) => o.id === id),
  ),
  refund: (id: string, amount: number, reason: string) =>
    withFallback<{ ok: boolean }>(() => apiClient.post(`/orders/${id}/refund`, { amount, reason }).then((r) => r.data), { ok: true }),
  saveNotes: (id: string, notes: string) =>
    withFallback<{ ok: boolean }>(() => apiClient.put(`/orders/${id}/notes`, { notes }).then((r) => r.data), { ok: true }),
};

export const deliveryApi = {
  list: (): Promise<DeliveryPartner[]> =>
    withFallback<DeliveryPartner[]>(() => apiClient.get("/delivery").then((r) => r.data), mockDelivery),
};

export const couponsApi = {
  list: (): Promise<Coupon[]> =>
    withFallback<Coupon[]>(() => apiClient.get("/coupons").then((r) => r.data), mockCoupons),
  create: (data: unknown) =>
    withFallback<{ ok: boolean }>(() => apiClient.post("/coupons", data).then((r) => r.data), { ok: true }),
  update: (id: string, data: unknown) =>
    withFallback<{ ok: boolean }>(() => apiClient.put(`/coupons/${id}`, data).then((r) => r.data), { ok: true }),
  remove: (id: string) =>
    withFallback<{ ok: boolean }>(() => apiClient.delete(`/coupons/${id}`).then((r) => r.data), { ok: true }),
};

export const fraudApi = {
  list: (): Promise<FraudAlert[]> =>
    withFallback<FraudAlert[]>(() => apiClient.get("/fraud/flagged-orders").then((r) => r.data), mockFraud),
  dismiss: (id: string) =>
    withFallback<{ ok: boolean }>(() => apiClient.post(`/fraud/${id}/dismiss`).then((r) => r.data), { ok: true }),
  investigate: (id: string) =>
    withFallback<{ ok: boolean }>(() => apiClient.post(`/fraud/${id}/investigate`).then((r) => r.data), { ok: true }),
};

export const analyticsApi = {
  revenue: (days = 30): Promise<{ date: string; gross: number; net: number; refunds: number }[]> =>
    withFallback(() => apiClient.get(`/analytics/revenue?range=${days}`).then((r) => r.data), revenueSeries(days)),
  users: (days = 30): Promise<{ date: string; users: number }[]> =>
    withFallback(() => apiClient.get(`/analytics/users?range=${days}`).then((r) => r.data), newUsersSeries(days)),
  ordersStatus: (): Promise<{ name: string; value: number }[]> =>
    withFallback(() => apiClient.get(`/analytics/orders`).then((r) => r.data), ordersByStatus()),
  heatmap: (): Promise<{ day: string; hours: number[] }[]> =>
    withFallback(() => apiClient.get(`/analytics/heatmap`).then((r) => r.data), heatmapData()),
};
