import { funnelData } from "@/lib/admin-mock";

export function Funnel() {
  const data = funnelData();
  const max = data[0].value;
  return (
    <div className="space-y-2">
      {data.map((d, i) => {
        const width = (d.value / max) * 100;
        const conv = i > 0 ? Math.round((d.value / data[i - 1].value) * 100) : 100;
        return (
          <div key={d.stage} className="flex items-center gap-4">
            <span className="w-32 text-sm">{d.stage}</span>
            <div className="flex-1 h-9 rounded-md bg-card-elevated/40 overflow-hidden">
              <div
                className="h-full flex items-center px-3 text-xs font-medium text-primary-foreground"
                style={{ width: `${width}%`, background: "linear-gradient(90deg, #00C9B1, #0D7A6F)" }}
              >
                {d.value.toLocaleString()}
              </div>
            </div>
            <span className="w-12 text-right text-xs text-muted-foreground tabular-nums">{conv}%</span>
          </div>
        );
      })}
    </div>
  );
}
