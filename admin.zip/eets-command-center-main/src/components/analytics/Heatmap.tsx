import { heatmapData } from "@/lib/admin-mock";

export function Heatmap({ data = heatmapData() }: { data?: ReturnType<typeof heatmapData> }) {
  const max = Math.max(...data.flatMap((d) => d.hours));
  return (
    <div className="overflow-x-auto">
      <div className="min-w-[680px]">
        <div className="grid" style={{ gridTemplateColumns: "40px repeat(24, minmax(0, 1fr))" }}>
          <div />
          {Array.from({ length: 24 }, (_, h) => (
            <div key={h} className="text-[10px] text-center text-muted-foreground py-1">{h}</div>
          ))}
          {data.map((row) => (
            <div key={row.day} className="contents">
              <div className="text-xs text-muted-foreground flex items-center pr-2">{row.day}</div>
              {row.hours.map((v, i) => {
                const opacity = v / max;
                return (
                  <div
                    key={i}
                    title={`${row.day} ${i}:00 — ${v} orders`}
                    className="aspect-square rounded-sm m-[1px]"
                    style={{ background: `rgba(0, 201, 177, ${0.05 + opacity * 0.95})` }}
                  />
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
