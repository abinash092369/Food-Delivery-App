import { Bell, LogOut, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useAdminAuth } from "@/store/adminAuth.store";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import { useMemo } from "react";

export function AdminHeader() {
  const user = useAdminAuth((s) => s.user);
  const logout = useAdminAuth((s) => s.logout);
  const navigate = useNavigate();
  const path = useRouterState({ select: (s) => s.location.pathname });

  const crumbs = useMemo(
    () => path.split("/").filter(Boolean).map((s) => s.replace(/-/g, " ")),
    [path],
  );

  return (
    <header
      className="fixed left-60 right-0 top-0 z-20 flex items-center justify-between border-b border-border bg-background/80 px-6 backdrop-blur"
      style={{ height: 60 }}
    >
      <div className="flex items-center gap-2 text-sm text-muted-foreground capitalize">
        {crumbs.map((c, i) => (
          <span key={i} className="flex items-center gap-2">
            {i > 0 && <span>/</span>}
            <span className={i === crumbs.length - 1 ? "text-foreground font-medium" : ""}>{c}</span>
          </span>
        ))}
      </div>
      <div className="flex items-center gap-4">
        <div className="relative hidden md:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search..." className="pl-9 w-64 bg-card border-border" />
        </div>
        <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
          <Bell className="h-5 w-5" />
        </Button>
        {user && (
          <div className="flex items-center gap-3">
            <Avatar className="h-8 w-8">
              <AvatarImage src={user.avatar} />
              <AvatarFallback>{user.name.slice(0, 1)}</AvatarFallback>
            </Avatar>
            <div className="hidden sm:block leading-tight">
              <p className="text-sm font-medium">{user.name}</p>
              <p className="text-[10px] uppercase tracking-wider text-primary">{user.role}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => { logout(); navigate({ to: "/admin/login" }); }}
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
    </header>
  );
}
