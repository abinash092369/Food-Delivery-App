import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard, Users, Store, ShoppingBag, Bike, BarChart3, Ticket, ShieldAlert, Settings,
} from "lucide-react";
import logo from "@/assets/eets-logo.png";
import { useAdminAuth } from "@/store/adminAuth.store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard, key: "dashboard" as const },
  { to: "/admin/users", label: "Users", icon: Users, key: "users" as const },
  { to: "/admin/restaurants", label: "Restaurants", icon: Store, key: "restaurants" as const },
  { to: "/admin/orders", label: "Orders", icon: ShoppingBag, key: "orders" as const },
  { to: "/admin/delivery", label: "Delivery", icon: Bike, key: "delivery" as const },
  { to: "/admin/analytics", label: "Analytics", icon: BarChart3, key: "analytics" as const },
  { to: "/admin/coupons", label: "Coupons", icon: Ticket, key: "coupons" as const },
  { to: "/admin/fraud", label: "Fraud", icon: ShieldAlert, key: "fraud" as const },
  { to: "/admin/settings", label: "Settings", icon: Settings, key: "settings" as const },
];

export function AdminSidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const can = useAdminAuth((s) => s.can);

  return (
    <aside className="fixed inset-y-0 left-0 z-30 w-60 border-r border-border bg-sidebar text-sidebar-foreground">
      <div className="flex items-center gap-3 px-5 border-b border-border" style={{ height: 60 }}>
        <img src={logo} alt="eets" className="h-7 w-auto" />
        <span className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Admin</span>
      </div>
      <nav className="p-3 space-y-1">
        {NAV.filter((n) => can(n.key)).map((n) => {
          const active = pathname === n.to || pathname.startsWith(n.to + "/");
          const Icon = n.icon;
          return (
            <Link
              key={n.to}
              to={n.to}
              className={cn(
                "relative flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                active
                  ? "bg-sidebar-accent text-primary"
                  : "text-sidebar-foreground/80 hover:bg-white/5 hover:text-foreground",
              )}
            >
              {active && <span className="absolute left-0 top-1/2 h-6 w-0.5 -translate-y-1/2 rounded-r bg-primary" />}
              <Icon className="h-4 w-4" />
              {n.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
