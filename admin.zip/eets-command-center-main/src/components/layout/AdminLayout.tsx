import { Outlet } from "@tanstack/react-router";
import { AdminSidebar } from "./AdminSidebar";
import { AdminHeader } from "./AdminHeader";

export function AdminLayout() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <AdminSidebar />
      <AdminHeader />
      <main className="ml-60 pt-[60px]">
        <div className="p-6 max-w-[1600px] mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
