import { Card } from "@/components/ui/card";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";
import * as React from "react";

interface Props {
  label: string;
  value: string;
  delta?: number;
  hint?: string;
  icon?: React.ReactNode;
}

export function MetricCard({ label, value, delta, hint, icon }: Props) {
  const positive = (delta ?? 0) >= 0;
  return (
    <Card className="p-5 bg-card border-border">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</p>
          <p className="mt-2 text-3xl font-bold tracking-tight text-foreground">{value}</p>
        </div>
        {icon && <div className="rounded-lg bg-primary/10 p-2 text-primary">{icon}</div>}
      </div>
      {delta !== undefined && (
        <div className="mt-3 flex items-center gap-1.5 text-xs">
          <span className={cn("inline-flex items-center gap-0.5 font-medium", positive ? "text-positive" : "text-negative")}>
            {positive ? <ArrowUpRight className="h-3.5 w-3.5" /> : <ArrowDownRight className="h-3.5 w-3.5" />}
            {Math.abs(delta).toFixed(1)}%
          </span>
          <span className="text-muted-foreground">{hint ?? "vs yesterday"}</span>
        </div>
      )}
    </Card>
  );
}
