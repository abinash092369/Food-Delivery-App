import { Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";

const COLORS = ["#FAC775", "#1A2980", "#00C9B1", "#26D07C", "#E24B4A"];

export function OrdersDonut({ data }: { data: { name: string; value: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <PieChart>
        <Pie data={data} dataKey="value" nameKey="name" innerRadius={60} outerRadius={95} paddingAngle={2} stroke="none">
          {data.map((_, i) => (<Cell key={i} fill={COLORS[i % COLORS.length]} />))}
        </Pie>
        <Tooltip contentStyle={{ background: "#0A1628", border: "1px solid rgba(143,168,200,0.2)", borderRadius: 8, color: "#fff" }} />
        <Legend
          formatter={(v: string) => <span className="text-xs capitalize text-muted-foreground">{v.replace(/_/g, " ")}</span>}
          iconType="circle"
        />
      </PieChart>
    </ResponsiveContainer>
  );
}
