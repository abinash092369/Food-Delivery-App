import { useEffect, useState } from "react";
import { liveOrderBus } from "@/lib/admin-utils";
import { mockOrders } from "@/lib/admin-mock";
import type { AdminOrder } from "@/types/admin";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { fmtRel, inr } from "@/lib/admin-utils";

export function LiveFeed() {
  const [orders, setOrders] = useState<AdminOrder[]>(mockOrders.slice(0, 6));

  useEffect(() => {
    return liveOrderBus.subscribe((o) => setOrders((cur) => [o, ...cur].slice(0, 12)));
  }, []);

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      <div className="flex items-center justify-between px-5 py-3 border-b border-border bg-card-elevated/50">
        <h3 className="font-semibold">Live order feed</h3>
        <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
          <span className="relative flex h-2 w-2">
            <span className="absolute inset-0 animate-ping rounded-full bg-primary opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
          </span>
          Real-time
        </span>
      </div>
      <ul className="divide-y divide-border/60">
        {orders.map((o, idx) => (
          <li key={o.id + idx} className="flex items-center gap-4 px-5 py-3 row-hover">
            <span className="font-mono text-xs text-muted-foreground w-24 shrink-0">{o.id}</span>
            <span className="flex-1 truncate text-sm">{o.customerName}</span>
            <span className="flex-1 truncate text-sm text-muted-foreground">{o.restaurantName}</span>
            <span className="text-sm font-medium tabular-nums w-20 text-right">{inr(o.amount)}</span>
            <StatusBadge status={o.status} />
            <span className="w-28 text-right text-xs text-muted-foreground">{fmtRel(o.createdAt)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
