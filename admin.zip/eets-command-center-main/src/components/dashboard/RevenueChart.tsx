import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export function RevenueChart({ data }: { data: { date: string; gross: number; net: number; refunds: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <AreaChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
        <defs>
          <linearGradient id="gross" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#00C9B1" stopOpacity={0.5} />
            <stop offset="100%" stopColor="#00C9B1" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="net" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#1A2980" stopOpacity={0.5} />
            <stop offset="100%" stopColor="#1A2980" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke="rgba(143,168,200,0.12)" vertical={false} />
        <XAxis dataKey="date" stroke="#8FA8C8" fontSize={11} tickLine={false} axisLine={false} />
        <YAxis stroke="#8FA8C8" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
        <Tooltip
          contentStyle={{ background: "#0A1628", border: "1px solid rgba(143,168,200,0.2)", borderRadius: 8, color: "#fff" }}
          formatter={(v) => `₹${Number(v).toLocaleString("en-IN")}`}
        />
        <Area type="monotone" dataKey="gross" stroke="#00C9B1" strokeWidth={2} fill="url(#gross)" name="Gross" />
        <Area type="monotone" dataKey="net" stroke="#26D07C" strokeWidth={2} fill="url(#net)" name="Net" />
        <Area type="monotone" dataKey="refunds" stroke="#E24B4A" strokeWidth={1.5} fillOpacity={0} name="Refunds" />
      </AreaChart>
    </ResponsiveContainer>
  );
}
