import { statusTone, statusLabel } from "@/lib/admin-utils";
import { cn } from "@/lib/utils";

export function StatusBadge({ status, className }: { status: string; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium capitalize",
        statusTone[status] ?? "bg-muted text-muted-foreground border-border",
        className,
      )}
    >
      {statusLabel(status)}
    </span>
  );
}