import * as React from "react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Download } from "lucide-react";
import { exportToExcel, exportElementToPdf, exportElementToPng } from "@/lib/admin-utils";

interface Props {
  rows?: Record<string, unknown>[];
  targetRef?: React.RefObject<HTMLElement | null>;
  filename: string;
}

export function ExportButton({ rows, targetRef, filename }: Props) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Download className="h-4 w-4" />
          Export
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {rows && (
          <DropdownMenuItem onClick={() => exportToExcel(rows, filename)}>
            Excel (.xlsx)
          </DropdownMenuItem>
        )}
        {targetRef && (
          <>
            <DropdownMenuItem onClick={() => targetRef.current && exportElementToPng(targetRef.current, filename)}>
              PNG image
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => targetRef.current && exportElementToPdf(targetRef.current, filename)}>
              PDF document
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}