import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { MOCK_CATEGORIES, MOCK_DISHES, formatINR, type Dish } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Trash2, Pencil } from "lucide-react";

export const Route = createFileRoute("/vendor/menu/dishes")({
  component: DishesPage,
});

function DishesPage() {
  const [dishes, setDishes] = useState<Dish[]>(MOCK_DISHES);

  const toggle = (id: string, key: "available" | "featured") =>
    setDishes((arr) => arr.map((d) => (d.id === id ? { ...d, [key]: !d[key] } : d)));

  return (
    <div className="space-y-6">
      {MOCK_CATEGORIES.map((cat) => {
        const items = dishes.filter((d) => d.categoryId === cat.id);
        if (items.length === 0) return null;
        return (
          <Card key={cat.id} className="border-border bg-card p-5">
            <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-muted-foreground">{cat.name}</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-xs text-muted-foreground">
                  <tr className="border-b border-border">
                    <th className="py-2 text-left">Dish</th>
                    <th className="text-right">Price</th>
                    <th className="text-center">Type</th>
                    <th className="text-center">Available</th>
                    <th className="text-center">Featured</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {items.map((d) => (
                    <tr key={d.id} className="row-hover">
                      <td className="py-3">
                        <p className="font-medium">{d.name}</p>
                        <p className="text-xs text-muted-foreground">{d.description}</p>
                      </td>
                      <td className="text-right font-medium">{formatINR(d.price)}</td>
                      <td className="text-center">
                        <Badge variant="outline" className={d.veg ? "border-positive text-positive" : "border-destructive text-destructive"}>
                          {d.veg ? "Veg" : "Non-Veg"}
                        </Badge>
                      </td>
                      <td className="text-center">
                        <Switch checked={d.available} onCheckedChange={() => toggle(d.id, "available")} />
                      </td>
                      <td className="text-center">
                        <Button variant="ghost" size="icon" onClick={() => toggle(d.id, "featured")}>
                          <Star className={`h-4 w-4 ${d.featured ? "fill-warning text-warning" : "text-muted-foreground"}`} />
                        </Button>
                      </td>
                      <td className="text-right">
                        <Link to="/vendor/menu/add-dish" className="mr-1 inline-flex">
                          <Button variant="ghost" size="icon"><Pencil className="h-4 w-4" /></Button>
                        </Link>
                        <Button variant="ghost" size="icon" className="text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        );
      })}
    </div>
  );
}
