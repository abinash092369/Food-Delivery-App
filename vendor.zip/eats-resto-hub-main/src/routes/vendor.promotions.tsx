import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MOCK_PROMOS, type Promo } from "@/lib/mock-data";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/vendor/promotions")({
  component: PromosPage,
});

function PromosPage() {
  const [promos, setPromos] = useState<Promo[]>(MOCK_PROMOS);
  const [form, setForm] = useState({ code: "", type: "percent" as Promo["type"], value: "10", appliesTo: "Entire menu", expiry: "", limit: "100" });

  const create = () => {
    if (!form.code.trim()) { toast.error("Code is required"); return; }
    setPromos((p) => [
      { id: `p${Date.now()}`, code: form.code.toUpperCase(), type: form.type, value: Number(form.value), appliesTo: form.appliesTo, usage: 0, limit: Number(form.limit), expiry: form.expiry || "2026-12-31", active: true },
      ...p,
    ]);
    toast.success("Promo created");
    setForm({ code: "", type: "percent", value: "10", appliesTo: "Entire menu", expiry: "", limit: "100" });
  };

  const labelType = (t: Promo["type"], v: number) =>
    t === "percent" ? `${v}% off` : t === "flat" ? `₹${v} off` : t === "free_delivery" ? "Free delivery" : "Buy X Get Y";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Promotions</h1>
        <p className="text-sm text-muted-foreground">Drive more orders with codes, discounts, and limited-time offers.</p>
      </div>

      <Card className="border-border bg-card p-5">
        <h3 className="mb-4 font-semibold">Create promo</h3>
        <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-6">
          <Field label="Code"><Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="SAVE20" /></Field>
          <Field label="Type">
            <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v as Promo["type"] })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="percent">% off</SelectItem>
                <SelectItem value="flat">₹ flat</SelectItem>
                <SelectItem value="free_delivery">Free delivery</SelectItem>
                <SelectItem value="bxgy">Buy X Get Y</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="Value"><Input type="number" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} /></Field>
          <Field label="Applies to"><Input value={form.appliesTo} onChange={(e) => setForm({ ...form, appliesTo: e.target.value })} /></Field>
          <Field label="Usage limit"><Input type="number" value={form.limit} onChange={(e) => setForm({ ...form, limit: e.target.value })} /></Field>
          <Field label="Expiry"><Input type="date" value={form.expiry} onChange={(e) => setForm({ ...form, expiry: e.target.value })} /></Field>
        </div>
        <Button onClick={create} className="mt-4 bg-primary text-primary-foreground hover:bg-primary/90">
          <Plus className="mr-2 h-4 w-4" /> Create promo
        </Button>
      </Card>

      <Card className="border-border bg-card p-5">
        <h3 className="mb-3 font-semibold">Active promos</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs text-muted-foreground">
              <tr className="border-b border-border">
                <th className="py-2 text-left">Code</th>
                <th className="text-left">Type</th>
                <th className="text-left">Applies to</th>
                <th className="text-right">Usage</th>
                <th className="text-right">Expiry</th>
                <th className="text-center">Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {promos.map((p) => (
                <tr key={p.id} className="row-hover">
                  <td className="py-3 font-mono font-semibold">{p.code}</td>
                  <td>{labelType(p.type, p.value)}</td>
                  <td className="text-muted-foreground">{p.appliesTo}</td>
                  <td className="text-right">{p.usage} / {p.limit}</td>
                  <td className="text-right text-muted-foreground">{p.expiry}</td>
                  <td className="text-center">
                    <Badge variant="outline" className={p.active ? "border-positive text-positive" : "border-muted-foreground text-muted-foreground"}>
                      {p.active ? "Active" : "Paused"}
                    </Badge>
                  </td>
                  <td className="text-right">
                    <Button variant="ghost" size="icon" className="text-destructive"
                      onClick={() => { setPromos((arr) => arr.filter((x) => x.id !== p.id)); toast.success("Deleted"); }}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="space-y-2"><Label>{label}</Label>{children}</div>;
}
