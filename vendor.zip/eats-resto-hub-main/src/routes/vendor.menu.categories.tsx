import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { MOCK_CATEGORIES, type Category } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Trash2, GripVertical, Plus } from "lucide-react";
import {
  DndContext, type DragEndEvent, PointerSensor, useSensor, useSensors, closestCenter,
} from "@dnd-kit/core";
import { SortableContext, arrayMove, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { toast } from "sonner";

export const Route = createFileRoute("/vendor/menu/categories")({
  component: CategoriesPage,
});

function CategoriesPage() {
  const [cats, setCats] = useState<Category[]>(MOCK_CATEGORIES);
  const [newName, setNewName] = useState("");
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));

  const onDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const oldIdx = cats.findIndex((c) => c.id === active.id);
    const newIdx = cats.findIndex((c) => c.id === over.id);
    setCats(arrayMove(cats, oldIdx, newIdx));
    toast.success("Order updated");
  };

  const add = () => {
    if (!newName.trim()) return;
    setCats((c) => [...c, { id: `c${Date.now()}`, name: newName.trim(), available: true, order: c.length }]);
    setNewName("");
  };

  return (
    <Card className="border-border bg-card p-5">
      <div className="mb-4 flex gap-2">
        <Input
          placeholder="New category name"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && add()}
        />
        <Button onClick={add} className="bg-primary text-primary-foreground hover:bg-primary/90">
          <Plus className="mr-2 h-4 w-4" /> Add
        </Button>
      </div>

      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
        <SortableContext items={cats.map((c) => c.id)} strategy={verticalListSortingStrategy}>
          <div className="space-y-2">
            {cats.map((c) => (
              <SortableRow
                key={c.id}
                cat={c}
                onToggle={(v) => setCats((arr) => arr.map((x) => x.id === c.id ? { ...x, available: v } : x))}
                onRename={(name) => setCats((arr) => arr.map((x) => x.id === c.id ? { ...x, name } : x))}
                onDelete={() => { setCats((arr) => arr.filter((x) => x.id !== c.id)); toast.success("Deleted"); }}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>
    </Card>
  );
}

function SortableRow({
  cat, onToggle, onRename, onDelete,
}: { cat: Category; onToggle: (v: boolean) => void; onRename: (n: string) => void; onDelete: () => void }) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: cat.id });
  const style = { transform: CSS.Transform.toString(transform), transition };
  return (
    <div ref={setNodeRef} style={style} className="flex items-center gap-3 rounded-lg border border-border bg-card-elevated p-3">
      <button {...attributes} {...listeners} className="cursor-grab text-muted-foreground hover:text-foreground">
        <GripVertical className="h-4 w-4" />
      </button>
      <Input
        value={cat.name}
        onChange={(e) => onRename(e.target.value)}
        className="flex-1 border-0 bg-transparent"
      />
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        Available
        <Switch checked={cat.available} onCheckedChange={onToggle} />
      </div>
      <Button variant="ghost" size="icon" onClick={onDelete} className="text-destructive hover:text-destructive">
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  );
}
