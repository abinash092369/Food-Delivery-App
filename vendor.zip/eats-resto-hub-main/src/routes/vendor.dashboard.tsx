import { createFileRoute } from "@tanstack/react-router";
import { useOrdersStore } from "@/store/orders.store";
import { formatINR, MOCK_RESTAURANT, timeAgo } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShoppingBag, IndianRupee, Clock, Star, Plus } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/vendor/dashboard")({
  component: Dashboard,
});

function Dashboard() {
  const orders = useOrdersStore((s) => s.orders);
  const push = useOrdersStore((s) => s.pushSimulatedOrder);

  const todayOrders = orders.filter((o) => o.status !== "cancelled");
  const revenue = todayOrders.reduce((acc, o) => acc + o.total, 0);

  const incoming = orders.filter((o) => o.status === "incoming");
  const preparing = orders.filter((o) => o.status === "preparing");
  const ready = orders.filter((o) => o.status === "ready");

  const simulate = () => {
    const num = Math.floor(Math.random() * 9000 + 1000);
    push({
      id: `sim_${num}`,
      number: `#${12451 + num}`,
      customer: "Live Customer",
      phone: "+91 99999 00000",
      address: "12, Demo Street, Bangalore",
      items: [{ name: "Butter Chicken", qty: 1, price: 420 }, { name: "Garlic Naan", qty: 2, price: 80 }],
      total: 580,
      payment: "UPI",
      status: "incoming",
      placedAt: new Date().toISOString(),
    });
    toast.success("Simulated incoming order!");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{MOCK_RESTAURANT.name}</h1>
          <p className="text-sm text-muted-foreground">Welcome back — here's what's happening today.</p>
        </div>
        <Button onClick={simulate} className="bg-primary text-primary-foreground hover:bg-primary/90">
          <Plus className="mr-2 h-4 w-4" /> Simulate incoming order
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Kpi icon={<ShoppingBag />} label="Orders today" value={String(todayOrders.length)} />
        <Kpi icon={<IndianRupee />} label="Revenue today" value={formatINR(revenue)} />
        <Kpi icon={<Clock />} label="Avg prep time" value="18 min" />
        <Kpi icon={<Star />} label="Avg rating" value={String(MOCK_RESTAURANT.rating)} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Column title="Incoming" tint="text-warning" orders={incoming} />
        <Column title="Preparing" tint="text-primary" orders={preparing} />
        <Column title="Ready for pickup" tint="text-positive" orders={ready} />
      </div>
    </div>
  );
}

function Kpi({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <Card className="border-border bg-card p-5">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">{icon}</div>
        <div>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
          <p className="text-xl font-bold">{value}</p>
        </div>
      </div>
    </Card>
  );
}

function Column({
  title, tint, orders,
}: { title: string; tint: string; orders: ReturnType<typeof useOrdersStore.getState>["orders"] }) {
  return (
    <Card className="border-border bg-card p-4">
      <div className="mb-3 flex items-center justify-between">
        <h3 className={`font-semibold ${tint}`}>{title}</h3>
        <span className="text-xs text-muted-foreground">{orders.length}</span>
      </div>
      <div className="space-y-2">
        {orders.length === 0 && (
          <p className="rounded-lg border border-dashed border-border p-6 text-center text-xs text-muted-foreground">
            No orders here right now.
          </p>
        )}
        {orders.map((o) => (
          <div key={o.id} className="rounded-lg border border-border bg-card-elevated p-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="font-semibold">{o.number}</span>
              <span className="text-xs text-muted-foreground">{timeAgo(o.placedAt)}</span>
            </div>
            <p className="mt-1 text-xs text-muted-foreground">{o.items.map((i) => `${i.qty}× ${i.name}`).join(", ")}</p>
            <p className="mt-2 text-sm font-bold text-primary">{formatINR(o.total)}</p>
          </div>
        ))}
      </div>
    </Card>
  );
}
