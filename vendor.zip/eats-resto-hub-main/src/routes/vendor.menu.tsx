import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/vendor/menu")({
  component: MenuLayout,
});

const TABS = [
  { to: "/vendor/menu/categories", label: "Categories" },
  { to: "/vendor/menu/dishes", label: "Dishes" },
  { to: "/vendor/menu/add-dish", label: "Add dish" },
];

function MenuLayout() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const isIndex = path === "/vendor/menu";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Menu management</h1>
        <p className="text-sm text-muted-foreground">Reorder categories, manage dishes and build customizations.</p>
      </div>
      <div className="flex gap-1 border-b border-border">
        {TABS.map((t) => {
          const active = path === t.to || (isIndex && t.to === "/vendor/menu/categories");
          return (
            <Link
              key={t.to}
              to={t.to}
              className={cn(
                "border-b-2 px-4 py-2 text-sm transition-colors",
                active ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground",
              )}
            >
              {t.label}
            </Link>
          );
        })}
      </div>
      {isIndex ? <CategoriesPlaceholder /> : <Outlet />}
    </div>
  );
}

function CategoriesPlaceholder() {
  return (
    <p className="text-sm text-muted-foreground">Pick a tab above to get started.</p>
  );
}
