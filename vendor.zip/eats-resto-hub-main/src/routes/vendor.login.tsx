import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useVendorAuth } from "@/store/vendorAuth.store";
import logo from "@/assets/eets-logo.png";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";

export const Route = createFileRoute("/vendor/login")({
  component: VendorLogin,
});

function VendorLogin() {
  const [email, setEmail] = useState("kabir@spicesymphony.in");
  const [password, setPassword] = useState("password");
  const login = useVendorAuth((s) => s.login);
  const navigate = useNavigate();

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Enter your email and password");
      return;
    }
    login(email, password);
    toast.success("Welcome back");
    navigate({ to: "/vendor/dashboard" });
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <form
        onSubmit={onSubmit}
        className="w-full max-w-md rounded-2xl border border-border bg-card p-8 shadow-2xl"
      >
        <div className="mb-8 flex flex-col items-center gap-3">
          <img src={logo} alt="eets" className="h-10" />
          <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Restaurant Partner</p>
        </div>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Email</Label>
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@restaurant.com" />
          </div>
          <div className="space-y-2">
            <Label>Password</Label>
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <Button type="submit" className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
            Sign in
          </Button>
        </div>
        <p className="mt-6 text-center text-sm text-muted-foreground">
          New restaurant?{" "}
          <Link to="/vendor/register" className="text-primary hover:underline">Register here</Link>
        </p>
      </form>
    </div>
  );
}
