import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  earningsTrend, earningsByCategory, formatINR, MOCK_PAYOUTS,
} from "@/lib/mock-data";
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { Download } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/vendor/earnings")({
  component: EarningsPage,
});

function EarningsPage() {
  const total = MOCK_PAYOUTS.reduce((a, p) => a + p.net, 0);
  const pending = MOCK_PAYOUTS.filter((p) => p.status !== "Paid").reduce((a, p) => a + p.net, 0);
  const monthly = 87656;
  const completed = MOCK_PAYOUTS.reduce((a, p) => a + p.orders, 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Earnings & payouts</h1>
        <p className="text-sm text-muted-foreground">Track your weekly settlements and per-category performance.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Kpi label="Total earnings" value={formatINR(total)} />
        <Kpi label="This month" value={formatINR(monthly)} />
        <Kpi label="Pending payout" value={formatINR(pending)} accent />
        <Kpi label="Completed orders" value={String(completed)} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="border-border bg-card p-5 lg:col-span-2">
          <h3 className="mb-4 font-semibold">Daily earnings · last 30 days</h3>
          <div className="h-72">
            <ResponsiveContainer>
              <AreaChart data={earningsTrend}>
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#00C9B1" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#00C9B1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="rgba(143,168,200,0.1)" />
                <XAxis dataKey="day" stroke="#8FA8C8" fontSize={11} />
                <YAxis stroke="#8FA8C8" fontSize={11} />
                <Tooltip contentStyle={{ background: "#162847", border: "1px solid rgba(143,168,200,0.2)", borderRadius: 8 }} />
                <Area type="monotone" dataKey="earnings" stroke="#00C9B1" fill="url(#g1)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="border-border bg-card p-5">
          <h3 className="mb-4 font-semibold">Earnings by category</h3>
          <div className="h-72">
            <ResponsiveContainer>
              <BarChart data={earningsByCategory} layout="vertical">
                <CartesianGrid stroke="rgba(143,168,200,0.1)" />
                <XAxis type="number" stroke="#8FA8C8" fontSize={11} />
                <YAxis type="category" dataKey="name" stroke="#8FA8C8" fontSize={11} width={80} />
                <Tooltip contentStyle={{ background: "#162847", border: "1px solid rgba(143,168,200,0.2)", borderRadius: 8 }} />
                <Bar dataKey="value" fill="#00C9B1" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <Card className="border-border bg-card p-5">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-semibold">Payout history</h3>
          <Button variant="outline" size="sm" onClick={() => toast.success("Exported to Excel")}>
            <Download className="mr-2 h-4 w-4" /> Export
          </Button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs text-muted-foreground">
              <tr className="border-b border-border">
                <th className="py-2 text-left">Period</th>
                <th className="text-right">Orders</th>
                <th className="text-right">Gross</th>
                <th className="text-right">Commission</th>
                <th className="text-right">Net</th>
                <th className="text-center">Status</th>
                <th className="text-right">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {MOCK_PAYOUTS.map((p) => (
                <tr key={p.id} className="row-hover">
                  <td className="py-3">{p.period}</td>
                  <td className="text-right">{p.orders}</td>
                  <td className="text-right">{formatINR(p.gross)}</td>
                  <td className="text-right text-muted-foreground">{p.commissionPct}%</td>
                  <td className="text-right font-semibold text-positive">{formatINR(p.net)}</td>
                  <td className="text-center">
                    <Badge variant="outline" className={
                      p.status === "Paid" ? "border-positive text-positive" :
                      p.status === "Processing" ? "border-warning text-warning" :
                      "border-muted-foreground text-muted-foreground"
                    }>{p.status}</Badge>
                  </td>
                  <td className="text-right text-muted-foreground">{p.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function Kpi({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <Card className="border-border bg-card p-5">
      <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className={`mt-1 text-2xl font-bold ${accent ? "text-warning" : ""}`}>{value}</p>
    </Card>
  );
}
