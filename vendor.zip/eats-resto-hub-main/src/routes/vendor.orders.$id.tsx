import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { useOrdersStore } from "@/store/orders.store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatINR, timeAgo } from "@/lib/mock-data";
import { ArrowLeft, Phone, MapPin } from "lucide-react";

export const Route = createFileRoute("/vendor/orders/$id")({
  component: OrderDetail,
});

function OrderDetail() {
  const { id } = useParams({ from: "/vendor/orders/$id" });
  const order = useOrdersStore((s) => s.orders.find((o) => o.id === id));

  if (!order) {
    return (
      <div>
        <Link to="/vendor/orders" className="text-sm text-muted-foreground hover:text-foreground">← Back to orders</Link>
        <p className="mt-6 text-muted-foreground">Order not found.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Link to="/vendor/orders" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back to orders
      </Link>

      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-bold">{order.number}</h1>
          <p className="text-sm text-muted-foreground">Placed {timeAgo(order.placedAt)} · {order.payment}</p>
        </div>
        <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase text-primary">{order.status.replace("_", " ")}</span>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="border-border bg-card p-5 lg:col-span-2">
          <h3 className="mb-3 font-semibold">Items</h3>
          <div className="divide-y divide-border">
            {order.items.map((it, i) => (
              <div key={i} className="flex items-center justify-between py-3 text-sm">
                <span>{it.qty}× {it.name}</span>
                <span className="font-medium">{formatINR(it.price * it.qty)}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex items-center justify-between border-t border-border pt-3">
            <span className="text-muted-foreground">Total</span>
            <span className="text-xl font-bold text-primary">{formatINR(order.total)}</span>
          </div>
          {order.instructions && (
            <div className="mt-4 rounded-lg bg-secondary p-3 text-sm">
              <p className="text-xs uppercase text-muted-foreground">Special instructions</p>
              <p className="mt-1">{order.instructions}</p>
            </div>
          )}
        </Card>

        <Card className="border-border bg-card p-5">
          <h3 className="mb-3 font-semibold">Customer</h3>
          <p className="text-sm font-medium">{order.customer}</p>
          <a href={`tel:${order.phone}`} className="mt-2 flex items-center gap-2 text-sm text-primary">
            <Phone className="h-4 w-4" /> {order.phone}
          </a>
          <div className="mt-4 flex gap-2 text-sm">
            <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
            <p>{order.address}</p>
          </div>
          <Button className="mt-5 w-full bg-primary text-primary-foreground hover:bg-primary/90">
            Contact support
          </Button>
        </Card>
      </div>
    </div>
  );
}
