import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/vendor/register")({
  component: VendorRegister,
});

const STEPS = ["Basic Info", "Location", "Timing", "Documents", "Bank", "Review"];

function VendorRegister() {
  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: "", cuisines: "", description: "",
    address: "", city: "", pincode: "",
    open: "10:00", close: "23:00",
    fssai: "", gst: "",
    holder: "", account: "", ifsc: "", upi: "",
  });

  const set = (k: keyof typeof form, v: string) => setForm((f) => ({ ...f, [k]: v }));

  if (submitted) {
    return (
      <div className="flex min-h-screen items-center justify-center px-4">
        <div className="max-w-md rounded-2xl border border-border bg-card p-10 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
            <Check className="h-7 w-7 text-primary" />
          </div>
          <h2 className="text-2xl font-bold">Under Review</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Thanks! Our team is reviewing your application — you'll hear back within 24 hours.
          </p>
          <Button className="mt-6" onClick={() => navigate({ to: "/vendor/login" })}>Back to login</Button>
        </div>
      </div>
    );
  }

  const next = () => setStep((s) => Math.min(STEPS.length - 1, s + 1));
  const prev = () => setStep((s) => Math.max(0, s - 1));
  const submit = () => { setSubmitted(true); toast.success("Application submitted"); };

  return (
    <div className="min-h-screen bg-background px-4 py-10">
      <div className="mx-auto max-w-2xl">
        <Link to="/vendor/login" className="text-sm text-muted-foreground hover:text-foreground">← Back to login</Link>
        <h1 className="mt-4 text-3xl font-bold">Register your restaurant</h1>

        <div className="my-6 flex gap-2">
          {STEPS.map((s, i) => (
            <div key={s} className="flex-1">
              <div className={cn("h-1 rounded-full", i <= step ? "bg-primary" : "bg-secondary")} />
              <p className={cn("mt-2 text-[11px]", i === step ? "text-foreground" : "text-muted-foreground")}>{s}</p>
            </div>
          ))}
        </div>

        <div className="rounded-2xl border border-border bg-card p-6">
          {step === 0 && (
            <div className="space-y-4">
              <Field label="Restaurant name"><Input value={form.name} onChange={(e) => set("name", e.target.value)} /></Field>
              <Field label="Cuisines (comma separated)"><Input value={form.cuisines} onChange={(e) => set("cuisines", e.target.value)} placeholder="North Indian, Chinese" /></Field>
              <Field label="Description"><Textarea value={form.description} onChange={(e) => set("description", e.target.value)} rows={3} /></Field>
            </div>
          )}
          {step === 1 && (
            <div className="space-y-4">
              <div className="rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
                📍 Map picker placeholder — drop a pin to set restaurant location
              </div>
              <Field label="Address"><Input value={form.address} onChange={(e) => set("address", e.target.value)} /></Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="City"><Input value={form.city} onChange={(e) => set("city", e.target.value)} /></Field>
                <Field label="Pincode"><Input value={form.pincode} onChange={(e) => set("pincode", e.target.value)} /></Field>
              </div>
            </div>
          )}
          {step === 2 && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Same hours apply for all days — customize per-day later in profile.</p>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Opens"><Input type="time" value={form.open} onChange={(e) => set("open", e.target.value)} /></Field>
                <Field label="Closes"><Input type="time" value={form.close} onChange={(e) => set("close", e.target.value)} /></Field>
              </div>
            </div>
          )}
          {step === 3 && (
            <div className="space-y-4">
              <Field label="FSSAI license number"><Input value={form.fssai} onChange={(e) => set("fssai", e.target.value)} /></Field>
              <Field label="GST number"><Input value={form.gst} onChange={(e) => set("gst", e.target.value)} /></Field>
              <div className="rounded-lg border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
                📄 Drop FSSAI certificate here (PDF / JPG)
              </div>
            </div>
          )}
          {step === 4 && (
            <div className="space-y-4">
              <Field label="Account holder"><Input value={form.holder} onChange={(e) => set("holder", e.target.value)} /></Field>
              <Field label="Account number"><Input value={form.account} onChange={(e) => set("account", e.target.value)} /></Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="IFSC"><Input value={form.ifsc} onChange={(e) => set("ifsc", e.target.value)} /></Field>
                <Field label="UPI ID"><Input value={form.upi} onChange={(e) => set("upi", e.target.value)} /></Field>
              </div>
            </div>
          )}
          {step === 5 && (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">Review your details before submitting.</p>
              {Object.entries(form).map(([k, v]) => (
                <div key={k} className="flex justify-between border-b border-border py-2 text-sm">
                  <span className="capitalize text-muted-foreground">{k}</span>
                  <span className="font-medium">{v || "—"}</span>
                </div>
              ))}
            </div>
          )}

          <div className="mt-6 flex justify-between">
            <Button variant="ghost" onClick={prev} disabled={step === 0}>Back</Button>
            {step < STEPS.length - 1 ? (
              <Button onClick={next} className="bg-primary text-primary-foreground hover:bg-primary/90">Continue</Button>
            ) : (
              <Button onClick={submit} className="bg-primary text-primary-foreground hover:bg-primary/90">Submit application</Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      {children}
    </div>
  );
}
