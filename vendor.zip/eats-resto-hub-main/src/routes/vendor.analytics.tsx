import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import {
  Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { peakHours, topDishes } from "@/lib/mock-data";

export const Route = createFileRoute("/vendor/analytics")({
  component: AnalyticsPage,
});

function AnalyticsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Performance analytics</h1>
        <p className="text-sm text-muted-foreground">Identify what your customers love and when they order.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Kpi label="30-day orders" value="892" />
        <Kpi label="Avg basket" value="₹542" />
        <Kpi label="Repeat rate" value="38%" />
        <Kpi label="Acceptance rate" value="98%" />
      </div>

      <Card className="border-border bg-card p-5">
        <h3 className="mb-4 font-semibold">Peak ordering hours</h3>
        <div className="h-72">
          <ResponsiveContainer>
            <BarChart data={peakHours}>
              <CartesianGrid stroke="rgba(143,168,200,0.1)" />
              <XAxis dataKey="hour" stroke="#8FA8C8" fontSize={11} />
              <YAxis stroke="#8FA8C8" fontSize={11} />
              <Tooltip contentStyle={{ background: "#162847", border: "1px solid rgba(143,168,200,0.2)", borderRadius: 8 }} />
              <Bar dataKey="orders" fill="#00C9B1" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card className="border-border bg-card p-5">
        <h3 className="mb-4 font-semibold">Top dishes (last 30 days)</h3>
        <div className="space-y-3">
          {topDishes.map((d) => {
            const max = topDishes[0].orders;
            return (
              <div key={d.name}>
                <div className="mb-1 flex justify-between text-sm">
                  <span>{d.name}</span>
                  <span className="text-muted-foreground">{d.orders} orders</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-secondary">
                  <div className="h-full bg-primary" style={{ width: `${(d.orders / max) * 100}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

function Kpi({ label, value }: { label: string; value: string }) {
  return (
    <Card className="border-border bg-card p-5">
      <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-1 text-2xl font-bold">{value}</p>
    </Card>
  );
}
