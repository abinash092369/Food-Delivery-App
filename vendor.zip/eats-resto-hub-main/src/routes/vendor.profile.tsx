import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { MOCK_RESTAURANT } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/vendor/profile")({
  component: ProfilePage,
});

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

function ProfilePage() {
  const [name, setName] = useState(MOCK_RESTAURANT.name);
  const [desc, setDesc] = useState("Authentic North Indian cuisine since 2014.");
  const [hours, setHours] = useState(
    DAYS.map((d) => ({ day: d, open: "10:00", close: "23:00", closed: false })),
  );

  const save = () => toast.success("Profile updated");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Restaurant profile</h1>
        <p className="text-sm text-muted-foreground">Manage your public listing details.</p>
      </div>

      <Card className="border-border bg-card p-5">
        <h3 className="mb-4 font-semibold">Basic info</h3>
        <div className="grid gap-4 md:grid-cols-2">
          <Field label="Restaurant name"><Input value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <Field label="Cuisines"><Input defaultValue={MOCK_RESTAURANT.cuisine.join(", ")} /></Field>
          <div className="md:col-span-2">
            <Field label="Description"><Textarea rows={3} value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
          </div>
        </div>
      </Card>

      <Card className="border-border bg-card p-5">
        <h3 className="mb-4 font-semibold">Operating hours</h3>
        <div className="space-y-2">
          {hours.map((h, i) => (
            <div key={h.day} className="grid grid-cols-5 items-center gap-3 rounded-lg border border-border bg-card-elevated p-3">
              <p className="font-medium">{h.day}</p>
              <Input type="time" value={h.open} disabled={h.closed} onChange={(e) => setHours((arr) => arr.map((x, j) => j === i ? { ...x, open: e.target.value } : x))} />
              <Input type="time" value={h.close} disabled={h.closed} onChange={(e) => setHours((arr) => arr.map((x, j) => j === i ? { ...x, close: e.target.value } : x))} />
              <div className="col-span-2 flex items-center justify-end gap-2 text-sm text-muted-foreground">
                Closed
                <Switch checked={h.closed} onCheckedChange={(v) => setHours((arr) => arr.map((x, j) => j === i ? { ...x, closed: v } : x))} />
              </div>
            </div>
          ))}
        </div>
      </Card>

      <div className="flex justify-end">
        <Button onClick={save} className="bg-primary text-primary-foreground hover:bg-primary/90">Save changes</Button>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="space-y-2"><Label>{label}</Label>{children}</div>;
}
