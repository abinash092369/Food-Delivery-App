import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Star, Reply } from "lucide-react";
import { MOCK_REVIEWS, ratingDistribution, timeAgo, type Review } from "@/lib/mock-data";
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";
import { toast } from "sonner";

export const Route = createFileRoute("/vendor/reviews")({
  component: ReviewsPage,
});

function ReviewsPage() {
  const [reviews, setReviews] = useState<Review[]>(MOCK_REVIEWS);
  const [replying, setReplying] = useState<Review | null>(null);
  const [reply, setReply] = useState("");

  const avg = (reviews.reduce((a, r) => a + r.rating, 0) / reviews.length).toFixed(1);

  const sendReply = () => {
    if (!replying) return;
    setReviews((arr) => arr.map((r) => (r.id === replying.id ? { ...r, reply } : r)));
    setReplying(null); setReply("");
    toast.success("Reply posted");
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Customer reviews</h1>
        <p className="text-sm text-muted-foreground">Reply to feedback to build trust with your customers.</p>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="border-border bg-card p-5">
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Overall rating</p>
          <p className="mt-2 text-5xl font-bold">{avg}</p>
          <div className="mt-2 flex gap-0.5">
            {[1, 2, 3, 4, 5].map((s) => (
              <Star key={s} className={`h-5 w-5 ${s <= Math.round(Number(avg)) ? "fill-warning text-warning" : "text-muted-foreground"}`} />
            ))}
          </div>
          <p className="mt-2 text-xs text-muted-foreground">Across 1,284 reviews</p>
        </Card>

        <Card className="border-border bg-card p-5 lg:col-span-2">
          <h3 className="mb-3 font-semibold">Star distribution</h3>
          <div className="h-44">
            <ResponsiveContainer>
              <BarChart data={ratingDistribution} layout="vertical">
                <XAxis type="number" stroke="#8FA8C8" fontSize={11} />
                <YAxis type="category" dataKey="stars" stroke="#8FA8C8" fontSize={11} width={40} />
                <Tooltip contentStyle={{ background: "#162847", border: "1px solid rgba(143,168,200,0.2)", borderRadius: 8 }} />
                <Bar dataKey="count" fill="#FAC775" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <div className="space-y-3">
        {reviews.map((r) => (
          <Card key={r.id} className="border-border bg-card p-5">
            <div className="flex items-start gap-4">
              <Avatar><AvatarFallback>{r.customer.slice(0, 1)}</AvatarFallback></Avatar>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">{r.customer}</p>
                    <p className="text-xs text-muted-foreground">{timeAgo(r.date)} · {r.items.join(", ")}</p>
                  </div>
                  <div className="flex gap-0.5">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star key={s} className={`h-4 w-4 ${s <= r.rating ? "fill-warning text-warning" : "text-muted-foreground"}`} />
                    ))}
                  </div>
                </div>
                <p className="mt-2 text-sm">{r.text}</p>
                {r.reply && (
                  <div className="mt-3 rounded-lg bg-primary/5 border border-primary/20 p-3 text-sm">
                    <p className="text-xs font-semibold uppercase text-primary">Your reply</p>
                    <p className="mt-1">{r.reply}</p>
                  </div>
                )}
                {!r.reply && (
                  <Button size="sm" variant="outline" className="mt-3"
                    onClick={() => { setReplying(r); setReply(""); }}>
                    <Reply className="mr-2 h-4 w-4" /> Reply
                  </Button>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Dialog open={!!replying} onOpenChange={(o) => !o && setReplying(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Reply to {replying?.customer}</DialogTitle></DialogHeader>
          <p className="rounded-lg bg-secondary p-3 text-sm">{replying?.text}</p>
          <Textarea value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Write a thoughtful reply..." rows={4} />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setReplying(null)}>Cancel</Button>
            <Button onClick={sendReply} className="bg-primary text-primary-foreground hover:bg-primary/90" disabled={!reply.trim()}>
              Post reply
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
