import { createFileRoute, Link } from "@tanstack/react-router";
import { useOrdersStore } from "@/store/orders.store";
import { formatINR, timeAgo, type OrderStatus } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  DndContext, type DragEndEvent, PointerSensor, useSensor, useSensors,
  useDraggable, useDroppable,
} from "@dnd-kit/core";
import { toast } from "sonner";

export const Route = createFileRoute("/vendor/orders")({
  component: OrdersBoard,
});

const COLUMNS: { id: OrderStatus; label: string; tint: string }[] = [
  { id: "incoming", label: "Incoming", tint: "text-warning" },
  { id: "preparing", label: "Preparing", tint: "text-primary" },
  { id: "ready", label: "Ready", tint: "text-positive" },
  { id: "picked_up", label: "Picked Up", tint: "text-chart-2" },
  { id: "completed", label: "Completed", tint: "text-muted-foreground" },
  { id: "cancelled", label: "Cancelled", tint: "text-destructive" },
];

function OrdersBoard() {
  const orders = useOrdersStore((s) => s.orders);
  const updateStatus = useOrdersStore((s) => s.updateStatus);
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));

  const onDragEnd = (e: DragEndEvent) => {
    const orderId = String(e.active.id);
    const target = e.over?.id as OrderStatus | undefined;
    if (!target) return;
    updateStatus(orderId, target);
    toast.success(`Order moved to ${COLUMNS.find((c) => c.id === target)?.label}`);
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Live Orders</h1>
        <p className="text-sm text-muted-foreground">Drag cards between columns to update status.</p>
      </div>

      <DndContext sensors={sensors} onDragEnd={onDragEnd}>
        <div className="grid gap-3 lg:grid-cols-3 xl:grid-cols-6">
          {COLUMNS.map((col) => {
            const colOrders = orders.filter((o) => o.status === col.id);
            return <Column key={col.id} {...col} orders={colOrders} />;
          })}
        </div>
      </DndContext>
    </div>
  );
}

function Column({
  id, label, tint, orders,
}: { id: OrderStatus; label: string; tint: string; orders: ReturnType<typeof useOrdersStore.getState>["orders"] }) {
  const { setNodeRef, isOver } = useDroppable({ id });
  return (
    <Card
      ref={setNodeRef}
      className={`border-border bg-card p-3 transition-colors ${isOver ? "ring-2 ring-primary" : ""}`}
    >
      <div className="mb-3 flex items-center justify-between">
        <h3 className={`text-sm font-semibold ${tint}`}>{label}</h3>
        <span className="text-xs text-muted-foreground">{orders.length}</span>
      </div>
      <div className="min-h-[200px] space-y-2">
        {orders.map((o) => <OrderCard key={o.id} order={o} />)}
        {orders.length === 0 && (
          <div className="rounded-lg border border-dashed border-border p-4 text-center text-[11px] text-muted-foreground">
            Drop here
          </div>
        )}
      </div>
    </Card>
  );
}

function OrderCard({ order }: { order: ReturnType<typeof useOrdersStore.getState>["orders"][number] }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({ id: order.id });
  const setPrep = useOrdersStore((s) => s.setPrep);
  const updateStatus = useOrdersStore((s) => s.updateStatus);
  const style = transform
    ? { transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`, opacity: isDragging ? 0.6 : 1 }
    : { opacity: isDragging ? 0.6 : 1 };

  const nextAction: Record<string, { label: string; next: OrderStatus } | undefined> = {
    incoming: { label: "Start Preparing", next: "preparing" },
    preparing: { label: "Mark Ready", next: "ready" },
    ready: { label: "Mark Picked Up", next: "picked_up" },
    picked_up: { label: "Mark Completed", next: "completed" },
  };
  const action = nextAction[order.status];

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="cursor-grab rounded-lg border border-border bg-card-elevated p-3 active:cursor-grabbing"
    >
      <div {...listeners} {...attributes}>
        <div className="flex items-center justify-between">
          <Link to="/vendor/orders/$id" params={{ id: order.id }} className="text-sm font-semibold hover:text-primary">
            {order.number}
          </Link>
          <span className="text-[10px] text-muted-foreground">{timeAgo(order.placedAt)}</span>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">{order.customer}</p>
        <p className="mt-1 truncate text-xs">{order.items.map((i) => `${i.qty}× ${i.name}`).join(", ")}</p>
        <div className="mt-2 flex items-center justify-between">
          <span className="text-sm font-bold text-primary">{formatINR(order.total)}</span>
          <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px]">{order.payment}</span>
        </div>
      </div>
      {(order.status === "preparing" || order.status === "incoming") && (
        <Select
          value={String(order.prepMinutes ?? 20)}
          onValueChange={(v) => setPrep(order.id, Number(v))}
        >
          <SelectTrigger className="mt-2 h-7 text-xs"><SelectValue placeholder="Prep time" /></SelectTrigger>
          <SelectContent>
            {[10, 15, 20, 25, 30].map((m) => (
              <SelectItem key={m} value={String(m)}>{m} min</SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
      {action && (
        <Button
          size="sm"
          className="mt-2 h-7 w-full bg-primary text-xs text-primary-foreground hover:bg-primary/90"
          onClick={() => updateStatus(order.id, action.next)}
        >
          {action.label}
        </Button>
      )}
    </div>
  );
}
