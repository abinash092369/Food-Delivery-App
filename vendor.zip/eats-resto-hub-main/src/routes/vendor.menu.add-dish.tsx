import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { MOCK_CATEGORIES } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Plus, Trash2, Upload, GripVertical } from "lucide-react";
import { toast } from "sonner";
import {
  DndContext, type DragEndEvent, PointerSensor, useSensor, useSensors, closestCenter,
} from "@dnd-kit/core";
import { SortableContext, arrayMove, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

export const Route = createFileRoute("/vendor/menu/add-dish")({
  component: AddDishPage,
});

interface OptionItem { id: string; name: string; price: number }
interface CustomGroup {
  id: string;
  name: string;
  type: "single" | "multi";
  required: boolean;
  options: OptionItem[];
}

function AddDishPage() {
  const navigate = useNavigate();
  const [dirty, setDirty] = useState(false);
  const [form, setForm] = useState({
    name: "", categoryId: MOCK_CATEGORIES[0]?.id ?? "",
    description: "", price: "",
    veg: "veg", available: true, image: "",
  });
  const [groups, setGroups] = useState<CustomGroup[]>([]);

  // Unsaved changes warning
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (dirty) { e.preventDefault(); e.returnValue = ""; }
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [dirty]);

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => {
    setForm((f) => ({ ...f, [k]: v }));
    setDirty(true);
  };

  const handleImage = (file: File) => {
    if (file.size > 5 * 1024 * 1024) { toast.error("Image must be under 5MB"); return; }
    const reader = new FileReader();
    reader.onload = () => { set("image", String(reader.result || "")); toast.success("Image attached"); };
    reader.onerror = () => toast.error("Failed to read image");
    reader.readAsDataURL(file);
  };

  const submit = () => {
    if (!form.name.trim()) { toast.error("Dish name is required"); return; }
    if (!form.price || Number(form.price) <= 0) { toast.error("Enter a valid price"); return; }
    if (form.description.length > 200) { toast.error("Description max 200 chars"); return; }
    setDirty(false);
    toast.success("Dish saved");
    navigate({ to: "/vendor/menu/dishes" });
  };

  const addGroup = () =>
    setGroups((g) => [...g, { id: `g${Date.now()}`, name: "New group", type: "single", required: false, options: [] }]);

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <Card className="border-border bg-card p-5 lg:col-span-2">
        <h3 className="mb-4 font-semibold">Dish details</h3>
        <div className="space-y-4">
          <Field label="Name *">
            <Input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="e.g. Butter Chicken" />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Category">
              <Select value={form.categoryId} onValueChange={(v) => set("categoryId", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {MOCK_CATEGORIES.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Price (₹) *">
              <Input type="number" value={form.price} onChange={(e) => set("price", e.target.value)} placeholder="280" />
            </Field>
          </div>
          <Field label={`Description (${form.description.length}/200)`}>
            <Textarea
              rows={3}
              maxLength={200}
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
            />
          </Field>
          <Field label="Type">
            <RadioGroup value={form.veg} onValueChange={(v) => set("veg", v)} className="flex gap-6">
              <label className="flex items-center gap-2 text-sm"><RadioGroupItem value="veg" /> Veg</label>
              <label className="flex items-center gap-2 text-sm"><RadioGroupItem value="nonveg" /> Non-Veg</label>
            </RadioGroup>
          </Field>
          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <div>
              <p className="text-sm font-medium">Available for ordering</p>
              <p className="text-xs text-muted-foreground">Customers can see and order this dish.</p>
            </div>
            <Switch checked={form.available} onCheckedChange={(v) => set("available", v)} />
          </div>
        </div>
      </Card>

      <Card className="border-border bg-card p-5">
        <h3 className="mb-4 font-semibold">Image</h3>
        <label className="flex aspect-video cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-border bg-card-elevated text-center hover:border-primary">
          {form.image ? (
            <img src={form.image} alt="" className="h-full w-full rounded-lg object-cover" />
          ) : (
            <>
              <Upload className="mb-2 h-6 w-6 text-muted-foreground" />
              <p className="text-sm">Drop or click to upload</p>
              <p className="text-xs text-muted-foreground">PNG or JPG · max 5MB</p>
            </>
          )}
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => { const f = e.target.files?.[0]; if (f) handleImage(f); }}
          />
        </label>
      </Card>

      <Card className="border-border bg-card p-5 lg:col-span-3">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-semibold">Customization groups</h3>
          <Button variant="outline" onClick={addGroup}><Plus className="mr-2 h-4 w-4" /> Add group</Button>
        </div>

        {groups.length === 0 ? (
          <p className="rounded-lg border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
            No customizations yet — e.g. add a "Size" group with Small / Medium / Large options.
          </p>
        ) : (
          <div className="space-y-4">
            {groups.map((g, gi) => (
              <GroupEditor
                key={g.id}
                group={g}
                onChange={(ng) => setGroups((arr) => arr.map((x, i) => (i === gi ? ng : x)))}
                onDelete={() => setGroups((arr) => arr.filter((_, i) => i !== gi))}
              />
            ))}
          </div>
        )}
      </Card>

      <div className="flex justify-end gap-3 lg:col-span-3">
        <Button variant="ghost" onClick={() => {
          if (dirty && !confirm("Discard unsaved changes?")) return;
          navigate({ to: "/vendor/menu/dishes" });
        }}>Cancel</Button>
        <Button onClick={submit} className="bg-primary text-primary-foreground hover:bg-primary/90">
          Save dish
        </Button>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="space-y-2"><Label>{label}</Label>{children}</div>;
}

function GroupEditor({
  group, onChange, onDelete,
}: { group: CustomGroup; onChange: (g: CustomGroup) => void; onDelete: () => void }) {
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));
  const onDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const oldIdx = group.options.findIndex((o) => o.id === active.id);
    const newIdx = group.options.findIndex((o) => o.id === over.id);
    onChange({ ...group, options: arrayMove(group.options, oldIdx, newIdx) });
  };
  const addOpt = () => onChange({
    ...group,
    options: [...group.options, { id: `o${Date.now()}`, name: "Option", price: 0 }],
  });

  return (
    <div className="rounded-xl border border-border bg-card-elevated p-4">
      <div className="grid gap-3 md:grid-cols-3">
        <Input value={group.name} onChange={(e) => onChange({ ...group, name: e.target.value })} placeholder="Group name (e.g. Size)" />
        <Select value={group.type} onValueChange={(v) => onChange({ ...group, type: v as "single" | "multi" })}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="single">Single-select</SelectItem>
            <SelectItem value="multi">Multi-select</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex items-center justify-between rounded-lg border border-border px-3">
          <span className="text-sm">Required</span>
          <div className="flex items-center gap-2">
            <Switch checked={group.required} onCheckedChange={(v) => onChange({ ...group, required: v })} />
            <Button variant="ghost" size="icon" onClick={onDelete} className="text-destructive"><Trash2 className="h-4 w-4" /></Button>
          </div>
        </div>
      </div>

      <div className="mt-4">
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
          <SortableContext items={group.options.map((o) => o.id)} strategy={verticalListSortingStrategy}>
            <div className="space-y-2">
              {group.options.map((o, oi) => (
                <SortableOption
                  key={o.id}
                  option={o}
                  onChange={(no) => onChange({ ...group, options: group.options.map((x, i) => (i === oi ? no : x)) })}
                  onDelete={() => onChange({ ...group, options: group.options.filter((_, i) => i !== oi) })}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
        <Button variant="outline" size="sm" className="mt-3" onClick={addOpt}>
          <Plus className="mr-2 h-3 w-3" /> Add option
        </Button>
      </div>
    </div>
  );
}

function SortableOption({
  option, onChange, onDelete,
}: { option: OptionItem; onChange: (o: OptionItem) => void; onDelete: () => void }) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: option.id });
  const style = { transform: CSS.Transform.toString(transform), transition };
  return (
    <div ref={setNodeRef} style={style} className="flex items-center gap-2">
      <button {...attributes} {...listeners} className="cursor-grab text-muted-foreground">
        <GripVertical className="h-4 w-4" />
      </button>
      <Input className="flex-1" value={option.name} onChange={(e) => onChange({ ...option, name: e.target.value })} />
      <Input className="w-28" type="number" placeholder="+₹0"
        value={option.price} onChange={(e) => onChange({ ...option, price: Number(e.target.value) })} />
      <Button variant="ghost" size="icon" onClick={onDelete} className="text-destructive"><Trash2 className="h-4 w-4" /></Button>
    </div>
  );
}
