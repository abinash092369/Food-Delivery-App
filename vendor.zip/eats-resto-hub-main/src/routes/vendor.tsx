import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { VendorLayout } from "@/components/layout/VendorLayout";
import { useVendorAuth } from "@/store/vendorAuth.store";

export const Route = createFileRoute("/vendor")({
  beforeLoad: ({ location }) => {
    const publicPaths = ["/vendor/login", "/vendor/register"];
    const { user } = useVendorAuth.getState();
    if (!user && !publicPaths.includes(location.pathname)) {
      throw redirect({ to: "/vendor/login" });
    }
    if (location.pathname === "/vendor") {
      throw redirect({ to: "/vendor/dashboard" });
    }
  },
  component: VendorGate,
});

function VendorGate() {
  const user = useVendorAuth((s) => s.user);
  if (!user) return <Outlet />;
  return <VendorLayout />;
}
