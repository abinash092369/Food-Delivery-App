// Mock data for the vendor panel. Replace with real API calls when backend is ready.

export type OrderStatus =
  | "incoming"
  | "preparing"
  | "ready"
  | "picked_up"
  | "completed"
  | "cancelled";

export interface OrderItem {
  name: string;
  qty: number;
  price: number;
  notes?: string;
}

export interface Order {
  id: string;
  number: string;
  customer: string;
  phone: string;
  address: string;
  items: OrderItem[];
  total: number;
  payment: "UPI" | "Card" | "COD";
  status: OrderStatus;
  placedAt: string; // ISO
  prepMinutes?: number;
  instructions?: string;
}

export interface Dish {
  id: string;
  name: string;
  categoryId: string;
  description: string;
  price: number;
  veg: boolean;
  available: boolean;
  featured: boolean;
  imageUrl?: string;
}

export interface Category {
  id: string;
  name: string;
  available: boolean;
  order: number;
}

export interface Review {
  id: string;
  customer: string;
  rating: number;
  date: string;
  text: string;
  items: string[];
  reply?: string;
}

export interface Promo {
  id: string;
  code: string;
  type: "percent" | "flat" | "free_delivery" | "bxgy";
  value: number;
  appliesTo: string;
  usage: number;
  limit: number;
  expiry: string;
  active: boolean;
}

export interface Payout {
  id: string;
  period: string;
  orders: number;
  gross: number;
  commissionPct: number;
  net: number;
  status: "Pending" | "Processing" | "Paid";
  date: string;
}

const now = Date.now();
const minsAgo = (m: number) => new Date(now - m * 60_000).toISOString();

export const MOCK_RESTAURANT = {
  id: "rest_001",
  name: "Spice Symphony",
  cuisine: ["North Indian", "Mughlai"],
  isOpen: true,
  rating: 4.6,
  totalReviews: 1284,
};

export const MOCK_CATEGORIES: Category[] = [
  { id: "c1", name: "Starters", available: true, order: 0 },
  { id: "c2", name: "Main Course", available: true, order: 1 },
  { id: "c3", name: "Breads", available: true, order: 2 },
  { id: "c4", name: "Desserts", available: false, order: 3 },
  { id: "c5", name: "Beverages", available: true, order: 4 },
];

export const MOCK_DISHES: Dish[] = [
  { id: "d1", name: "Paneer Tikka", categoryId: "c1", description: "Smoky char-grilled cottage cheese cubes", price: 280, veg: true, available: true, featured: true },
  { id: "d2", name: "Chicken 65", categoryId: "c1", description: "Crispy Andhra-style spiced chicken", price: 320, veg: false, available: true, featured: false },
  { id: "d3", name: "Butter Chicken", categoryId: "c2", description: "Creamy tomato-butter gravy with tandoori chicken", price: 420, veg: false, available: true, featured: true },
  { id: "d4", name: "Dal Makhani", categoryId: "c2", description: "Slow-cooked black lentils, finished with cream", price: 280, veg: true, available: true, featured: false },
  { id: "d5", name: "Garlic Naan", categoryId: "c3", description: "Tandoor-baked flatbread with garlic & coriander", price: 80, veg: true, available: true, featured: false },
  { id: "d6", name: "Gulab Jamun", categoryId: "c4", description: "Warm milk dumplings in cardamom syrup", price: 120, veg: true, available: false, featured: false },
  { id: "d7", name: "Masala Chai", categoryId: "c5", description: "Spiced milk tea", price: 60, veg: true, available: true, featured: false },
];

export const MOCK_ORDERS: Order[] = [
  {
    id: "o1", number: "#12451", customer: "Rohan Mehta", phone: "+91 98100 12345",
    address: "B-204, Sapphire Heights, Sector 21, Gurgaon",
    items: [{ name: "Butter Chicken", qty: 1, price: 420 }, { name: "Garlic Naan", qty: 3, price: 80 }],
    total: 660, payment: "UPI", status: "incoming", placedAt: minsAgo(1),
  },
  {
    id: "o2", number: "#12450", customer: "Aisha Khan", phone: "+91 99887 65432",
    address: "A-12, Greenwood Apartments, Indiranagar, Bangalore",
    items: [{ name: "Paneer Tikka", qty: 2, price: 280 }, { name: "Masala Chai", qty: 2, price: 60 }],
    total: 680, payment: "Card", status: "preparing", placedAt: minsAgo(8), prepMinutes: 20,
  },
  {
    id: "o3", number: "#12449", customer: "Vikram Singh", phone: "+91 90000 11122",
    address: "Flat 5, Lakeview Heights, Bandra W, Mumbai",
    items: [{ name: "Dal Makhani", qty: 1, price: 280 }, { name: "Garlic Naan", qty: 4, price: 80 }],
    total: 600, payment: "COD", status: "preparing", placedAt: minsAgo(14), prepMinutes: 15,
  },
  {
    id: "o4", number: "#12448", customer: "Priya Sharma", phone: "+91 98212 33445",
    address: "House 18, MG Road, Pune",
    items: [{ name: "Chicken 65", qty: 1, price: 320 }],
    total: 320, payment: "UPI", status: "ready", placedAt: minsAgo(22),
  },
  {
    id: "o5", number: "#12447", customer: "Arjun Nair", phone: "+91 99001 22334",
    address: "Tower 3, Prestige Park, Whitefield, Bangalore",
    items: [{ name: "Butter Chicken", qty: 2, price: 420 }, { name: "Gulab Jamun", qty: 4, price: 120 }],
    total: 1320, payment: "Card", status: "picked_up", placedAt: minsAgo(38),
  },
  {
    id: "o6", number: "#12446", customer: "Neha Gupta", phone: "+91 90909 80808",
    address: "C-7, Vasant Kunj, New Delhi",
    items: [{ name: "Paneer Tikka", qty: 1, price: 280 }],
    total: 280, payment: "UPI", status: "completed", placedAt: minsAgo(120),
  },
  {
    id: "o7", number: "#12445", customer: "Sahil Verma", phone: "+91 95555 11111",
    address: "Flat 22, Mira Road, Mumbai",
    items: [{ name: "Dal Makhani", qty: 1, price: 280 }],
    total: 280, payment: "COD", status: "cancelled", placedAt: minsAgo(180),
  },
];

export const MOCK_REVIEWS: Review[] = [
  { id: "r1", customer: "Rohan M.", rating: 5, date: minsAgo(60 * 2), text: "Butter chicken was lush — best in the area.", items: ["Butter Chicken", "Garlic Naan"] },
  { id: "r2", customer: "Aisha K.", rating: 4, date: minsAgo(60 * 24), text: "Great taste, but delivery took a bit long.", items: ["Paneer Tikka"], reply: "Thank you Aisha! We'll work on packaging speed." },
  { id: "r3", customer: "Anonymous", rating: 2, date: minsAgo(60 * 48), text: "Food arrived cold today.", items: ["Dal Makhani"] },
  { id: "r4", customer: "Vikram S.", rating: 5, date: minsAgo(60 * 72), text: "Consistent quality every time.", items: ["Chicken 65"] },
  { id: "r5", customer: "Priya S.", rating: 3, date: minsAgo(60 * 96), text: "Decent but portion sizes could be better.", items: ["Butter Chicken"] },
];

export const MOCK_PROMOS: Promo[] = [
  { id: "p1", code: "WELCOME20", type: "percent", value: 20, appliesTo: "Entire menu", usage: 142, limit: 500, expiry: "2026-08-30", active: true },
  { id: "p2", code: "FREEDEL", type: "free_delivery", value: 0, appliesTo: "Orders > ₹400", usage: 88, limit: 200, expiry: "2026-07-15", active: true },
  { id: "p3", code: "FLAT100", type: "flat", value: 100, appliesTo: "Main Course", usage: 51, limit: 100, expiry: "2026-06-30", active: false },
];

export const MOCK_PAYOUTS: Payout[] = [
  { id: "py1", period: "May 18 – May 24, 2026", orders: 184, gross: 96420, commissionPct: 22, net: 75208, status: "Paid", date: "2026-05-26" },
  { id: "py2", period: "May 25 – May 31, 2026", orders: 211, gross: 112380, commissionPct: 22, net: 87656, status: "Paid", date: "2026-06-02" },
  { id: "py3", period: "Jun 01 – Jun 02, 2026", orders: 34, gross: 18420, commissionPct: 22, net: 14368, status: "Pending", date: "—" },
];

// Charts
export const earningsTrend = Array.from({ length: 30 }).map((_, i) => ({
  day: `${i + 1}`,
  earnings: 1800 + Math.round(Math.sin(i / 3) * 800 + Math.random() * 600 + i * 35),
}));

export const earningsByCategory = [
  { name: "Main Course", value: 62000 },
  { name: "Starters", value: 31000 },
  { name: "Breads", value: 18500 },
  { name: "Beverages", value: 7200 },
  { name: "Desserts", value: 4900 },
];

export const peakHours = Array.from({ length: 24 }).map((_, i) => ({
  hour: `${i.toString().padStart(2, "0")}h`,
  orders: i < 9 ? Math.round(Math.random() * 2) :
          i < 12 ? Math.round(Math.random() * 6 + 3) :
          i < 15 ? Math.round(Math.random() * 14 + 10) :
          i < 18 ? Math.round(Math.random() * 6 + 4) :
          i < 22 ? Math.round(Math.random() * 18 + 16) :
                   Math.round(Math.random() * 4),
}));

export const topDishes = [
  { name: "Butter Chicken", orders: 412 },
  { name: "Paneer Tikka", orders: 318 },
  { name: "Garlic Naan", orders: 287 },
  { name: "Dal Makhani", orders: 244 },
  { name: "Chicken 65", orders: 188 },
];

export const ratingDistribution = [
  { stars: "5★", count: 812 },
  { stars: "4★", count: 311 },
  { stars: "3★", count: 92 },
  { stars: "2★", count: 41 },
  { stars: "1★", count: 28 },
];

export function formatINR(n: number): string {
  return "₹" + n.toLocaleString("en-IN");
}

export function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}
