import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard, ShoppingBag, UtensilsCrossed, Wallet, Star,
  Megaphone, BarChart3, Settings,
} from "lucide-react";
import logo from "@/assets/eets-logo.png";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/vendor/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/vendor/orders", label: "Orders", icon: ShoppingBag },
  { to: "/vendor/menu", label: "Menu", icon: UtensilsCrossed },
  { to: "/vendor/earnings", label: "Earnings", icon: Wallet },
  { to: "/vendor/reviews", label: "Reviews", icon: Star },
  { to: "/vendor/promotions", label: "Promotions", icon: Megaphone },
  { to: "/vendor/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/vendor/profile", label: "Profile", icon: Settings },
];

export function VendorSidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <aside className="fixed inset-y-0 left-0 z-30 w-60 border-r border-sidebar-border bg-sidebar text-sidebar-foreground">
      <div className="flex items-center gap-3 px-5 border-b border-sidebar-border" style={{ height: 60 }}>
        <img src={logo} alt="eets" className="h-7 w-auto" />
        <span className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Partner</span>
      </div>
      <nav className="p-3 space-y-1">
        {NAV.map((n) => {
          const active = pathname === n.to || pathname.startsWith(n.to + "/");
          const Icon = n.icon;
          return (
            <Link
              key={n.to}
              to={n.to}
              className={cn(
                "relative flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                active
                  ? "bg-sidebar-accent text-primary"
                  : "text-sidebar-foreground/80 hover:bg-white/5 hover:text-foreground",
              )}
            >
              {active && (
                <span className="absolute left-0 top-1/2 h-6 w-0.5 -translate-y-1/2 rounded-r bg-primary" />
              )}
              <Icon className="h-4 w-4" />
              {n.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
