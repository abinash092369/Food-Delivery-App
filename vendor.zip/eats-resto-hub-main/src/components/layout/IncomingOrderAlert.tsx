import { useEffect, useState } from "react";
import { useOrdersStore } from "@/store/orders.store";
import { Button } from "@/components/ui/button";
import { formatINR } from "@/lib/mock-data";
import { Bell, Check, X } from "lucide-react";
import { toast } from "sonner";

export function IncomingOrderAlert() {
  const alert = useOrdersStore((s) => s.incomingAlert);
  const accept = useOrdersStore((s) => s.acceptIncoming);
  const reject = useOrdersStore((s) => s.rejectIncoming);
  const [secondsLeft, setSecondsLeft] = useState(30);

  useEffect(() => {
    if (!alert) return;
    setSecondsLeft(30);
    const id = setInterval(() => setSecondsLeft((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(id);
  }, [alert]);

  useEffect(() => {
    if (alert && secondsLeft === 5) {
      toast.warning("Auto-rejecting in 5 seconds!");
    }
    if (alert && secondsLeft === 0) {
      reject(alert.id, "Auto-rejected (timeout)");
    }
  }, [secondsLeft, alert, reject]);

  if (!alert) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
      <div className="pulse-teal w-[min(520px,92vw)] rounded-2xl bg-card-elevated p-8 text-center">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
          <Bell className="h-7 w-7 text-primary" />
        </div>
        <p className="text-xs uppercase tracking-widest text-muted-foreground">New Order</p>
        <h2 className="mt-1 text-3xl font-bold">{alert.number}</h2>
        <p className="mt-2 text-lg text-primary">{formatINR(alert.total)} · {alert.items.length} items</p>
        <p className="mt-1 text-sm text-muted-foreground">{alert.customer}</p>

        <div className="mt-6 flex gap-3">
          <Button
            variant="outline"
            className="flex-1 border-destructive/40 text-destructive hover:bg-destructive/10"
            onClick={() => reject(alert.id)}
          >
            <X className="mr-2 h-4 w-4" /> Reject
          </Button>
          <Button
            className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={() => { accept(alert.id); toast.success(`Order ${alert.number} accepted`); }}
          >
            <Check className="mr-2 h-4 w-4" /> Accept
          </Button>
        </div>
        <p className="mt-4 text-xs text-muted-foreground">Auto-reject in {secondsLeft}s</p>
      </div>
    </div>
  );
}
