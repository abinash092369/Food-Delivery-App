import { useOrdersStore } from "@/store/orders.store";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

export function OnlineToggle() {
  const isOnline = useOrdersStore((s) => s.isOnline);
  const setOnline = useOrdersStore((s) => s.setOnline);
  return (
    <div className="flex items-center gap-3">
      <span
        className={cn(
          "rounded-full px-3 py-1 text-xs font-semibold",
          isOnline ? "bg-positive text-background" : "bg-destructive text-background",
        )}
      >
        {isOnline ? "OPEN" : "CLOSED"}
      </span>
      <Switch checked={isOnline} onCheckedChange={setOnline} />
    </div>
  );
}
