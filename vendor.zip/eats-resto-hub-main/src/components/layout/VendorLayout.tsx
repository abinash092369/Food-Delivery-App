import { Outlet } from "@tanstack/react-router";
import { VendorSidebar } from "./VendorSidebar";
import { VendorHeader } from "./VendorHeader";
import { IncomingOrderAlert } from "./IncomingOrderAlert";

export function VendorLayout() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <VendorSidebar />
      <VendorHeader />
      <main className="ml-60 pt-[60px]">
        <div className="p-6 max-w-[1600px] mx-auto">
          <Outlet />
        </div>
      </main>
      <IncomingOrderAlert />
    </div>
  );
}
