import { Bell, LogOut } from "lucide-react";
import { useVendorAuth } from "@/store/vendorAuth.store";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import { useMemo } from "react";
import { OnlineToggle } from "./OnlineToggle";

export function VendorHeader() {
  const user = useVendorAuth((s) => s.user);
  const logout = useVendorAuth((s) => s.logout);
  const navigate = useNavigate();
  const path = useRouterState({ select: (s) => s.location.pathname });

  const crumbs = useMemo(
    () => path.split("/").filter(Boolean).map((s) => s.replace(/-/g, " ")),
    [path],
  );

  return (
    <header
      className="fixed left-60 right-0 top-0 z-20 flex items-center justify-between border-b border-border bg-background/80 px-6 backdrop-blur"
      style={{ height: 60 }}
    >
      <div className="flex items-center gap-2 text-sm text-muted-foreground capitalize">
        {crumbs.map((c, i) => (
          <span key={i} className="flex items-center gap-2">
            {i > 0 && <span>/</span>}
            <span className={i === crumbs.length - 1 ? "text-foreground font-medium" : ""}>{c}</span>
          </span>
        ))}
      </div>
      <div className="flex items-center gap-4">
        <OnlineToggle />
        <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
          <Bell className="h-5 w-5" />
        </Button>
        {user && (
          <div className="flex items-center gap-3">
            <Avatar className="h-8 w-8">
              <AvatarFallback>{user.name.slice(0, 1)}</AvatarFallback>
            </Avatar>
            <div className="hidden sm:block leading-tight">
              <p className="text-sm font-medium">{user.name}</p>
              <p className="text-[10px] uppercase tracking-wider text-primary">Vendor</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => { logout(); navigate({ to: "/vendor/login" }); }}
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
    </header>
  );
}
