import { create } from "zustand";
import { persist } from "zustand/middleware";

interface VendorUser {
  id: string;
  name: string;
  email: string;
  restaurantName: string;
  avatar?: string;
}

interface VendorAuthState {
  user: VendorUser | null;
  login: (email: string, _password: string) => void;
  logout: () => void;
  setUser: (u: VendorUser) => void;
}

export const useVendorAuth = create<VendorAuthState>()(
  persist(
    (set) => ({
      user: {
        id: "v1",
        name: "Kabir Singh",
        email: "kabir@spicesymphony.in",
        restaurantName: "Spice Symphony",
      },
      login: (email) =>
        set({
          user: {
            id: "v1",
            name: email.split("@")[0] || "Vendor",
            email,
            restaurantName: "Spice Symphony",
          },
        }),
      logout: () => set({ user: null }),
      setUser: (u) => set({ user: u }),
    }),
    { name: "vendor-auth" },
  ),
);
