import { create } from "zustand";
import { MOCK_ORDERS, type Order, type OrderStatus } from "@/lib/mock-data";

interface OrdersState {
  orders: Order[];
  incomingAlert: Order | null;
  isOnline: boolean;
  setOnline: (v: boolean) => void;
  updateStatus: (id: string, status: OrderStatus) => void;
  setPrep: (id: string, minutes: number) => void;
  acceptIncoming: (id: string) => void;
  rejectIncoming: (id: string, reason?: string) => void;
  pushSimulatedOrder: (o: Order) => void;
  dismissAlert: () => void;
}

export const useOrdersStore = create<OrdersState>((set) => ({
  orders: MOCK_ORDERS,
  incomingAlert: null,
  isOnline: true,
  setOnline: (v) => set({ isOnline: v }),
  updateStatus: (id, status) =>
    set((s) => ({ orders: s.orders.map((o) => (o.id === id ? { ...o, status } : o)) })),
  setPrep: (id, minutes) =>
    set((s) => ({ orders: s.orders.map((o) => (o.id === id ? { ...o, prepMinutes: minutes } : o)) })),
  acceptIncoming: (id) =>
    set((s) => ({
      orders: s.orders.map((o) => (o.id === id ? { ...o, status: "preparing" as const, prepMinutes: 20 } : o)),
      incomingAlert: null,
    })),
  rejectIncoming: (id) =>
    set((s) => ({
      orders: s.orders.map((o) => (o.id === id ? { ...o, status: "cancelled" as const } : o)),
      incomingAlert: null,
    })),
  pushSimulatedOrder: (o) =>
    set((s) => ({ orders: [o, ...s.orders], incomingAlert: o })),
  dismissAlert: () => set({ incomingAlert: null }),
}));
