# eets Backend

Production-grade Spring Boot 3.3 backend for the **eets** food delivery platform.
Serves 4 frontends: Customer, Admin, Vendor, Driver.

## Tech
Java 21 · Spring Boot 3.3 · Spring Security (JWT) · Spring Data JPA · MySQL 8 · Redis 7
WebSocket (STOMP) · Twilio · Razorpay · Cloudinary · Firebase Admin · MapStruct · Lombok

## Quick start

```bash
# 1. Create MySQL database
mysql -u root -p -e "CREATE DATABASE eets_db CHARACTER SET utf8mb4;"
mysql -u root -p eets_db < src/main/resources/schema.sql

# 2. Start Redis
redis-server

# 3. Configure env (copy and edit)
cp .env.example .env
# fill in DB_USERNAME, DB_PASSWORD, JWT_SECRET, TWILIO_*, RAZORPAY_*, CLOUDINARY_*, MAIL_*

# 4. Build & run
./mvnw spring-boot:run
# or:  mvn spring-boot:run
```

Backend runs on **http://localhost:8080**
Swagger UI: **http://localhost:8080/swagger-ui.html**
WebSocket endpoint: **ws://localhost:8080/ws**

## Frontends (CORS pre-configured)
| App      | Port  |
|----------|-------|
| Customer | 5173  |
| Admin    | 5174  |
| Vendor   | 5175  |
| Driver   | 5176  |

## Postman
Import `eets.postman_collection.json` and set the `baseUrl` env var to `http://localhost:8080/api`.

## Project layout
See the package tree under `src/main/java/com/eets/`.
