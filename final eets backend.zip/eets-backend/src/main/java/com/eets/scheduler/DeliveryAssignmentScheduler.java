package com.eets.scheduler;

import com.eets.service.DeliveryService;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DeliveryAssignmentScheduler {
    private final DeliveryService deliveryService;

    @Scheduled(fixedDelayString = "#{${eets.delivery.assignment-retry-interval-min} * 60 * 1000}")
    public void retryUnassigned() { deliveryService.retryUnassignedOrders(); }
}
