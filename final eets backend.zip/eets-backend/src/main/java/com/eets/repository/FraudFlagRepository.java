package com.eets.repository;

import com.eets.domain.*;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public interface FraudFlagRepository extends JpaRepository<FraudFlag, Long> {

    Page<FraudFlag> findByStatus(FraudStatus status, Pageable pageable);
    boolean existsByUserIdAndFlagTypeAndStatus(Long userId, String flagType, FraudStatus status);
}
