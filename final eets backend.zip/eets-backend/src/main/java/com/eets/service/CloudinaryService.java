package com.eets.service;

import com.cloudinary.Cloudinary;
import com.eets.dto.response.CloudinarySignResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class CloudinaryService {
    private final Cloudinary cloudinary;

    public CloudinarySignResponse sign(String folder) {
        long timestamp = System.currentTimeMillis() / 1000L;
        Map<String, Object> params = new TreeMap<>();
        params.put("folder", folder);
        params.put("timestamp", timestamp);
        String signature = cloudinary.apiSignRequest(params, cloudinary.config.apiSecret);
        return new CloudinarySignResponse(signature, timestamp,
            cloudinary.config.apiKey, cloudinary.config.cloudName, folder);
    }
}
