package com.eets.service;

import com.eets.config.TwilioConfig;
import com.eets.exception.OtpException;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.Duration;

@Slf4j
@Service
@RequiredArgsConstructor
public class OtpService {
    private static final SecureRandom RND = new SecureRandom();
    private static final Duration TTL = Duration.ofMinutes(5);
    private static final Duration RATE_TTL = Duration.ofHours(1);

    private final StringRedisTemplate redis;
    private final TwilioConfig twilio;

    public void sendOtp(String phone, String countryCode) {
        String rateKey = "otp:send:" + phone;
        Long count = redis.opsForValue().increment(rateKey);
        if (count != null && count == 1L) redis.expire(rateKey, RATE_TTL);
        if (count != null && count > 3) throw new OtpException("Too many OTP requests. Try again later.");

        String otp = String.format("%06d", RND.nextInt(1_000_000));
        redis.opsForValue().set("otp:" + phone, otp, TTL);
        redis.delete("otp:attempts:" + phone);

        String body = "Your eets OTP is " + otp + ". Valid for 5 minutes.";
        if (twilio.enabled()) {
            try {
                Message.creator(new PhoneNumber(countryCode + phone), new PhoneNumber(twilio.getFromNumber()), body).create();
            } catch (Exception e) {
                log.warn("Twilio send failed: {}", e.getMessage());
            }
        } else {
            log.info("[DEV] OTP for {} = {}", phone, otp);
        }
    }

    public boolean verifyOtp(String phone, String otp) {
        String key = "otp:" + phone;
        String stored = redis.opsForValue().get(key);
        if (stored == null) throw new OtpException("OTP expired or not found");
        String attemptsKey = "otp:attempts:" + phone;
        Long attempts = redis.opsForValue().increment(attemptsKey);
        if (attempts != null && attempts == 1L) redis.expire(attemptsKey, TTL);
        if (attempts != null && attempts > 5) {
            redis.delete(key);
            throw new OtpException("Too many invalid attempts");
        }
        if (!stored.equals(otp)) throw new OtpException("Invalid OTP");
        redis.delete(key);
        redis.delete(attemptsKey);
        return true;
    }
}
