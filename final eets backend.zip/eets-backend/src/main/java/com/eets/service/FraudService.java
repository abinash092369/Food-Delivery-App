package com.eets.service;

import com.eets.domain.*;
import com.eets.repository.*;
import com.eets.util.DateUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class FraudService {
    private final FraudFlagRepository flags;
    private final OrderRepository orders;
    private final AddressRepository addresses;
    private final UserRepository users;
    private final ObjectMapper json = new ObjectMapper();

    public void runDetection() {
        log.info("Running fraud detection sweep");
        try {
            ruleMultipleAccountsSameAddress();
            ruleExcessiveCancellations();
        } catch (Exception e) {
            log.error("Fraud detection error", e);
        }
    }

    private void ruleMultipleAccountsSameAddress() {
        Instant since = DateUtil.startOfDaysAgo(1);
        List<Order> recent = orders.findAll().stream()
            .filter(o -> o.getCreatedAt() != null && o.getCreatedAt().isAfter(since)).toList();
        Map<String, Set<Long>> addrToUsers = new HashMap<>();
        for (Order o : recent) {
            addresses.findById(o.getDeliveryAddressId()).ifPresent(a -> {
                String key = (a.getAddressLine() + "|" + a.getCity() + "|" + a.getPincode()).toLowerCase();
                addrToUsers.computeIfAbsent(key, k -> new HashSet<>()).add(o.getUserId());
            });
        }
        addrToUsers.forEach((addr, userSet) -> {
            if (userSet.size() > 2) {
                for (Long uid : userSet) flagOnce(uid, null, "MULTI_ACCOUNT_SAME_ADDRESS", 80, Map.of("address", addr, "userCount", userSet.size()));
            }
        });
    }

    private void ruleExcessiveCancellations() {
        Instant since = DateUtil.startOfDaysAgo(1);
        Map<Long, Long> cancelCounts = orders.findAll().stream()
            .filter(o -> o.getStatus() == OrderStatus.CANCELLED && o.getCreatedAt() != null && o.getCreatedAt().isAfter(since))
            .collect(Collectors.groupingBy(Order::getUserId, Collectors.counting()));
        cancelCounts.forEach((uid, count) -> {
            if (count > 5) flagOnce(uid, null, "EXCESSIVE_CANCELLATIONS", 90, Map.of("count", count));
        });
    }

    private void flagOnce(Long userId, Long orderId, String type, int risk, Map<String, Object> details) {
        if (flags.existsByUserIdAndFlagTypeAndStatus(userId, type, FraudStatus.OPEN)) return;
        try {
            flags.save(FraudFlag.builder().userId(userId).orderId(orderId).flagType(type)
                .riskScore(risk).details(json.writeValueAsString(details))
                .status(FraudStatus.OPEN).flaggedAt(Instant.now()).build());
            log.warn("Fraud flag created: user={} type={}", userId, type);
        } catch (Exception e) { log.error("Failed to create fraud flag", e); }
    }
}
