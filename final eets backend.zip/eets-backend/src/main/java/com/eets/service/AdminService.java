package com.eets.service;

import com.eets.domain.*;
import com.eets.dto.request.*;
import com.eets.dto.response.*;
import com.eets.exception.*;
import com.eets.repository.*;
import com.eets.util.PageResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;

@Service
@RequiredArgsConstructor
@Transactional
public class AdminService {
    private final UserRepository users;
    private final RestaurantRepository restaurants;
    private final DeliveryPartnerRepository drivers;
    private final OrderRepository orders;
    private final FraudFlagRepository fraudFlags;
    private final CouponRepository coupons;
    private final EmailService emailService;
    private final RestaurantService restaurantService;
    private final OrderService orderService;

    // ----- Users -----
    public PageResponse<AdminUserResponse> listUsers(int page, int size, Role role, String q) {
        return PageResponse.of(users.search(q, role, PageRequest.of(page, size)).map(this::toUserDto));
    }
    public AdminUserResponse getUser(Long id) {
        return toUserDto(users.findById(id).orElseThrow(() -> new ResourceNotFoundException("User not found")));
    }
    public AdminUserResponse updateUser(Long id, AdminUserUpdateRequest req) {
        User u = users.findById(id).orElseThrow(() -> new ResourceNotFoundException("Not found"));
        if (req.name() != null) u.setName(req.name());
        if (req.email() != null) u.setEmail(req.email());
        if (req.isActive() != null) u.setIsActive(req.isActive());
        return toUserDto(users.save(u));
    }
    public void banUser(Long id, String reason) {
        User u = users.findById(id).orElseThrow(() -> new ResourceNotFoundException("Not found"));
        u.setIsBanned(true); u.setIsActive(false); u.setBanReason(reason);
        users.save(u);
        emailService.sendBanNotice(u, reason);
    }

    // ----- Restaurants -----
    public PageResponse<RestaurantDetailResponse> listRestaurants(int page, int size, String q) {
        return PageResponse.of(restaurants.searchAdmin(q, PageRequest.of(page, size)).map(restaurantService::toDetail));
    }
    public List<RestaurantDetailResponse> pendingRestaurants() {
        return restaurants.findByIsApprovedFalseAndRejectionReasonIsNull(PageRequest.of(0, 100))
            .map(restaurantService::toDetail).getContent();
    }
    public void approveRestaurant(Long id) {
        Restaurant r = restaurants.findById(id).orElseThrow(() -> new ResourceNotFoundException("Not found"));
        r.setIsApproved(true);
        r.setRejectionReason(null);
        restaurants.save(r);
        users.findById(r.getOwnerId()).ifPresent(v -> emailService.sendRestaurantApproved(v, r));
    }
    public void rejectRestaurant(Long id, String reason) {
        Restaurant r = restaurants.findById(id).orElseThrow(() -> new ResourceNotFoundException("Not found"));
        r.setIsApproved(false);
        r.setRejectionReason(reason);
        restaurants.save(r);
        users.findById(r.getOwnerId()).ifPresent(v -> emailService.sendRestaurantRejected(v, r, reason));
    }
    public void setRestaurantStatus(Long id, String status) {
        Restaurant r = restaurants.findById(id).orElseThrow(() -> new ResourceNotFoundException("Not found"));
        r.setIsActive("ACTIVE".equalsIgnoreCase(status));
        restaurants.save(r);
    }

    // ----- Drivers -----
    public PageResponse<DriverProfileResponse> listDrivers(int page, int size, DriverService driverService) {
        return PageResponse.of(drivers.findAll(PageRequest.of(page, size)).map(d -> {
            User u = users.findById(d.getUserId()).orElseThrow();
            return driverService.toDto(d, u);
        }));
    }
    public void verifyDriver(Long driverId) {
        DeliveryPartner d = drivers.findById(driverId).orElseThrow(() -> new ResourceNotFoundException("Not found"));
        d.setIsVerified(true);
        drivers.save(d);
    }

    // ----- Orders -----
    public PageResponse<OrderResponse> listOrders(int page, int size, OrderStatus status) {
        var pageable = PageRequest.of(page, size);
        var pageResult = status == null
            ? orders.findAll(pageable).map(orderService::toDto)
            : orders.findByStatusOrderByCreatedAtDesc(status, pageable).map(orderService::toDto);
        return PageResponse.of(pageResult);
    }
    public OrderResponse setOrderNotes(Long id, String notes) {
        Order o = orders.findById(id).orElseThrow(() -> new ResourceNotFoundException("Not found"));
        o.setAdminNotes(notes);
        return orderService.toDto(orders.save(o));
    }

    // ----- Fraud -----
    public PageResponse<FraudFlagResponse> listFlags(int page, int size, FraudStatus status) {
        var pageable = PageRequest.of(page, size);
        var pageResult = status == null
            ? fraudFlags.findAll(pageable).map(this::toFlag)
            : fraudFlags.findByStatus(status, pageable).map(this::toFlag);
        return PageResponse.of(pageResult);
    }
    public void resolveFlag(Long id, FraudStatus status) {
        FraudFlag f = fraudFlags.findById(id).orElseThrow(() -> new ResourceNotFoundException("Not found"));
        f.setStatus(status);
        fraudFlags.save(f);
    }

    // ----- Coupons -----
    public CouponResponse createCoupon(Long createdById, CouponCreateRequest req, CouponService couponService) {
        Coupon c = Coupon.builder().code(req.code().toUpperCase()).type(req.type()).value(req.value())
            .maxDiscount(req.maxDiscount()).minOrderAmount(req.minOrderAmount() == null ? java.math.BigDecimal.ZERO : req.minOrderAmount())
            .usageLimitPerUser(req.usageLimitPerUser() == null ? 1 : req.usageLimitPerUser())
            .totalUsageLimit(req.totalUsageLimit()).validFrom(req.validFrom() == null ? Instant.now() : req.validFrom())
            .validUntil(req.validUntil()).isActive(true).applicableRestaurantId(req.applicableRestaurantId())
            .createdById(createdById).build();
        c = coupons.save(c);
        return couponService.toDto(c);
    }
    public PageResponse<CouponResponse> listCoupons(int page, int size, CouponService couponService) {
        return PageResponse.of(coupons.findAll(PageRequest.of(page, size)).map(couponService::toDto));
    }
    public void deleteCoupon(Long id) {
        Coupon c = coupons.findById(id).orElseThrow(() -> new ResourceNotFoundException("Not found"));
        c.setIsActive(false);
        coupons.save(c);
    }

    private AdminUserResponse toUserDto(User u) {
        return new AdminUserResponse(u.getId(), u.getName(), u.getEmail(), u.getPhone(), u.getRole(),
            u.getIsActive(), u.getIsBanned(), u.getBanReason(), u.getLastLoginAt(), u.getCreatedAt());
    }
    private FraudFlagResponse toFlag(FraudFlag f) {
        return new FraudFlagResponse(f.getId(), f.getUserId(), f.getOrderId(), f.getFlagType(),
            f.getRiskScore(), f.getDetails(), f.getStatus(), f.getFlaggedAt());
    }
}
