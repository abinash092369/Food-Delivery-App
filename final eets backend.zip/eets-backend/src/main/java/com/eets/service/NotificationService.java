package com.eets.service;

import com.eets.domain.*;
import com.eets.dto.response.NotificationResponse;
import com.eets.repository.*;
import com.eets.util.PageResponse;
import com.eets.websocket.OrderSocketService;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notifications;
    private final UserRepository users;
    private final OrderSocketService socket;

    public void send(Long userId, String title, String body, String type, Long referenceId) {
        Notification n = Notification.builder().userId(userId).title(title).body(body)
            .type(type).referenceId(referenceId).isRead(false)
            .sentVia("[\"push\",\"in_app\"]").build();
        notifications.save(n);
        socket.notifyUser(userId, Map.of("title", title, "body", body, "type", type, "referenceId", referenceId == null ? "" : referenceId));
        users.findById(userId).ifPresent(u -> sendFcm(u.getFcmToken(), title, body));
    }

    @Async
    public void sendFcm(String token, String title, String body) {
        if (token == null || token.isBlank() || FirebaseApp.getApps().isEmpty()) return;
        try {
            Message msg = Message.builder()
                .setToken(token)
                .setNotification(com.google.firebase.messaging.Notification.builder()
                    .setTitle(title).setBody(body).build())
                .build();
            FirebaseMessaging.getInstance().send(msg);
        } catch (Exception e) {
            log.warn("FCM send failed: {}", e.getMessage());
        }
    }

    public PageResponse<NotificationResponse> list(Long userId, int page, int size, boolean unreadOnly) {
        Pageable p = PageRequest.of(page, size);
        Page<Notification> result = unreadOnly
            ? notifications.findByUserIdAndIsReadFalseOrderByCreatedAtDesc(userId, p)
            : notifications.findByUserIdOrderByCreatedAtDesc(userId, p);
        return PageResponse.of(result.map(n -> new NotificationResponse(
            n.getId(), n.getTitle(), n.getBody(), n.getType(), n.getReferenceId(), n.getIsRead(), n.getCreatedAt())));
    }

    public void markRead(Long userId, Long id) {
        notifications.findById(id).ifPresent(n -> {
            if (!n.getUserId().equals(userId)) return;
            n.setIsRead(true);
            notifications.save(n);
        });
    }

    public void markAllRead(Long userId) {
        notifications.findByUserIdAndIsReadFalseOrderByCreatedAtDesc(userId, PageRequest.of(0, 500))
            .forEach(n -> { n.setIsRead(true); notifications.save(n); });
    }
}
