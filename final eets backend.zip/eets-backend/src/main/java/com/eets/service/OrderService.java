package com.eets.service;

import com.eets.domain.*;
import com.eets.dto.request.*;
import com.eets.dto.response.*;
import com.eets.exception.*;
import com.eets.repository.*;
import com.eets.security.JwtTokenProvider;
import com.eets.util.OrderNumberGenerator;
import com.eets.util.PageResponse;
import com.eets.websocket.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class OrderService {
    private static final BigDecimal TAX_RATE = new BigDecimal("0.18");

    private final OrderRepository orders;
    private final OrderItemRepository orderItems;
    private final OrderStatusHistoryRepository history;
    private final CartRepository carts;
    private final CartItemRepository cartItems;
    private final MenuItemRepository menuItems;
    private final RestaurantRepository restaurants;
    private final UserRepository users;
    private final AddressRepository addresses;
    private final DeliveryAssignmentRepository assignments;
    private final DeliveryPartnerRepository drivers;
    private final OrderNumberGenerator numberGen;
    private final PaymentService paymentService;
    private final CouponService couponService;
    private final DeliveryService deliveryService;
    private final NotificationService notificationService;
    private final OrderSocketService orderSocket;
    private final AdminSocketService adminSocket;
    private final ObjectMapper json = new ObjectMapper();

    public InitiateOrderResponse initiate(Long userId, InitiateOrderRequest req) {
        Cart cart = carts.findByUserId(userId).orElseThrow(() -> new BadRequestException("Cart empty"));
        List<CartItem> items = cartItems.findByCartId(cart.getId());
        if (items.isEmpty()) throw new BadRequestException("Cart empty");
        Address addr = addresses.findById(req.addressId()).orElseThrow(() -> new BadRequestException("Address not found"));
        if (!addr.getUserId().equals(userId)) throw new UnauthorizedException("Address not yours");
        Restaurant r = restaurants.findById(cart.getRestaurantId()).orElseThrow();

        BigDecimal subtotal = items.stream().map(CartItem::getTotalPrice).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal deliveryFee = r.getDeliveryFee();
        BigDecimal tax = subtotal.multiply(TAX_RATE).setScale(2, RoundingMode.HALF_UP);
        BigDecimal discount = BigDecimal.ZERO;
        Coupon coupon = null;
        if (req.couponCode() != null && !req.couponCode().isBlank()) {
            coupon = couponService.findOrThrow(req.couponCode());
            discount = couponService.calculateDiscount(coupon, subtotal);
            if (coupon.getType() == CouponType.FREE_DELIVERY) deliveryFee = BigDecimal.ZERO;
        }
        BigDecimal total = subtotal.add(deliveryFee).add(tax).subtract(discount).max(BigDecimal.ZERO);

        Order order = Order.builder()
            .orderNumber(numberGen.next())
            .userId(userId).restaurantId(r.getId()).deliveryAddressId(addr.getId())
            .couponId(coupon == null ? null : coupon.getId())
            .status(OrderStatus.PLACED)
            .paymentMethod(req.paymentMethod())
            .paymentStatus(req.paymentMethod() == PaymentMethod.COD ? PaymentStatus.PENDING : PaymentStatus.PENDING)
            .subtotal(subtotal).deliveryFee(deliveryFee).taxAmount(tax)
            .discountAmount(discount).totalAmount(total)
            .specialInstructions(req.specialInstructions())
            .estimatedDeliveryAt(Instant.now().plusSeconds(r.getDeliveryTimeMin() * 60L))
            .build();
        order = orders.save(order);

        // snapshot items
        for (CartItem ci : items) {
            MenuItem mi = menuItems.findById(ci.getMenuItemId()).orElse(null);
            orderItems.save(OrderItem.builder()
                .orderId(order.getId()).menuItemId(ci.getMenuItemId())
                .name(mi == null ? "Item" : mi.getName())
                .quantity(ci.getQuantity()).unitPrice(ci.getItemPrice()).totalPrice(ci.getTotalPrice())
                .selectedOptions(ci.getSelectedOptions()).build());
        }
        history.save(OrderStatusHistory.builder().orderId(order.getId()).status("PLACED")
            .changedById(userId).changedAt(Instant.now()).notes("Order placed").build());

        User u = users.findById(userId).orElseThrow();
        if (req.paymentMethod() == PaymentMethod.RAZORPAY) {
            PaymentService.RazorpayOrder rz = paymentService.createOrder(total, userId);
            order.setRazorpayOrderId(rz.id());
            orders.save(order);
            return new InitiateOrderResponse(order.getId(), order.getOrderNumber(),
                rz.id(), total, rz.currency(), paymentService.getKeyId(),
                new InitiateOrderResponse.Prefill(u.getName(), u.getEmail(), u.getPhone()));
        } else {
            // COD: confirm immediately
            confirmOrder(order, coupon, userId);
            return new InitiateOrderResponse(order.getId(), order.getOrderNumber(),
                null, total, "INR", null,
                new InitiateOrderResponse.Prefill(u.getName(), u.getEmail(), u.getPhone()));
        }
    }

    public Map<String, Object> verifyPayment(Long userId, VerifyPaymentRequest req) {
        paymentService.verifySignature(req.razorpayOrderId(), req.razorpayPaymentId(), req.razorpaySignature());
        Order order = orders.findAll().stream()
            .filter(o -> req.razorpayOrderId().equals(o.getRazorpayOrderId())).findFirst()
            .orElseThrow(() -> new BadRequestException("Order not found"));
        if (!order.getUserId().equals(userId)) throw new UnauthorizedException("Not your order");
        order.setRazorpayPaymentId(req.razorpayPaymentId());
        order.setRazorpaySignature(req.razorpaySignature());
        order.setPaymentStatus(PaymentStatus.PAID);
        orders.save(order);
        Coupon coupon = order.getCouponId() == null ? null : couponService.byId(order.getCouponId());
        confirmOrder(order, coupon, userId);
        return Map.of("orderId", order.getId(), "orderNumber", order.getOrderNumber());
    }

    private void confirmOrder(Order order, Coupon coupon, Long userId) {
        if (coupon != null) couponService.recordUsage(coupon, userId, order.getId(), order.getDiscountAmount());
        carts.findByUserId(userId).ifPresent(c -> { cartItems.deleteByCartId(c.getId()); c.setRestaurantId(null); c.setCouponId(null); carts.save(c); });
        Restaurant r = restaurants.findById(order.getRestaurantId()).orElse(null);
        User u = users.findById(userId).orElse(null);

        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("event", "order_received");
        payload.put("orderId", order.getId());
        payload.put("orderNumber", order.getOrderNumber());
        payload.put("total", order.getTotalAmount());
        payload.put("customerName", u == null ? "" : u.getName());
        orderSocket.broadcastOrderToRestaurant(order.getRestaurantId(), payload);
        adminSocket.broadcastNewOrder(Map.of("orderId", order.getId(), "amount", order.getTotalAmount(),
            "restaurant", r == null ? "" : r.getName(), "customer", u == null ? "" : u.getName()));
        if (r != null) notificationService.send(r.getOwnerId(), "New order!", "Order " + order.getOrderNumber() + " received", "NEW_ORDER", order.getId());
    }

    public PageResponse<OrderResponse> userOrders(Long userId, int page, int size) {
        return PageResponse.of(orders.findByUserIdOrderByCreatedAtDesc(userId, PageRequest.of(page, size)).map(this::toDto));
    }

    public OrderResponse getOrder(Long userId, Long id) {
        Order o = orders.findById(id).orElseThrow(() -> new ResourceNotFoundException("Order not found"));
        if (!o.getUserId().equals(userId)) throw new UnauthorizedException("Not your order");
        return toDto(o);
    }

    public OrderResponse getOrderAsAdmin(Long id) {
        return toDto(orders.findById(id).orElseThrow(() -> new ResourceNotFoundException("Order not found")));
    }

    public void cancelOrder(Long userId, Long id, String reason) {
        Order o = orders.findById(id).orElseThrow(() -> new ResourceNotFoundException("Order not found"));
        if (!o.getUserId().equals(userId)) throw new UnauthorizedException("Not your order");
        if (!EnumSet.of(OrderStatus.PLACED, OrderStatus.ACCEPTED, OrderStatus.PREPARING).contains(o.getStatus()))
            throw new BadRequestException("Cannot cancel at this stage");
        o.setStatus(OrderStatus.CANCELLED);
        o.setCancellationReason(reason);
        if (o.getPaymentStatus() == PaymentStatus.PAID) {
            paymentService.refund(o.getRazorpayPaymentId(), o.getTotalAmount());
            o.setPaymentStatus(PaymentStatus.REFUNDED);
            o.setRefundAmount(o.getTotalAmount());
            o.setStatus(OrderStatus.REFUNDED);
        }
        orders.save(o);
        history.save(OrderStatusHistory.builder().orderId(o.getId()).status("CANCELLED")
            .changedById(userId).changedAt(Instant.now()).notes(reason).build());
        orderSocket.broadcastOrderToRestaurant(o.getRestaurantId(),
            Map.of("event", "order_cancelled", "orderId", o.getId(), "reason", reason));
        Restaurant r = restaurants.findById(o.getRestaurantId()).orElse(null);
        if (r != null) notificationService.send(r.getOwnerId(), "Order cancelled", "Order " + o.getOrderNumber() + " was cancelled", "ORDER_CANCELLED", o.getId());
    }

    public Map<String, Object> reorder(Long userId, Long id) {
        Order o = orders.findById(id).orElseThrow(() -> new ResourceNotFoundException("Order not found"));
        if (!o.getUserId().equals(userId)) throw new UnauthorizedException("Not your order");
        Cart cart = carts.findByUserId(userId).orElseGet(() -> carts.save(Cart.builder().userId(userId).restaurantId(o.getRestaurantId()).build()));
        cartItems.deleteByCartId(cart.getId());
        cart.setRestaurantId(o.getRestaurantId()); cart.setCouponId(null); carts.save(cart);
        List<String> unavailable = new ArrayList<>();
        List<OrderItem> items = orderItems.findByOrderId(o.getId());
        for (OrderItem oi : items) {
            MenuItem mi = menuItems.findById(oi.getMenuItemId()).orElse(null);
            if (mi == null || !Boolean.TRUE.equals(mi.getIsAvailable())) { unavailable.add(oi.getName()); continue; }
            cartItems.save(CartItem.builder().cartId(cart.getId()).menuItemId(mi.getId())
                .quantity(oi.getQuantity()).itemPrice(oi.getUnitPrice())
                .totalPrice(oi.getUnitPrice().multiply(BigDecimal.valueOf(oi.getQuantity())))
                .selectedOptions(oi.getSelectedOptions()).build());
        }
        return Map.of("cartId", cart.getId(), "unavailableItems", unavailable);
    }

    // vendor flow
    public OrderResponse vendorUpdateStatus(Long vendorUserId, Long orderId, OrderStatus status) {
        Order o = orders.findById(orderId).orElseThrow(() -> new ResourceNotFoundException("Order not found"));
        Restaurant r = restaurants.findById(o.getRestaurantId()).orElseThrow();
        if (!r.getOwnerId().equals(vendorUserId)) throw new UnauthorizedException("Not your restaurant");
        o.setStatus(status);
        orders.save(o);
        history.save(OrderStatusHistory.builder().orderId(o.getId()).status(status.name())
            .changedById(vendorUserId).changedAt(Instant.now()).build());
        orderSocket.broadcastStatusUpdate(o.getId(),
            Map.of("event", "status_updated", "status", status.name()));
        notificationService.send(o.getUserId(), "Order " + status.name().toLowerCase(),
            "Your order " + o.getOrderNumber() + " is " + status.name(), "ORDER_STATUS", o.getId());
        if (status == OrderStatus.ACCEPTED) deliveryService.assignDelivery(o.getId());
        return toDto(o);
    }

    public OrderResponse vendorReject(Long vendorUserId, Long orderId, String reason) {
        Order o = orders.findById(orderId).orElseThrow(() -> new ResourceNotFoundException("Order not found"));
        Restaurant r = restaurants.findById(o.getRestaurantId()).orElseThrow();
        if (!r.getOwnerId().equals(vendorUserId)) throw new UnauthorizedException("Not your restaurant");
        o.setStatus(OrderStatus.CANCELLED);
        o.setCancellationReason(reason);
        if (o.getPaymentStatus() == PaymentStatus.PAID) {
            paymentService.refund(o.getRazorpayPaymentId(), o.getTotalAmount());
            o.setPaymentStatus(PaymentStatus.REFUNDED);
            o.setStatus(OrderStatus.REFUNDED);
            o.setRefundAmount(o.getTotalAmount());
        }
        orders.save(o);
        history.save(OrderStatusHistory.builder().orderId(o.getId()).status("CANCELLED")
            .changedById(vendorUserId).changedAt(Instant.now()).notes(reason).build());
        notificationService.send(o.getUserId(), "Order rejected", reason, "ORDER_REJECTED", o.getId());
        return toDto(o);
    }

    public void adminRefund(Long orderId, BigDecimal amount, String reason) {
        Order o = orders.findById(orderId).orElseThrow(() -> new ResourceNotFoundException("Order not found"));
        paymentService.refund(o.getRazorpayPaymentId(), amount);
        o.setRefundAmount(amount); o.setRefundReason(reason);
        o.setPaymentStatus(PaymentStatus.REFUNDED);
        orders.save(o);
        notificationService.send(o.getUserId(), "Refund initiated", "₹" + amount + " refund for " + o.getOrderNumber(), "REFUND", o.getId());
    }

    public OrderResponse toDto(Order o) {
        List<OrderItem> items = orderItems.findByOrderId(o.getId());
        List<OrderItemResponse> itemDtos = items.stream().map(i ->
            new OrderItemResponse(i.getId(), i.getMenuItemId(), i.getName(), i.getQuantity(),
                i.getUnitPrice(), i.getTotalPrice(), i.getSelectedOptions())).toList();
        List<OrderStatusHistoryResponse> hist = history.findByOrderIdOrderByChangedAtAsc(o.getId()).stream()
            .map(h -> new OrderStatusHistoryResponse(h.getStatus(), h.getChangedAt(), h.getNotes())).toList();
        Restaurant r = restaurants.findById(o.getRestaurantId()).orElse(null);
        Address a = addresses.findById(o.getDeliveryAddressId()).orElse(null);
        AddressResponse addrDto = a == null ? null : new AddressResponse(a.getId(), a.getLabel(),
            a.getAddressLine(), a.getCity(), a.getState(), a.getPincode(), a.getLat(), a.getLng(), a.getIsDefault());
        OrderResponse.DriverInfo driverInfo = null;
        if (o.getDeliveryPartnerId() != null) {
            DeliveryPartner dp = drivers.findById(o.getDeliveryPartnerId()).orElse(null);
            if (dp != null) {
                User du = users.findById(dp.getUserId()).orElse(null);
                driverInfo = new OrderResponse.DriverInfo(dp.getId(),
                    du == null ? null : du.getName(), du == null ? null : du.getPhone(),
                    dp.getVehicleType() == null ? null : dp.getVehicleType().name(), dp.getAvgRating());
            }
        }
        return new OrderResponse(o.getId(), o.getOrderNumber(), o.getStatus(), o.getPaymentMethod(),
            o.getPaymentStatus(), o.getSubtotal(), o.getDeliveryFee(), o.getTaxAmount(),
            o.getDiscountAmount(), o.getTotalAmount(), o.getSpecialInstructions(),
            o.getEstimatedDeliveryAt(), o.getDeliveredAt(), o.getCreatedAt(),
            o.getRestaurantId(), r == null ? null : r.getName(),
            addrDto, itemDtos, hist, driverInfo);
    }
}
