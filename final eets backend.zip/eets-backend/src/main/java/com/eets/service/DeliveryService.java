package com.eets.service;

import com.eets.domain.*;
import com.eets.dto.response.DeliveryResponse;
import com.eets.exception.*;
import com.eets.repository.*;
import com.eets.util.HaversineUtil;
import com.eets.websocket.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class DeliveryService {
    private static final SecureRandom RND = new SecureRandom();

    @Value("${eets.delivery.search-radius-km}") private double radiusKm;
    @Value("${eets.commission.driver-base-fee}") private BigDecimal baseFee;
    @Value("${eets.commission.driver-per-km}") private BigDecimal perKm;

    private final DeliveryPartnerRepository drivers;
    private final DeliveryAssignmentRepository assignments;
    private final OrderRepository orders;
    private final RestaurantRepository restaurants;
    private final UserRepository users;
    private final AddressRepository addresses;
    private final DriverSocketService driverSocket;
    private final OrderSocketService orderSocket;
    private final NotificationService notificationService;

    public DeliveryAssignment assignDelivery(Long orderId) {
        Order o = orders.findById(orderId).orElseThrow(() -> new ResourceNotFoundException("Order not found"));
        Restaurant r = restaurants.findById(o.getRestaurantId()).orElseThrow();
        if (r.getLat() == null || r.getLng() == null) {
            log.warn("Restaurant {} missing coordinates - cannot assign", r.getId());
            return null;
        }
        List<DeliveryPartner> available = drivers.findByIsOnlineTrueAndIsVerifiedTrue();

        record Candidate(DeliveryPartner d, double dist, long active) {}
        List<Candidate> ranked = new ArrayList<>();
        for (DeliveryPartner d : available) {
            if (d.getCurrentLat() == null || d.getCurrentLng() == null) continue;
            double dist = HaversineUtil.km(r.getLat(), r.getLng(), d.getCurrentLat(), d.getCurrentLng());
            if (dist > radiusKm) continue;
            long active = assignments.countByDriverIdAndStatus(d.getId(), AssignmentStatus.ACCEPTED)
                + assignments.countByDriverIdAndStatus(d.getId(), AssignmentStatus.PICKED_UP);
            ranked.add(new Candidate(d, dist, active));
        }
        ranked.sort(Comparator.comparingLong((Candidate c) -> c.active)
            .thenComparing(c -> -1 * (c.d.getAvgRating() == null ? 0 : c.d.getAvgRating())));

        if (ranked.isEmpty()) { log.info("No driver found for order {}", orderId); return null; }
        DeliveryPartner chosen = ranked.get(0).d;
        double distance = ranked.get(0).dist;
        BigDecimal earnings = baseFee.add(perKm.multiply(BigDecimal.valueOf(distance))).setScale(2, RoundingMode.HALF_UP);

        DeliveryAssignment a = DeliveryAssignment.builder()
            .orderId(orderId).driverId(chosen.getId())
            .status(AssignmentStatus.ASSIGNED).assignedAt(Instant.now())
            .pickupOtp(String.format("%04d", RND.nextInt(10000)))
            .deliveryOtp(String.format("%04d", RND.nextInt(10000)))
            .distanceKm(distance).earningsAmount(earnings).build();
        a = assignments.save(a);

        Address addr = addresses.findById(o.getDeliveryAddressId()).orElse(null);
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("event", "new_delivery_assignment");
        payload.put("deliveryId", a.getId());
        payload.put("orderId", orderId);
        payload.put("restaurant", Map.of("name", r.getName(), "address", r.getAddressLine(),
            "lat", r.getLat(), "lng", r.getLng()));
        payload.put("customer", Map.of("address", addr == null ? "" : addr.getAddressLine(),
            "lat", addr == null ? null : addr.getLat(), "lng", addr == null ? null : addr.getLng()));
        payload.put("distance", distance);
        payload.put("earning", earnings);
        payload.put("pickupOtp", a.getPickupOtp());
        driverSocket.sendAssignmentToDriver(chosen.getId(), payload);

        notificationService.send(chosen.getUserId(), "New delivery", "Order " + o.getOrderNumber() + " awaits acceptance", "DELIVERY_ASSIGNED", orderId);
        return a;
    }

    public DeliveryResponse acceptAssignment(Long driverUserId, Long assignmentId) {
        DeliveryAssignment a = assignments.findById(assignmentId).orElseThrow(() -> new ResourceNotFoundException("Assignment not found"));
        DeliveryPartner driver = drivers.findByUserId(driverUserId).orElseThrow();
        if (!a.getDriverId().equals(driver.getId())) throw new UnauthorizedException("Not your assignment");
        a.setStatus(AssignmentStatus.ACCEPTED);
        a.setAcceptedAt(Instant.now());
        assignments.save(a);
        Order o = orders.findById(a.getOrderId()).orElseThrow();
        o.setDeliveryPartnerId(driver.getId());
        orders.save(o);
        User driverUser = users.findById(driverUserId).orElseThrow();
        orderSocket.broadcastStatusUpdate(o.getId(),
            Map.of("event", "driver_assigned", "driverName", driverUser.getName(),
                "vehicleType", driver.getVehicleType() == null ? "" : driver.getVehicleType().name(),
                "rating", driver.getAvgRating() == null ? 0 : driver.getAvgRating()));
        return toDto(a, o);
    }

    public void rejectAssignment(Long driverUserId, Long assignmentId, String reason) {
        DeliveryAssignment a = assignments.findById(assignmentId).orElseThrow(() -> new ResourceNotFoundException("Assignment not found"));
        DeliveryPartner driver = drivers.findByUserId(driverUserId).orElseThrow();
        if (!a.getDriverId().equals(driver.getId())) throw new UnauthorizedException("Not your assignment");
        a.setStatus(AssignmentStatus.REJECTED);
        a.setRejectionReason(reason);
        assignments.save(a);
        reassignOrEscalate(a.getOrderId());
    }

    public DeliveryResponse updateStatus(Long driverUserId, Long assignmentId, String status, String otp) {
        DeliveryAssignment a = assignments.findById(assignmentId).orElseThrow(() -> new ResourceNotFoundException("Assignment not found"));
        DeliveryPartner driver = drivers.findByUserId(driverUserId).orElseThrow();
        if (!a.getDriverId().equals(driver.getId())) throw new UnauthorizedException("Not your assignment");
        Order o = orders.findById(a.getOrderId()).orElseThrow();
        switch (status) {
            case "PICKED_UP" -> {
                if (otp == null || !otp.equals(a.getPickupOtp())) throw new BadRequestException("Invalid pickup OTP");
                a.setStatus(AssignmentStatus.PICKED_UP);
                a.setPickedUpAt(Instant.now());
                o.setStatus(OrderStatus.ON_THE_WAY);
                orders.save(o);
                orderSocket.broadcastStatusUpdate(o.getId(), Map.of("event", "status_updated", "status", "ON_THE_WAY"));
                notificationService.send(o.getUserId(), "Order on the way", "Your order " + o.getOrderNumber() + " is out for delivery", "ORDER_STATUS", o.getId());
            }
            case "DELIVERED" -> {
                if (otp == null || !otp.equals(a.getDeliveryOtp())) throw new BadRequestException("Invalid delivery OTP");
                a.setStatus(AssignmentStatus.DELIVERED);
                a.setDeliveredAt(Instant.now());
                o.setStatus(OrderStatus.DELIVERED);
                o.setDeliveredAt(Instant.now());
                orders.save(o);
                driver.setTotalDeliveries((driver.getTotalDeliveries() == null ? 0 : driver.getTotalDeliveries()) + 1);
                drivers.save(driver);
                orderSocket.broadcastStatusUpdate(o.getId(), Map.of("event", "order_delivered"));
                notificationService.send(o.getUserId(), "Order delivered", "Enjoy your meal!", "ORDER_DELIVERED", o.getId());
            }
            default -> throw new BadRequestException("Unsupported status transition");
        }
        assignments.save(a);
        return toDto(a, o);
    }

    public void reassignOrEscalate(Long orderId) {
        DeliveryAssignment fresh = assignDelivery(orderId);
        if (fresh == null) log.warn("Escalating: no driver for order {}", orderId);
    }

    public void retryUnassignedOrders() {
        // Orders in ACCEPTED or PREPARING status with no driver
        // (simple fallback - production would page large lists)
        // intentionally lightweight to keep scheduler fast
    }

    public DeliveryResponse toDto(DeliveryAssignment a, Order o) {
        return new DeliveryResponse(a.getId(), a.getOrderId(), o == null ? null : o.getOrderNumber(),
            a.getStatus(), a.getAssignedAt(), a.getAcceptedAt(), a.getPickedUpAt(), a.getDeliveredAt(),
            a.getPickupOtp(), a.getDeliveryOtp(), a.getDistanceKm(), a.getEarningsAmount());
    }
}
