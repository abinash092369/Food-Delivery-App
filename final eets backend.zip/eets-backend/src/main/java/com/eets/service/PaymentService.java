package com.eets.service;

import com.eets.config.RazorpayConfig;
import com.eets.exception.PaymentException;
import com.eets.util.HmacUtil;
import com.razorpay.RazorpayClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentService {

    private final RazorpayClient client;
    private final RazorpayConfig cfg;

    public record RazorpayOrder(String id, BigDecimal amount, String currency) {}

    public RazorpayOrder createOrder(BigDecimal totalAmount, Long userId) {
        try {
            long paise = totalAmount.multiply(BigDecimal.valueOf(100)).setScale(0, RoundingMode.HALF_UP).longValueExact();
            JSONObject opts = new JSONObject();
            opts.put("amount", paise);
            opts.put("currency", "INR");
            opts.put("receipt", "eets_" + userId + "_" + System.currentTimeMillis());
            com.razorpay.Order rzOrder = client.orders.create(opts);
            String id = rzOrder.get("id");
            log.info("Razorpay order created: {} for user={}", id, userId);
            return new RazorpayOrder(id, totalAmount, "INR");
        } catch (Exception e) {
            log.error("Razorpay order failed", e);
            throw new PaymentException("Failed to create payment order");
        }
    }

    public void verifySignature(String orderId, String paymentId, String signature) {
        String payload = orderId + "|" + paymentId;
        if (!HmacUtil.verify(payload, cfg.getKeySecret(), signature))
            throw new PaymentException("Signature mismatch");
        log.info("Payment verified for order {}", orderId);
    }

    public void refund(String paymentId, BigDecimal amount) {
        if (paymentId == null) { log.info("No payment id to refund (COD?)"); return; }
        try {
            long paise = amount.multiply(BigDecimal.valueOf(100)).setScale(0, RoundingMode.HALF_UP).longValueExact();
            JSONObject opts = new JSONObject();
            opts.put("amount", paise);
            client.payments.refund(paymentId, opts);
            log.info("Refund initiated: payment={} amount={}", paymentId, amount);
        } catch (Exception e) {
            log.error("Refund failed for payment {}", paymentId, e);
            throw new PaymentException("Refund failed");
        }
    }

    public String getKeyId() { return cfg.getKeyId(); }
}
