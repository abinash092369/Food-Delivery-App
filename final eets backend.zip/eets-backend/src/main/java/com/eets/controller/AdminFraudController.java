package com.eets.controller;

import com.eets.domain.FraudStatus;
import com.eets.dto.response.FraudFlagResponse;
import com.eets.service.AdminService;
import com.eets.util.ApiResponse;
import com.eets.util.PageResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/admin/fraud")
@RequiredArgsConstructor
public class AdminFraudController {
    private final AdminService admin;
    @GetMapping
    public ApiResponse<PageResponse<FraudFlagResponse>> list(@RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size, @RequestParam(required = false) FraudStatus status) {
        return ApiResponse.ok(admin.listFlags(page, size, status));
    }
    @PatchMapping("/{id}/status")
    public ApiResponse<Map<String, String>> setStatus(@PathVariable Long id, @RequestParam FraudStatus status) {
        admin.resolveFlag(id, status); return ApiResponse.ok(Map.of("status", "updated"));
    }
}
