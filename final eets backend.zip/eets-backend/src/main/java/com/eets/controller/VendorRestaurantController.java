package com.eets.controller;

import com.eets.dto.request.*;
import com.eets.dto.response.*;
import com.eets.security.CurrentUser;
import com.eets.service.*;
import com.eets.util.ApiResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/vendor/restaurant")
@RequiredArgsConstructor
public class VendorRestaurantController {
    private final VendorService vendor;
    private final RestaurantService restaurantService;

    @GetMapping
    public ApiResponse<RestaurantDetailResponse> get() {
        return ApiResponse.ok(vendor.getMyRestaurant(CurrentUser.id(), restaurantService));
    }
    @PutMapping
    public ApiResponse<RestaurantDetailResponse> update(@Valid @RequestBody RestaurantUpdateRequest req) {
        return ApiResponse.ok(vendor.updateMyRestaurant(CurrentUser.id(), req, restaurantService));
    }
    @PatchMapping("/status")
    public ApiResponse<Map<String, Boolean>> toggle() {
        return ApiResponse.ok(vendor.toggleStatus(CurrentUser.id()));
    }
}
