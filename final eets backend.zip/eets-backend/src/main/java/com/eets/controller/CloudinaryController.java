package com.eets.controller;

import com.eets.dto.request.CloudinarySignRequest;
import com.eets.dto.response.CloudinarySignResponse;
import com.eets.service.CloudinaryService;
import com.eets.util.ApiResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cloudinary")
@RequiredArgsConstructor
public class CloudinaryController {
    private final CloudinaryService cloudinary;

    @PostMapping("/sign-upload")
    public ApiResponse<CloudinarySignResponse> sign(@Valid @RequestBody CloudinarySignRequest req) {
        return ApiResponse.ok(cloudinary.sign(req.folder()));
    }
}
