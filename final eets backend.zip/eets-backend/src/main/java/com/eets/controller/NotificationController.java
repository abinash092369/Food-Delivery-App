package com.eets.controller;

import com.eets.dto.response.NotificationResponse;
import com.eets.security.CurrentUser;
import com.eets.service.NotificationService;
import com.eets.util.ApiResponse;
import com.eets.util.PageResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class NotificationController {
    private final NotificationService notifications;

    @GetMapping
    public ApiResponse<PageResponse<NotificationResponse>> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "false") boolean unreadOnly) {
        return ApiResponse.ok(notifications.list(CurrentUser.id(), page, size, unreadOnly));
    }
    @PatchMapping("/{id}/read")
    public ApiResponse<Map<String, String>> read(@PathVariable Long id) {
        notifications.markRead(CurrentUser.id(), id);
        return ApiResponse.ok(Map.of("status", "ok"));
    }
    @PatchMapping("/read-all")
    public ApiResponse<Map<String, String>> readAll() {
        notifications.markAllRead(CurrentUser.id());
        return ApiResponse.ok(Map.of("status", "ok"));
    }
}
