package com.eets.controller;

import com.eets.dto.response.*;
import com.eets.repository.*;
import com.eets.service.MenuService;
import com.eets.service.RestaurantService;
import com.eets.util.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/search")
@RequiredArgsConstructor
public class SearchController {
    private final RestaurantRepository restaurants;
    private final MenuItemRepository items;
    private final RestaurantService restaurantService;
    private final MenuService menuService;

    @GetMapping
    public ApiResponse<Map<String, Object>> global(@RequestParam(required = false) String q,
                                                    @RequestParam(required = false) String city,
                                                    @RequestParam(defaultValue = "10") int limit) {
        var rs = restaurants.searchPublic(city, q, PageRequest.of(0, limit))
            .map(r -> restaurantService.toCard(r, null, null)).getContent();
        var its = items.search(q == null ? "" : q, PageRequest.of(0, limit))
            .map(menuService::toItem).getContent();
        return ApiResponse.ok(Map.of("restaurants", rs, "items", its));
    }
}
