package com.eets.dto.request;

import jakarta.validation.constraints.*;
import java.util.List;
public record VendorRegisterRequest(
    @NotBlank String name, @NotBlank @Email String email,
    @NotBlank String password, @NotBlank String phone,
    @NotBlank String restaurantName, String description,
    List<String> cuisineTypes, String coverImageUrl, String logoUrl,
    String addressLine, String city, String state, String pincode,
    Double lat, Double lng, String fssaiLicense, String gstNumber) {}
