package com.eets.dto.request;

import jakarta.validation.constraints.*;
import java.util.List;
public record AddToCartRequest(
    @NotNull Long menuItemId,
    @Min(1) int quantity,
    List<SelectedOption> selectedOptions) {
    public record SelectedOption(Long groupId, Long optionId) {}
}
