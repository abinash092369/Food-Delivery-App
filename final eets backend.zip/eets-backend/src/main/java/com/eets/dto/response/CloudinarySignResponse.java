package com.eets.dto.response;

public record CloudinarySignResponse(String signature, long timestamp, String apiKey, String cloudName, String folder) {}
