package com.eets.dto.request;

public record DriverProfileUpdateRequest(String name, String email, String profileImageUrl,
    String bankAccountNumber, String bankIfsc, String upiId) {}
