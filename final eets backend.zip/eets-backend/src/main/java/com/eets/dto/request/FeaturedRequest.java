package com.eets.dto.request;

public record FeaturedRequest(Boolean isFeatured) {}
