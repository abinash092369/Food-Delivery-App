package com.eets.dto.request;

import jakarta.validation.constraints.NotBlank;
public record CloudinarySignRequest(@NotBlank String folder) {}
