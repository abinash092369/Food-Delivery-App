package com.eets.dto.request;

public record AvailabilityRequest(Boolean isAvailable) {}
