package com.eets.dto.response;

import java.math.BigDecimal;
import java.util.List;
public record RestaurantCardResponse(Long id, String name, String slug, String coverImageUrl,
    List<String> cuisineTypes, Double avgRating, Integer totalRatings,
    Integer deliveryTimeMin, BigDecimal deliveryFee, BigDecimal minOrderAmount,
    Boolean isOpen, Double distance) {}
