package com.eets.dto.request;

import com.eets.domain.VehicleType;
import jakarta.validation.constraints.*;
public record DriverRegisterRequest(
    @NotBlank String name, @NotBlank @Pattern(regexp="^[6-9]\\d{9}$") String phone,
    @Email String email, String dob,
    @NotNull VehicleType vehicleType, String vehicleMake, String vehicleModel,
    @NotBlank String vehicleRegNumber,
    String aadhaarFrontUrl, String aadhaarBackUrl, String licenseUrl, String rcUrl, String selfieUrl,
    String bankAccountNumber, String bankIfsc, String upiId) {}
