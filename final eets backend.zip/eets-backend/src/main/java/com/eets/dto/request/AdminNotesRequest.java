package com.eets.dto.request;

public record AdminNotesRequest(String adminNotes) {}
