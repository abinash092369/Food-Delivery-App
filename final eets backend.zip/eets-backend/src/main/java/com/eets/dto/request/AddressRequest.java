package com.eets.dto.request;

import com.eets.domain.AddressLabel;
import jakarta.validation.constraints.*;
public record AddressRequest(
    @NotNull AddressLabel label,
    @NotBlank String addressLine, String city, String state,
    @Pattern(regexp="^\\d{6}$") String pincode,
    Double lat, Double lng, Boolean isDefault) {}
