package com.eets.dto.request;

public record NotificationPrefRequest(Boolean push, Boolean email, Boolean sms, Boolean orderUpdates, Boolean promotions) {}
