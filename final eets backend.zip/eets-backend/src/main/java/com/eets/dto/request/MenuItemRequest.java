package com.eets.dto.request;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.util.List;
public record MenuItemRequest(
    @NotBlank String name, String description,
    @NotNull @DecimalMin("0.01") BigDecimal price,
    @NotNull Long categoryId, Boolean isVeg, String imageUrl,
    Boolean isAvailable, Boolean isFeatured,
    List<CustomizationGroup> customizationGroups) {
    public record CustomizationGroup(String name, com.eets.domain.CustomizationType type, Boolean isRequired, List<Option> options) {}
    public record Option(String name, BigDecimal extraPrice) {}
}
