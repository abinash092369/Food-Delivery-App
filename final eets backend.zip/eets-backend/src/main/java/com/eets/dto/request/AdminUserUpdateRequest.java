package com.eets.dto.request;

public record AdminUserUpdateRequest(String name, String email, Boolean isActive) {}
