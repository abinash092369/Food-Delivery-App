package com.eets.websocket;

import com.eets.repository.DeliveryPartnerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.stereotype.Controller;

import java.time.Duration;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class DriverLocationController {

    private final DeliveryPartnerRepository driverRepo;
    private final OrderSocketService orderSocket;
    private final StringRedisTemplate redis;

    @MessageMapping("/driver/location")
    public void onLocation(Map<String, Object> body) {
        Long driverId = ((Number) body.get("driverId")).longValue();
        Double lat = ((Number) body.get("lat")).doubleValue();
        Double lng = ((Number) body.get("lng")).doubleValue();
        Object orderIdObj = body.get("orderId");
        Long orderId = orderIdObj == null ? null : ((Number) orderIdObj).longValue();

        // throttle DB writes to ~ 1 per 5 seconds per driver
        String key = "driver:loc:throttle:" + driverId;
        Boolean ok = redis.opsForValue().setIfAbsent(key, "1", Duration.ofSeconds(5));
        if (Boolean.TRUE.equals(ok)) {
            driverRepo.findById(driverId).ifPresent(d -> {
                d.setCurrentLat(lat); d.setCurrentLng(lng);
                driverRepo.save(d);
            });
        }
        if (orderId != null) orderSocket.notifyDriverLocation(orderId, lat, lng, null);
    }
}
