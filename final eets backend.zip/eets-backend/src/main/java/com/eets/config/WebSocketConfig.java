package com.eets.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.*;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Value("${eets.frontend-urls.customer}") String customerUrl;
    @Value("${eets.frontend-urls.admin}") String adminUrl;
    @Value("${eets.frontend-urls.vendor}") String vendorUrl;
    @Value("${eets.frontend-urls.driver}") String driverUrl;

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        config.enableSimpleBroker("/topic", "/queue");
        config.setApplicationDestinationPrefixes("/app");
        config.setUserDestinationPrefix("/user");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws")
            .setAllowedOrigins(customerUrl, adminUrl, vendorUrl, driverUrl)
            .withSockJS();
    }
}
