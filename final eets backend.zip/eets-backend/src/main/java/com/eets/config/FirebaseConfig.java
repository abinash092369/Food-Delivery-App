package com.eets.config;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.*;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.io.FileInputStream;

@Slf4j
@Configuration
public class FirebaseConfig {
    @Value("${firebase.service-account-path:}") String path;

    @PostConstruct
    public void init() {
        if (path == null || path.isBlank()) { log.info("Firebase disabled (no service account path)"); return; }
        try (FileInputStream in = new FileInputStream(path)) {
            FirebaseOptions opts = FirebaseOptions.builder()
                .setCredentials(GoogleCredentials.fromStream(in)).build();
            if (FirebaseApp.getApps().isEmpty()) FirebaseApp.initializeApp(opts);
            log.info("Firebase initialized");
        } catch (Exception e) {
            log.warn("Firebase init failed: {}", e.getMessage());
        }
    }
}
