import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CartItem, MenuItem } from "@/types";

interface CartState {
  items: CartItem[];
  restaurantId: string | null;
  restaurantName: string | null;
  addItem: (item: MenuItem, restaurantName: string) => { ok: boolean; conflict?: boolean };
  forceAdd: (item: MenuItem, restaurantName: string) => void;
  removeItem: (id: string) => void;
  updateQty: (id: string, qty: number) => void;
  clear: () => void;
  subtotal: () => number;
  itemCount: () => number;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      restaurantId: null,
      restaurantName: null,
      addItem: (item, restaurantName) => {
        const { restaurantId, items } = get();
        if (restaurantId && restaurantId !== item.restaurantId && items.length > 0) {
          return { ok: false, conflict: true };
        }
        const existing = items.find((i) => i.id === item.id);
        if (existing) {
          set({ items: items.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i)) });
        } else {
          set({
            items: [...items, { ...item, quantity: 1 }],
            restaurantId: item.restaurantId,
            restaurantName,
          });
        }
        return { ok: true };
      },
      forceAdd: (item, restaurantName) => {
        set({
          items: [{ ...item, quantity: 1 }],
          restaurantId: item.restaurantId,
          restaurantName,
        });
      },
      removeItem: (id) => {
        const items = get().items.filter((i) => i.id !== id);
        set({
          items,
          restaurantId: items.length ? get().restaurantId : null,
          restaurantName: items.length ? get().restaurantName : null,
        });
      },
      updateQty: (id, qty) => {
        if (qty <= 0) {
          get().removeItem(id);
          return;
        }
        set({ items: get().items.map((i) => (i.id === id ? { ...i, quantity: qty } : i)) });
      },
      clear: () => set({ items: [], restaurantId: null, restaurantName: null }),
      subtotal: () => get().items.reduce((s, i) => s + i.price * i.quantity, 0),
      itemCount: () => get().items.reduce((s, i) => s + i.quantity, 0),
    }),
    { name: "eets-cart" }
  )
);
