import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, Phone, Lock } from "lucide-react";
import { motion } from "framer-motion";
import { Logo } from "@/components/shared/Logo";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Log in — eets" }] }),
  component: LoginPage,
});

function LoginPage() {
  const [tab, setTab] = useState<"email" | "phone">("email");

  return (
    <div className="mx-auto flex min-h-[80vh] max-w-md items-center px-4 py-12">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full rounded-2xl bg-card p-7 ring-1 ring-border">
        <div className="flex flex-col items-center text-center">
          <Logo className="h-14 w-14" />
          <h1 className="mt-4 text-2xl font-bold">Welcome back</h1>
          <p className="mt-1 text-sm text-muted-foreground">Log in to continue ordering</p>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-1 rounded-xl bg-secondary p-1">
          <TabBtn active={tab === "email"} onClick={() => setTab("email")}><Mail className="h-4 w-4" /> Email</TabBtn>
          <TabBtn active={tab === "phone"} onClick={() => setTab("phone")}><Phone className="h-4 w-4" /> Phone</TabBtn>
        </div>

        <form
          onSubmit={(e) => { e.preventDefault(); toast.success("Backend coming soon — UI ready"); }}
          className="mt-6 space-y-3"
        >
          {tab === "email" ? (
            <>
              <Field icon={<Mail className="h-4 w-4" />} type="email" placeholder="you@example.com" />
              <Field icon={<Lock className="h-4 w-4" />} type="password" placeholder="Password" />
              <div className="flex justify-end">
                <Link to="/" className="text-xs text-primary hover:underline">Forgot password?</Link>
              </div>
            </>
          ) : (
            <>
              <div className="flex gap-2">
                <select className="rounded-[10px] border border-input bg-secondary px-2 text-sm">
                  <option>🇮🇳 +91</option><option>🇺🇸 +1</option><option>🇬🇧 +44</option>
                </select>
                <Field icon={<Phone className="h-4 w-4" />} type="tel" placeholder="98765 43210" />
              </div>
              <p className="text-xs text-muted-foreground">We'll send you a 6-digit OTP to verify.</p>
            </>
          )}
          <button className="w-full rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground shadow-[var(--shadow-glow)] transition hover:bg-primary/90">
            {tab === "email" ? "Log in" : "Send OTP"}
          </button>
        </form>

        <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
          <div className="h-px flex-1 bg-border" /> OR <div className="h-px flex-1 bg-border" />
        </div>
        <button className="flex w-full items-center justify-center gap-2 rounded-xl border border-border bg-secondary py-2.5 text-sm font-medium hover:bg-secondary/80">
          <svg className="h-4 w-4" viewBox="0 0 24 24"><path fill="#fff" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09Z"/><path fill="#fff" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.99.66-2.26 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23Z"/></svg>
          Continue with Google
        </button>

        <p className="mt-6 text-center text-sm text-muted-foreground">
          New to eets? <Link to="/login" className="font-semibold text-primary hover:underline">Create account</Link>
        </p>
      </motion.div>
    </div>
  );
}

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button type="button" onClick={onClick} className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-sm font-medium transition ${active ? "bg-card text-foreground shadow" : "text-muted-foreground"}`}>
      {children}
    </button>
  );
}

function Field({ icon, ...rest }: { icon: React.ReactNode } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="flex items-center gap-2 rounded-[10px] border border-input bg-secondary px-3 py-2.5 focus-within:border-primary">
      <span className="text-muted-foreground">{icon}</span>
      <input {...rest} className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground" />
    </label>
  );
}
