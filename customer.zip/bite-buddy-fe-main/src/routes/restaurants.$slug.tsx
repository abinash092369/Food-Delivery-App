import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { restaurants, restaurantMenus, defaultMenu } from "@/lib/mock-data";
import type { MenuCategory, MenuItem } from "@/types";
import { formatCurrency } from "@/lib/format";
import { Star, Clock, Bike, ChevronLeft, Plus, Minus } from "lucide-react";
import { useCartStore } from "@/store/cart.store";
import { useUIStore } from "@/store/ui.store";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { useState } from "react";

export const Route = createFileRoute("/restaurants/$slug")({
  loader: ({ params }) => {
    const r = restaurants.find((x) => x.slug === params.slug);
    if (!r) throw notFound();
    return { restaurant: r, menu: restaurantMenus[params.slug] ?? defaultMenu };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.restaurant.name ?? "Restaurant"} — eets` },
      { name: "description", content: `Order from ${loaderData?.restaurant.name}. ${loaderData?.restaurant.cuisines.join(", ")}.` },
    ],
  }),
  notFoundComponent: () => (
    <div className="mx-auto max-w-md p-12 text-center">
      <h1 className="text-2xl font-semibold">Restaurant not found</h1>
      <Link to="/restaurants" className="mt-4 inline-block text-primary hover:underline">Browse all restaurants</Link>
    </div>
  ),
  errorComponent: ({ error }) => <div className="p-6 text-destructive">{error.message}</div>,
  component: RestaurantDetailPage,
});

function RestaurantDetailPage() {
  const { restaurant: r, menu } = Route.useLoaderData();
  const [activeCat, setActiveCat] = useState(menu[0]?.id);

  return (
    <div>
      <div className="relative h-64 w-full overflow-hidden md:h-80">
        <img src={r.image} alt={r.name} className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background/20" />
        <Link to="/restaurants" className="absolute left-4 top-4 inline-flex items-center gap-1 rounded-full bg-background/80 px-3 py-1.5 text-sm backdrop-blur hover:bg-background">
          <ChevronLeft className="h-4 w-4" /> Back
        </Link>
      </div>

      <div className="mx-auto -mt-20 max-w-7xl px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl bg-card p-6 shadow-2xl ring-1 ring-border">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold md:text-3xl">{r.name}</h1>
              <p className="mt-1 text-sm text-muted-foreground">{r.cuisines.join(" • ")}</p>
              <div className="mt-3 flex flex-wrap items-center gap-4 text-sm">
                <span className="flex items-center gap-1 rounded-md bg-rating/15 px-2 py-0.5 font-bold text-rating">
                  <Star className="h-4 w-4 fill-rating" /> {r.rating}
                </span>
                <span className="text-muted-foreground">({r.ratingCount.toLocaleString()} ratings)</span>
                <span className="flex items-center gap-1 text-muted-foreground"><Clock className="h-4 w-4" /> {r.deliveryTime} min</span>
                <span className="flex items-center gap-1 text-muted-foreground"><Bike className="h-4 w-4" /> {r.distance} km</span>
              </div>
            </div>
            <div className="rounded-xl border border-dashed border-primary/40 bg-primary/5 px-4 py-2">
              <p className="text-xs text-muted-foreground">Min order</p>
              <p className="text-lg font-bold text-primary">{formatCurrency(r.minOrder)}</p>
            </div>
          </div>
        </motion.div>

        <div className="mt-8 grid grid-cols-1 gap-8 md:grid-cols-[220px_1fr]">
          <aside className="md:sticky md:top-20 md:self-start">
            <h3 className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Menu</h3>
            <nav className="scrollbar-hide flex gap-2 overflow-x-auto md:flex-col md:gap-1">
              {(menu as MenuCategory[]).map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    setActiveCat(c.id);
                    document.getElementById(`cat-${c.id}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
                  }}
                  className={`shrink-0 rounded-lg px-3 py-2 text-left text-sm font-medium transition ${activeCat === c.id ? "bg-primary/15 text-primary" : "text-muted-foreground hover:bg-secondary hover:text-foreground"}`}
                >
                  {c.name} <span className="text-xs opacity-60">({c.items.length})</span>
                </button>
              ))}
            </nav>
          </aside>

          <div className="space-y-10 pb-12">
            {(menu as MenuCategory[]).map((cat: MenuCategory) => (
              <section key={cat.id} id={`cat-${cat.id}`}>
                <h2 className="text-xl font-semibold">{cat.name}</h2>
                <div className="mt-4 divide-y divide-border">
                  {cat.items.map((item: MenuItem) => (
                    <MenuItemRow key={item.id} item={item} restaurantName={r.name} />
                  ))}
                </div>
              </section>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MenuItemRow({ item, restaurantName }: { item: import("@/types").MenuItem; restaurantName: string }) {
  const { items, addItem, updateQty, forceAdd } = useCartStore();
  const setCartOpen = useUIStore((s) => s.setCartOpen);
  const inCart = items.find((i) => i.id === item.id);

  const handleAdd = () => {
    const res = addItem(item, restaurantName);
    if (!res.ok && res.conflict) {
      if (confirm(`Clear cart and add from ${restaurantName}?`)) {
        forceAdd(item, restaurantName);
        toast.success(`Added ${item.name}`);
      }
    } else {
      toast.success(`Added ${item.name}`);
      setCartOpen(true);
    }
  };

  return (
    <div className="flex gap-4 py-5">
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <div className={`flex h-4 w-4 items-center justify-center rounded-sm border-2 ${item.isVeg ? "border-veg" : "border-nonveg"}`}>
            <div className={`h-2 w-2 rounded-full ${item.isVeg ? "bg-veg" : "bg-nonveg"}`} />
          </div>
          {item.bestseller && <span className="rounded bg-rating/15 px-1.5 py-0.5 text-[10px] font-bold text-rating">★ BESTSELLER</span>}
        </div>
        <h3 className="mt-1 text-base font-semibold">{item.name}</h3>
        <p className="mt-1 text-sm font-bold">{formatCurrency(item.price)}</p>
        <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{item.description}</p>
      </div>
      <div className="flex flex-col items-end gap-2">
        {item.image && (
          <div className="h-24 w-24 overflow-hidden rounded-xl bg-secondary md:h-28 md:w-28">
            <img src={item.image} alt={item.name} loading="lazy" className="h-full w-full object-cover" />
          </div>
        )}
        {inCart ? (
          <div className="flex items-center gap-1 rounded-lg bg-card ring-1 ring-primary">
            <button onClick={() => updateQty(item.id, inCart.quantity - 1)} className="px-2.5 py-1.5 text-primary"><Minus className="h-3.5 w-3.5" /></button>
            <span className="min-w-[1.5rem] text-center text-sm font-bold text-primary">{inCart.quantity}</span>
            <button onClick={() => updateQty(item.id, inCart.quantity + 1)} className="px-2.5 py-1.5 text-primary"><Plus className="h-3.5 w-3.5" /></button>
          </div>
        ) : (
          <button onClick={handleAdd} className="inline-flex items-center gap-1 rounded-lg border border-primary bg-primary/10 px-4 py-1.5 text-sm font-semibold text-primary hover:bg-primary hover:text-primary-foreground transition">
            <Plus className="h-4 w-4" /> Add
          </button>
        )}
      </div>
    </div>
  );
}
