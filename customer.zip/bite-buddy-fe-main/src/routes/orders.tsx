import { createFileRoute } from "@tanstack/react-router";
import { Package } from "lucide-react";

export const Route = createFileRoute("/orders")({
  head: () => ({ meta: [{ title: "Your Orders — eets" }] }),
  component: () => (
    <div className="mx-auto max-w-md py-24 text-center px-4">
      <div className="mx-auto inline-flex rounded-full bg-secondary p-6"><Package className="h-10 w-10 text-muted-foreground" /></div>
      <h1 className="mt-5 text-2xl font-semibold">No orders yet</h1>
      <p className="mt-2 text-muted-foreground">Your past orders will show up here.</p>
    </div>
  ),
});
