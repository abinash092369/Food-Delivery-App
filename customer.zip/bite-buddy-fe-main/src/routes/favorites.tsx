import { createFileRoute } from "@tanstack/react-router";
import { Heart } from "lucide-react";

export const Route = createFileRoute("/favorites")({
  head: () => ({ meta: [{ title: "Favorites — eets" }] }),
  component: () => (
    <div className="mx-auto max-w-md py-24 text-center px-4">
      <div className="mx-auto inline-flex rounded-full bg-secondary p-6"><Heart className="h-10 w-10 text-muted-foreground" /></div>
      <h1 className="mt-5 text-2xl font-semibold">No favorites yet</h1>
      <p className="mt-2 text-muted-foreground">Tap the heart on any restaurant to save it here.</p>
    </div>
  ),
});
