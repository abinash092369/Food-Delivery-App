import { createFileRoute } from "@tanstack/react-router";
import { Hero } from "@/components/home/Hero";
import { CategoryRow } from "@/components/home/CategoryRow";
import { FeaturedRestaurants } from "@/components/home/FeaturedRestaurants";
import { TrendingDishes } from "@/components/home/TrendingDishes";
import { OffersBanner } from "@/components/home/OffersBanner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "eets — Crave it. Tap it. Eat it." },
      { name: "description", content: "Discover and order from 3,000+ restaurants near you. Delivered hot in 25 minutes." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="space-y-14 pb-10">
      <Hero />
      <CategoryRow />
      <FeaturedRestaurants />
      <OffersBanner />
      <TrendingDishes />
    </div>
  );
}
