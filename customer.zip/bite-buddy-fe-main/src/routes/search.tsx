import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useState } from "react";
import { restaurants, trendingDishes } from "@/lib/mock-data";
import { RestaurantCard } from "@/components/restaurant/RestaurantCard";

export const Route = createFileRoute("/search")({
  head: () => ({ meta: [{ title: "Search — eets" }] }),
  component: SearchPage,
});

function SearchPage() {
  const [q, setQ] = useState("");
  const ql = q.toLowerCase().trim();
  const rests = ql ? restaurants.filter((r) => r.name.toLowerCase().includes(ql) || r.cuisines.some((c) => c.toLowerCase().includes(ql))) : [];
  const dishes = ql ? trendingDishes.filter((d) => d.name.toLowerCase().includes(ql)) : [];

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="text-3xl font-bold">Search</h1>
      <div className="mt-5 flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-3 focus-within:border-primary">
        <Search className="h-5 w-5 text-muted-foreground" />
        <input
          autoFocus value={q} onChange={(e) => setQ(e.target.value)}
          placeholder="Search restaurants or dishes…"
          className="w-full bg-transparent text-base outline-none placeholder:text-muted-foreground"
        />
      </div>

      {!ql && <p className="mt-8 text-center text-sm text-muted-foreground">Start typing to find your next meal.</p>}
      {ql && rests.length === 0 && dishes.length === 0 && (
        <p className="mt-8 text-center text-sm text-muted-foreground">No matches for "{q}"</p>
      )}

      {dishes.length > 0 && (
        <section className="mt-8">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">Dishes</h2>
          <div className="mt-3 space-y-2">
            {dishes.map((d) => (
              <div key={d.id} className="flex items-center gap-3 rounded-xl bg-card p-3 ring-1 ring-border">
                {d.image && <img src={d.image} className="h-14 w-14 rounded-lg object-cover" alt={d.name} />}
                <div className="flex-1"><p className="font-medium">{d.name}</p><p className="text-xs text-muted-foreground">{d.restaurantName}</p></div>
              </div>
            ))}
          </div>
        </section>
      )}
      {rests.length > 0 && (
        <section className="mt-8">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">Restaurants</h2>
          <div className="mt-3 grid gap-4 sm:grid-cols-2">
            {rests.map((r) => <RestaurantCard key={r.id} restaurant={r} />)}
          </div>
        </section>
      )}
    </div>
  );
}
