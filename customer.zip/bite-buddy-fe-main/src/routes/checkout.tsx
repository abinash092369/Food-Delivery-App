import { createFileRoute, Link } from "@tanstack/react-router";
import { useCartStore } from "@/store/cart.store";
import { formatCurrency } from "@/lib/format";
import { MapPin, CreditCard, Wallet, Banknote } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/checkout")({
  head: () => ({ meta: [{ title: "Checkout — eets" }] }),
  component: CheckoutPage,
});

const DELIVERY_FEE = 39;
const GST = 0.05;

function CheckoutPage() {
  const { items, subtotal, restaurantName, clear } = useCartStore();
  const [pay, setPay] = useState<"razorpay" | "upi" | "cod">("razorpay");
  const sub = subtotal();
  const taxes = Math.round(sub * GST);
  const total = sub + (sub > 0 ? DELIVERY_FEE + taxes : 0);

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-md py-20 text-center">
        <h1 className="text-2xl font-semibold">Your cart is empty</h1>
        <Link to="/restaurants" className="mt-4 inline-block rounded-xl bg-primary px-5 py-2.5 font-semibold text-primary-foreground">Browse restaurants</Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="text-3xl font-bold">Checkout</h1>
      <p className="mt-1 text-muted-foreground">Order from {restaurantName}</p>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_380px]">
        <div className="space-y-6">
          <section className="rounded-2xl bg-card p-5 ring-1 ring-border">
            <h2 className="flex items-center gap-2 text-lg font-semibold"><MapPin className="h-5 w-5 text-primary" /> Delivery Address</h2>
            <div className="mt-4 space-y-2">
              {[
                { tag: "Home", line: "Flat 402, 7th Cross, HSR Layout Sector 5, Bengaluru — 560102" },
                { tag: "Work", line: "Embassy Tech Square, Outer Ring Rd, Bengaluru — 560103" },
              ].map((a, i) => (
                <label key={i} className="flex cursor-pointer items-start gap-3 rounded-xl border border-border bg-secondary/40 p-4 has-[:checked]:border-primary has-[:checked]:bg-primary/5">
                  <input type="radio" name="addr" defaultChecked={i === 0} className="mt-1 accent-primary" />
                  <div>
                    <p className="text-sm font-semibold">{a.tag}</p>
                    <p className="mt-0.5 text-sm text-muted-foreground">{a.line}</p>
                  </div>
                </label>
              ))}
              <button className="text-sm font-medium text-primary hover:underline">+ Add new address</button>
            </div>
          </section>

          <section className="rounded-2xl bg-card p-5 ring-1 ring-border">
            <h2 className="flex items-center gap-2 text-lg font-semibold"><CreditCard className="h-5 w-5 text-primary" /> Payment Method</h2>
            <div className="mt-4 grid gap-2 sm:grid-cols-3">
              <PayOpt active={pay === "razorpay"} onClick={() => setPay("razorpay")} icon={<CreditCard />} label="Card / Razorpay" />
              <PayOpt active={pay === "upi"} onClick={() => setPay("upi")} icon={<Wallet />} label="UPI" />
              <PayOpt active={pay === "cod"} onClick={() => setPay("cod")} icon={<Banknote />} label="Cash on Delivery" />
            </div>
            {pay === "upi" && (
              <input placeholder="yourname@okhdfcbank" className="mt-4 w-full rounded-[10px] border border-input bg-secondary px-3 py-2.5 text-sm outline-none focus:border-primary" />
            )}
          </section>
        </div>

        <aside className="h-fit rounded-2xl bg-card-elevated p-5 ring-1 ring-border lg:sticky lg:top-20">
          <h2 className="text-lg font-semibold">Order Summary</h2>
          <div className="mt-4 space-y-2 border-b border-border pb-4">
            {items.map((it) => (
              <div key={it.id} className="flex justify-between text-sm">
                <span className="text-muted-foreground">{it.quantity} × {it.name}</span>
                <span>{formatCurrency(it.price * it.quantity)}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 space-y-1.5 text-sm text-muted-foreground">
            <Row label="Subtotal" v={formatCurrency(sub)} />
            <Row label="Delivery fee" v={formatCurrency(DELIVERY_FEE)} />
            <Row label="GST" v={formatCurrency(taxes)} />
            <div className="my-2 border-t border-border" />
            <Row label={<strong className="text-foreground">Total</strong>} v={<strong className="text-foreground text-base">{formatCurrency(total)}</strong>} />
          </div>
          <button
            onClick={() => { toast.success("Order placed! (demo — payment backend pending)"); clear(); }}
            className="mt-5 w-full rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground shadow-[var(--shadow-glow)] transition hover:bg-primary/90"
          >
            Place Order · {formatCurrency(total)}
          </button>
        </aside>
      </div>
    </div>
  );
}

function PayOpt({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button onClick={onClick} className={`flex flex-col items-center gap-1.5 rounded-xl border p-3 text-xs font-medium transition ${active ? "border-primary bg-primary/10 text-primary" : "border-border bg-secondary text-muted-foreground hover:border-primary/40"}`}>
      <span className="[&>svg]:h-5 [&>svg]:w-5">{icon}</span>
      {label}
    </button>
  );
}
function Row({ label, v }: { label: React.ReactNode; v: React.ReactNode }) {
  return <div className="flex justify-between"><span>{label}</span><span>{v}</span></div>;
}
