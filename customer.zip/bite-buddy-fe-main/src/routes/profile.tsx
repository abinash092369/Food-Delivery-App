import { createFileRoute } from "@tanstack/react-router";
import { User, MapPin, CreditCard, Bell, Heart, LogOut } from "lucide-react";

export const Route = createFileRoute("/profile")({
  head: () => ({ meta: [{ title: "Profile — eets" }] }),
  component: ProfilePage,
});

function ProfilePage() {
  const items = [
    { icon: User, label: "Account details" },
    { icon: MapPin, label: "Saved addresses" },
    { icon: CreditCard, label: "Payment methods" },
    { icon: Heart, label: "Favorites" },
    { icon: Bell, label: "Notifications" },
    { icon: LogOut, label: "Log out" },
  ];

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <div className="flex items-center gap-4 rounded-2xl bg-card-gradient p-6 ring-1 ring-border">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary text-2xl font-bold text-primary-foreground">A</div>
        <div>
          <h1 className="text-xl font-bold">Aarav Sharma</h1>
          <p className="text-sm text-muted-foreground">aarav@example.com • +91 98765 43210</p>
        </div>
      </div>
      <div className="mt-6 divide-y divide-border rounded-2xl bg-card ring-1 ring-border">
        {items.map(({ icon: Icon, label }) => (
          <button key={label} className="flex w-full items-center gap-3 px-5 py-4 text-left hover:bg-secondary/50">
            <Icon className="h-5 w-5 text-primary" />
            <span className="flex-1 text-sm font-medium">{label}</span>
            <span className="text-muted-foreground">›</span>
          </button>
        ))}
      </div>
    </div>
  );
}
