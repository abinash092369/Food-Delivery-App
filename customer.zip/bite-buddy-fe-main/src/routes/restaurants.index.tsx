import { createFileRoute } from "@tanstack/react-router";
import { restaurants, categories } from "@/lib/mock-data";
import { RestaurantCard } from "@/components/restaurant/RestaurantCard";
import { useState, useMemo } from "react";
import { SlidersHorizontal, Star } from "lucide-react";

export const Route = createFileRoute("/restaurants/")({
  head: () => ({ meta: [{ title: "All Restaurants — eets" }] }),
  component: RestaurantsPage,
});

function RestaurantsPage() {
  const [sort, setSort] = useState<"relevance" | "rating" | "delivery">("relevance");
  const [vegOnly, setVegOnly] = useState(false);
  const [activeCat, setActiveCat] = useState<string | null>(null);

  const list = useMemo(() => {
    let r = [...restaurants];
    if (activeCat) r = r.filter((x) => x.cuisines.some((c) => c.toLowerCase().includes(activeCat.toLowerCase())));
    if (sort === "rating") r.sort((a, b) => b.rating - a.rating);
    if (sort === "delivery") r.sort((a, b) => a.deliveryTime - b.deliveryTime);
    return r;
    void vegOnly;
  }, [sort, activeCat, vegOnly]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="text-3xl font-bold">All Restaurants</h1>
      <p className="mt-1 text-muted-foreground">{list.length} places delivering to you</p>

      <div className="scrollbar-hide mt-6 flex gap-2 overflow-x-auto pb-2">
        <button onClick={() => setActiveCat(null)} className={`shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition ${!activeCat ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground hover:border-primary/40"}`}>All</button>
        {categories.map((c) => (
          <button key={c.id} onClick={() => setActiveCat(c.name)} className={`shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition ${activeCat === c.name ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground hover:border-primary/40"}`}>
            <span className="mr-1">{c.emoji}</span>{c.name}
          </button>
        ))}
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-2">
        <span className="flex items-center gap-1.5 text-sm text-muted-foreground"><SlidersHorizontal className="h-4 w-4" /> Filters:</span>
        <FilterChip active={sort === "rating"} onClick={() => setSort(sort === "rating" ? "relevance" : "rating")}>
          <Star className="h-3.5 w-3.5" /> Top Rated
        </FilterChip>
        <FilterChip active={sort === "delivery"} onClick={() => setSort(sort === "delivery" ? "relevance" : "delivery")}>
          Fastest Delivery
        </FilterChip>
        <FilterChip active={vegOnly} onClick={() => setVegOnly(!vegOnly)}>Pure Veg</FilterChip>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((r) => <RestaurantCard key={r.id} restaurant={r} />)}
      </div>
    </div>
  );
}

function FilterChip({ children, active, onClick }: { children: React.ReactNode; active?: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition ${active ? "border-primary bg-primary/15 text-primary" : "border-border bg-card text-muted-foreground hover:border-primary/40"}`}>
      {children}
    </button>
  );
}
