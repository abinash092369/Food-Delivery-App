export interface Restaurant {
  id: string;
  slug: string;
  name: string;
  image: string;
  cuisines: string[];
  rating: number;
  ratingCount: number;
  deliveryTime: number; // minutes
  minOrder: number;
  distance: number; // km
  isOpen: boolean;
  priceLevel: 1 | 2 | 3;
  offer?: string;
}

export interface MenuCategory {
  id: string;
  name: string;
  items: MenuItem[];
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image?: string;
  isVeg: boolean;
  rating?: number;
  bestseller?: boolean;
  restaurantId: string;
  restaurantName?: string;
}

export interface CartItem extends MenuItem {
  quantity: number;
}

export interface Category {
  id: string;
  name: string;
  emoji: string;
}

export interface Offer {
  id: string;
  title: string;
  description: string;
  code: string;
  discount: string;
}
