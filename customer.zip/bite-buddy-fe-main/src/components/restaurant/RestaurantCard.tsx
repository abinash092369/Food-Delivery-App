import { Link } from "@tanstack/react-router";
import { Star, Clock, Bike } from "lucide-react";
import { motion } from "framer-motion";
import type { Restaurant } from "@/types";
import { formatCurrency } from "@/lib/format";

export function RestaurantCard({ restaurant: r, compact = false }: { restaurant: Restaurant; compact?: boolean }) {
  return (
    <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300, damping: 28 }}>
      <Link
        to="/restaurants/$slug"
        params={{ slug: r.slug }}
        className={`group block overflow-hidden rounded-2xl bg-card-gradient ring-1 ring-border transition hover:ring-primary/40 ${compact ? "w-72 shrink-0" : ""}`}
      >
        <div className="relative aspect-[4/3] overflow-hidden">
          <img
            src={r.image}
            alt={r.name}
            loading="lazy"
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/10 to-transparent" />
          {r.offer && (
            <div className="absolute bottom-3 left-3 rounded-lg bg-primary/95 px-2.5 py-1 text-xs font-bold text-primary-foreground shadow-lg">
              {r.offer}
            </div>
          )}
          {!r.isOpen && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/70 backdrop-blur-sm">
              <span className="rounded-lg bg-destructive/90 px-3 py-1 text-sm font-semibold">Closed</span>
            </div>
          )}
        </div>
        <div className="p-4">
          <div className="flex items-start justify-between gap-2">
            <h3 className="line-clamp-1 text-base font-semibold text-foreground">{r.name}</h3>
            <span className="flex shrink-0 items-center gap-1 rounded-md bg-rating/15 px-1.5 py-0.5 text-sm font-bold text-rating">
              <Star className="h-3.5 w-3.5 fill-rating" />
              {r.rating}
            </span>
          </div>
          <p className="mt-1 line-clamp-1 text-xs text-muted-foreground">{r.cuisines.join(" • ")}</p>
          <div className="mt-3 flex items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{r.deliveryTime} min</span>
            <span className="flex items-center gap-1"><Bike className="h-3.5 w-3.5" />{r.distance} km</span>
            <span>Min {formatCurrency(r.minOrder)}</span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
