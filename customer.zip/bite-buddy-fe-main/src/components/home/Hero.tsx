import { Search, MapPin } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";

const cycle = ["Biryani", "Pizza", "Sushi", "Tacos", "Burgers"];

export function Hero() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((p) => (p + 1) % cycle.length), 2200);
    return () => clearInterval(t);
  }, []);

  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 bg-hero-gradient opacity-90" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(0,201,177,0.35),transparent_40%),radial-gradient(circle_at_80%_60%,rgba(26,41,128,0.55),transparent_45%)]" />
      <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-primary/30 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-4 py-16 md:py-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
          className="max-w-2xl"
        >
          <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/15 px-3 py-1 text-xs font-medium text-primary ring-1 ring-primary/30">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary" />
            Free delivery on orders above ₹399
          </span>
          <h1 className="mt-4 text-4xl font-bold leading-tight text-foreground md:text-6xl">
            Craving{" "}
            <span className="relative inline-block min-w-[3ch] text-primary">
              <AnimatePresence mode="wait">
                <motion.span
                  key={cycle[i]}
                  initial={{ y: 30, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: -30, opacity: 0 }}
                  transition={{ duration: 0.35 }}
                  className="inline-block"
                >
                  {cycle[i]}
                </motion.span>
              </AnimatePresence>
            </span>
            ?<br /> We've got you in 25 min.
          </h1>
          <p className="mt-4 text-base text-muted-foreground md:text-lg">
            Discover 3,000+ restaurants delivering to your door — hot, fresh, and fast.
          </p>

          <div className="mt-8 flex flex-col gap-2 rounded-2xl bg-card/80 p-2 ring-1 ring-border backdrop-blur md:flex-row">
            <div className="flex items-center gap-2 rounded-xl bg-secondary/60 px-3.5 py-3 md:w-56">
              <MapPin className="h-4 w-4 text-primary" />
              <input
                defaultValue="HSR Layout, Bengaluru"
                className="w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
              />
            </div>
            <div className="flex flex-1 items-center gap-2 rounded-xl bg-secondary/60 px-3.5 py-3">
              <Search className="h-4 w-4 text-muted-foreground" />
              <input
                placeholder="Search for restaurants or dishes"
                className="w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
              />
            </div>
            <button className="rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-glow)] transition hover:bg-primary/90">
              Find Food
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
