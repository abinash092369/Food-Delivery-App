import { categories } from "@/lib/mock-data";
import { motion } from "framer-motion";

export function CategoryRow() {
  return (
    <section className="mx-auto max-w-7xl px-4">
      <div className="flex items-end justify-between">
        <h2 className="text-2xl font-semibold">What's on your mind?</h2>
      </div>
      <div className="scrollbar-hide mt-5 flex gap-3 overflow-x-auto pb-2">
        {categories.map((c, i) => (
          <motion.button
            key={c.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
            className="flex shrink-0 items-center gap-2 rounded-full border border-border bg-card px-5 py-3 text-sm font-medium text-foreground transition hover:border-primary/50 hover:bg-secondary"
          >
            <span className="text-xl">{c.emoji}</span>
            {c.name}
          </motion.button>
        ))}
      </div>
    </section>
  );
}
