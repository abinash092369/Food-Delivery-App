import { offers } from "@/lib/mock-data";
import { Copy, Check } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export function OffersBanner() {
  const [copied, setCopied] = useState<string | null>(null);
  const copy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(code);
    toast.success(`Copied ${code}`);
    setTimeout(() => setCopied(null), 1500);
  };
  return (
    <section className="mx-auto max-w-7xl px-4">
      <h2 className="text-2xl font-semibold">Offers For You</h2>
      <div className="mt-5 grid gap-4 md:grid-cols-3">
        {offers.map((o) => (
          <div key={o.id} className="relative overflow-hidden rounded-2xl bg-card-gradient p-5 ring-1 ring-border">
            <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-primary/20 blur-2xl" />
            <span className="rounded-md bg-primary/15 px-2 py-0.5 text-xs font-bold text-primary">{o.discount}</span>
            <h3 className="mt-3 text-lg font-semibold">{o.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{o.description}</p>
            <button
              onClick={() => copy(o.code)}
              className="mt-4 inline-flex items-center gap-2 rounded-lg border border-dashed border-primary/50 bg-primary/10 px-3 py-1.5 text-sm font-semibold text-primary transition hover:bg-primary/20"
            >
              {copied === o.code ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              {o.code}
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}
