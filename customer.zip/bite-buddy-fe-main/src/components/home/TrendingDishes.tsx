import { trendingDishes } from "@/lib/mock-data";
import { formatCurrency } from "@/lib/format";
import { motion } from "framer-motion";
import { Plus } from "lucide-react";
import { useCartStore } from "@/store/cart.store";
import { toast } from "sonner";

export function TrendingDishes() {
  const addItem = useCartStore((s) => s.addItem);

  return (
    <section className="mx-auto max-w-7xl px-4">
      <h2 className="text-2xl font-semibold">Trending Dishes</h2>
      <p className="mt-1 text-sm text-muted-foreground">What people are loving right now</p>
      <div className="mt-5 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {trendingDishes.map((d, i) => (
          <motion.div
            key={d.id}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.05 }}
            className="group overflow-hidden rounded-2xl bg-card ring-1 ring-border"
          >
            <div className="relative aspect-square overflow-hidden">
              <img src={d.image} alt={d.name} loading="lazy" className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
              <div className={`absolute left-2 top-2 flex h-4 w-4 items-center justify-center rounded-sm border-2 ${d.isVeg ? "border-veg" : "border-nonveg"}`}>
                <div className={`h-2 w-2 rounded-full ${d.isVeg ? "bg-veg" : "bg-nonveg"}`} />
              </div>
              {d.bestseller && (
                <span className="absolute right-2 top-2 rounded-md bg-rating/95 px-1.5 py-0.5 text-[10px] font-bold text-background">★ BESTSELLER</span>
              )}
            </div>
            <div className="p-3">
              <h3 className="line-clamp-1 text-sm font-semibold">{d.name}</h3>
              <p className="line-clamp-1 text-xs text-muted-foreground">{d.restaurantName}</p>
              <div className="mt-2 flex items-center justify-between">
                <span className="text-sm font-bold text-foreground">{formatCurrency(d.price)}</span>
                <button
                  onClick={() => {
                    const res = addItem(d, d.restaurantName ?? "");
                    if (res.ok) toast.success(`Added ${d.name}`);
                    else toast.error("Items from another restaurant in cart");
                  }}
                  className="inline-flex h-7 w-7 items-center justify-center rounded-lg bg-primary text-primary-foreground transition hover:scale-110"
                  aria-label={`Add ${d.name}`}
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
