import { restaurants } from "@/lib/mock-data";
import { RestaurantCard } from "@/components/restaurant/RestaurantCard";
import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";

export function FeaturedRestaurants() {
  return (
    <section className="mx-auto max-w-7xl px-4">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="text-2xl font-semibold">Featured Restaurants</h2>
          <p className="mt-1 text-sm text-muted-foreground">Hand-picked just for you</p>
        </div>
        <Link to="/restaurants" className="flex items-center gap-1 text-sm font-medium text-primary hover:underline">
          See all <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
      <div className="scrollbar-hide mt-5 flex gap-4 overflow-x-auto pb-4">
        {restaurants.map((r) => (
          <RestaurantCard key={r.id} restaurant={r} compact />
        ))}
      </div>
    </section>
  );
}
