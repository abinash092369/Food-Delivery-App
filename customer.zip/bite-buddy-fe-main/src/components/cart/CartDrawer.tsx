import { AnimatePresence, motion } from "framer-motion";
import { X, Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { useUIStore } from "@/store/ui.store";
import { useCartStore } from "@/store/cart.store";
import { formatCurrency } from "@/lib/format";
import { Link } from "@tanstack/react-router";

const DELIVERY_FEE = 39;
const GST_RATE = 0.05;

export function CartDrawer() {
  const open = useUIStore((s) => s.cartOpen);
  const setOpen = useUIStore((s) => s.setCartOpen);
  const { items, restaurantName, updateQty, removeItem, clear, subtotal } = useCartStore();
  const sub = subtotal();
  const taxes = Math.round(sub * GST_RATE);
  const total = sub + (sub > 0 ? DELIVERY_FEE + taxes : 0);

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={() => setOpen(false)}
            className="fixed inset-0 z-50 bg-background/70 backdrop-blur-sm"
          />
          <motion.aside
            initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 32 }}
            className="fixed inset-y-0 right-0 z-50 flex w-full max-w-md flex-col border-l border-border bg-card shadow-2xl"
          >
            <header className="flex items-center justify-between border-b border-border px-5 py-4">
              <div>
                <h2 className="text-lg font-semibold">Your Cart</h2>
                {restaurantName && <p className="text-xs text-muted-foreground">From {restaurantName}</p>}
              </div>
              <button onClick={() => setOpen(false)} className="rounded-lg p-2 hover:bg-secondary" aria-label="Close cart">
                <X className="h-5 w-5" />
              </button>
            </header>

            {items.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
                <div className="rounded-full bg-secondary p-6">
                  <ShoppingBag className="h-10 w-10 text-muted-foreground" />
                </div>
                <h3 className="mt-4 text-lg font-semibold">Your cart is empty</h3>
                <p className="mt-1 text-sm text-muted-foreground">Add delicious dishes to get started</p>
                <button
                  onClick={() => setOpen(false)}
                  className="mt-6 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground"
                >
                  Browse restaurants
                </button>
              </div>
            ) : (
              <>
                <div className="flex-1 space-y-3 overflow-y-auto p-5">
                  {items.map((it) => (
                    <div key={it.id} className="flex items-start gap-3 rounded-xl bg-secondary/40 p-3">
                      <div className={`mt-1 flex h-4 w-4 shrink-0 items-center justify-center rounded-sm border-2 ${it.isVeg ? "border-veg" : "border-nonveg"}`}>
                        <div className={`h-2 w-2 rounded-full ${it.isVeg ? "bg-veg" : "bg-nonveg"}`} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium">{it.name}</p>
                        <p className="mt-0.5 text-xs text-muted-foreground">{formatCurrency(it.price)}</p>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <div className="flex items-center gap-1 rounded-lg bg-card ring-1 ring-border">
                          <button onClick={() => updateQty(it.id, it.quantity - 1)} className="px-2 py-1 text-primary hover:bg-primary/10 rounded-l-lg" aria-label="Decrease">
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <span className="min-w-[1.5rem] text-center text-sm font-semibold">{it.quantity}</span>
                          <button onClick={() => updateQty(it.id, it.quantity + 1)} className="px-2 py-1 text-primary hover:bg-primary/10 rounded-r-lg" aria-label="Increase">
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </div>
                        <span className="text-sm font-bold">{formatCurrency(it.price * it.quantity)}</span>
                      </div>
                    </div>
                  ))}
                  <button onClick={clear} className="flex items-center gap-1.5 text-xs text-destructive hover:underline">
                    <Trash2 className="h-3.5 w-3.5" /> Clear cart
                  </button>
                </div>

                <div className="border-t border-border bg-card-elevated/40 p-5">
                  <div className="space-y-1.5 text-sm">
                    <Row label="Subtotal" value={formatCurrency(sub)} />
                    <Row label="Delivery fee" value={formatCurrency(DELIVERY_FEE)} />
                    <Row label="Taxes (5% GST)" value={formatCurrency(taxes)} />
                    <div className="my-2 border-t border-border" />
                    <Row label={<strong className="text-foreground">Total</strong>} value={<strong className="text-foreground">{formatCurrency(total)}</strong>} />
                  </div>
                  <Link
                    to="/checkout"
                    onClick={() => setOpen(false)}
                    className="mt-4 block w-full rounded-xl bg-primary py-3 text-center text-sm font-bold text-primary-foreground shadow-[var(--shadow-glow)] transition hover:bg-primary/90"
                  >
                    Proceed to Checkout
                  </Link>
                </div>
              </>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}

function Row({ label, value }: { label: React.ReactNode; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between text-muted-foreground">
      <span>{label}</span>
      <span>{value}</span>
    </div>
  );
}
