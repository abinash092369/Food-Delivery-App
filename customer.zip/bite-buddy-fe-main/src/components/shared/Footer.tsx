import { Logo } from "./Logo";

export function Footer() {
  return (
    <footer className="mt-20 border-t border-border/60 bg-card/40">
      <div className="mx-auto max-w-7xl px-4 py-12">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <Logo />
              <span className="text-xl font-bold">eets</span>
            </div>
            <p className="mt-3 text-sm text-muted-foreground">
              Crave it. Tap it. Eat it. Food delivery reimagined.
            </p>
          </div>
          {[
            { title: "Company", links: ["About", "Careers", "Press", "Blog"] },
            { title: "For You", links: ["Help", "Partner with us", "Ride with us", "Gift cards"] },
            { title: "Legal", links: ["Terms", "Privacy", "Refund Policy", "Contact"] },
          ].map((col) => (
            <div key={col.title}>
              <h4 className="text-sm font-semibold text-foreground">{col.title}</h4>
              <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
                {col.links.map((l) => (
                  <li key={l}><a className="hover:text-primary" href="#">{l}</a></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-10 border-t border-border/60 pt-6 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} eets. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
