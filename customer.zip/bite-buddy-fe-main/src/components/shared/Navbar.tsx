import { Link } from "@tanstack/react-router";
import { ShoppingBag, MapPin, Heart, User, Search } from "lucide-react";
import { Logo } from "./Logo";
import { useCartStore } from "@/store/cart.store";
import { useUIStore } from "@/store/ui.store";
import { motion } from "framer-motion";

export function Navbar() {
  const itemCount = useCartStore((s) => s.itemCount());
  const setCartOpen = useUIStore((s) => s.setCartOpen);

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 md:gap-6">
        <Link to="/" className="flex items-center gap-2.5">
          <Logo />
          <span className="hidden text-xl font-bold tracking-tight text-foreground sm:inline">eets</span>
        </Link>

        <button className="hidden items-center gap-1.5 rounded-lg px-2 py-1.5 text-sm text-muted-foreground hover:bg-secondary md:flex">
          <MapPin className="h-4 w-4 text-primary" />
          <span className="font-medium text-foreground">HSR Layout</span>
          <span className="text-xs">Bengaluru</span>
        </button>

        <Link
          to="/search"
          className="ml-auto hidden flex-1 max-w-md items-center gap-2 rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm text-muted-foreground transition hover:border-primary/40 md:flex"
        >
          <Search className="h-4 w-4" />
          Search restaurants & dishes
        </Link>

        <nav className="ml-auto flex items-center gap-1 md:ml-0">
          <Link to="/search" className="rounded-lg p-2 text-muted-foreground hover:bg-secondary hover:text-foreground md:hidden">
            <Search className="h-5 w-5" />
          </Link>
          <Link to="/favorites" className="rounded-lg p-2 text-muted-foreground hover:bg-secondary hover:text-foreground">
            <Heart className="h-5 w-5" />
          </Link>
          <Link to="/profile" className="rounded-lg p-2 text-muted-foreground hover:bg-secondary hover:text-foreground">
            <User className="h-5 w-5" />
          </Link>
          <button
            onClick={() => setCartOpen(true)}
            className="relative ml-1 inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-glow)] transition hover:bg-primary/90"
          >
            <ShoppingBag className="h-4 w-4" />
            <span className="hidden sm:inline">Cart</span>
            {itemCount > 0 && (
              <motion.span
                key={itemCount}
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-background px-1.5 text-xs font-bold text-primary"
              >
                {itemCount}
              </motion.span>
            )}
          </button>
        </nav>
      </div>
    </header>
  );
}
