import logoSrc from "@/assets/eets-logo.png";

export function Logo({ className = "h-9 w-9" }: { className?: string }) {
  return (
    <div className={`${className} overflow-hidden rounded-xl ring-1 ring-primary/30`}>
      <img src={logoSrc} alt="eets" className="h-full w-full object-cover" />
    </div>
  );
}
