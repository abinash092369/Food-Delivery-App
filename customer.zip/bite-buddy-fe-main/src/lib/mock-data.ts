import type { Restaurant, MenuCategory, Category, Offer, MenuItem } from "@/types";

export const categories: Category[] = [
  { id: "1", name: "Biryani", emoji: "🍛" },
  { id: "2", name: "Pizza", emoji: "🍕" },
  { id: "3", name: "Burger", emoji: "🍔" },
  { id: "4", name: "Sushi", emoji: "🍣" },
  { id: "5", name: "Tacos", emoji: "🌮" },
  { id: "6", name: "Desserts", emoji: "🍰" },
  { id: "7", name: "Healthy", emoji: "🥗" },
  { id: "8", name: "Coffee", emoji: "☕" },
  { id: "9", name: "Chinese", emoji: "🥡" },
  { id: "10", name: "Pasta", emoji: "🍝" },
];

const img = (q: string, seed: number) =>
  `https://images.unsplash.com/photo-${q}?auto=format&fit=crop&w=800&q=80&s=${seed}`;

export const restaurants: Restaurant[] = [
  {
    id: "r1", slug: "spice-orchid",
    name: "Spice Orchid",
    image: "https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=800&q=80",
    cuisines: ["North Indian", "Biryani", "Mughlai"],
    rating: 4.6, ratingCount: 2450, deliveryTime: 28, minOrder: 199, distance: 1.2,
    isOpen: true, priceLevel: 2, offer: "50% OFF up to ₹100",
  },
  {
    id: "r2", slug: "tokyo-bowl",
    name: "Tokyo Bowl",
    image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=800&q=80",
    cuisines: ["Japanese", "Sushi", "Asian"],
    rating: 4.8, ratingCount: 1820, deliveryTime: 35, minOrder: 299, distance: 2.4,
    isOpen: true, priceLevel: 3, offer: "Free delivery",
  },
  {
    id: "r3", slug: "napoli-pizzeria",
    name: "Napoli Pizzeria",
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80",
    cuisines: ["Italian", "Pizza", "Pasta"],
    rating: 4.5, ratingCount: 3120, deliveryTime: 25, minOrder: 249, distance: 0.8,
    isOpen: true, priceLevel: 2,
  },
  {
    id: "r4", slug: "green-leaf",
    name: "Green Leaf Kitchen",
    image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80",
    cuisines: ["Healthy", "Salads", "Bowls"],
    rating: 4.7, ratingCount: 980, deliveryTime: 22, minOrder: 199, distance: 1.5,
    isOpen: true, priceLevel: 2, offer: "20% OFF on first order",
  },
  {
    id: "r5", slug: "burger-bros",
    name: "Burger Bros",
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80",
    cuisines: ["American", "Burgers", "Fast Food"],
    rating: 4.3, ratingCount: 4200, deliveryTime: 20, minOrder: 149, distance: 0.6,
    isOpen: true, priceLevel: 1,
  },
  {
    id: "r6", slug: "dragon-wok",
    name: "Dragon Wok",
    image: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?auto=format&fit=crop&w=800&q=80",
    cuisines: ["Chinese", "Asian"],
    rating: 4.4, ratingCount: 1560, deliveryTime: 32, minOrder: 199, distance: 1.9,
    isOpen: false, priceLevel: 2,
  },
];

export const trendingDishes: MenuItem[] = [
  { id: "d1", name: "Chicken Hyderabadi Biryani", description: "Aromatic basmati rice with tender chicken", price: 349, isVeg: false, image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80", restaurantId: "r1", restaurantName: "Spice Orchid", rating: 4.7, bestseller: true },
  { id: "d2", name: "Truffle Mushroom Pizza", description: "Wood-fired with black truffle oil", price: 549, isVeg: true, image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=600&q=80", restaurantId: "r3", restaurantName: "Napoli Pizzeria", rating: 4.6 },
  { id: "d3", name: "Salmon Nigiri Set", description: "8 pieces of fresh salmon nigiri", price: 699, isVeg: false, image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=600&q=80", restaurantId: "r2", restaurantName: "Tokyo Bowl", rating: 4.9, bestseller: true },
  { id: "d4", name: "Quinoa Power Bowl", description: "Quinoa, avocado, kale, chickpea", price: 329, isVeg: true, image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=600&q=80", restaurantId: "r4", restaurantName: "Green Leaf Kitchen", rating: 4.5 },
  { id: "d5", name: "Smash Cheese Burger", description: "Double patty with cheddar & onions", price: 279, isVeg: false, image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80", restaurantId: "r5", restaurantName: "Burger Bros", rating: 4.4 },
  { id: "d6", name: "Dragon Noodles", description: "Spicy hand-pulled noodles", price: 259, isVeg: true, image: "https://images.unsplash.com/photo-1552611052-33e04de081de?auto=format&fit=crop&w=600&q=80", restaurantId: "r6", restaurantName: "Dragon Wok", rating: 4.3 },
];

export const offers: Offer[] = [
  { id: "o1", title: "Welcome Treat", description: "50% off on your first order", code: "EETS50", discount: "50% OFF" },
  { id: "o2", title: "Weekend Feast", description: "Free delivery on orders above ₹399", code: "FREEDEL", discount: "Free Delivery" },
  { id: "o3", title: "Lunch Hour", description: "Flat ₹100 off, 12-3 PM daily", code: "LUNCH100", discount: "₹100 OFF" },
];

export const restaurantMenus: Record<string, MenuCategory[]> = {
  "spice-orchid": [
    {
      id: "c1", name: "Biryani",
      items: [
        { id: "d1", name: "Chicken Hyderabadi Biryani", description: "Aromatic basmati rice with tender chicken, slow-cooked dum style", price: 349, isVeg: false, image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80", restaurantId: "r1", rating: 4.7, bestseller: true },
        { id: "d1b", name: "Veg Dum Biryani", description: "Fragrant rice with mixed vegetables and saffron", price: 269, isVeg: true, image: "https://images.unsplash.com/photo-1631515243349-e0cb75fb8d3a?auto=format&fit=crop&w=600&q=80", restaurantId: "r1", rating: 4.4 },
        { id: "d1c", name: "Mutton Biryani", description: "Tender mutton with long-grain basmati", price: 449, isVeg: false, image: "https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=600&q=80", restaurantId: "r1", rating: 4.8, bestseller: true },
      ],
    },
    {
      id: "c2", name: "Curries",
      items: [
        { id: "d1d", name: "Butter Chicken", description: "Creamy tomato gravy with tandoori chicken", price: 379, isVeg: false, image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=600&q=80", restaurantId: "r1", rating: 4.6 },
        { id: "d1e", name: "Paneer Tikka Masala", description: "Grilled paneer in spiced gravy", price: 319, isVeg: true, image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=600&q=80", restaurantId: "r1", rating: 4.5 },
      ],
    },
    {
      id: "c3", name: "Breads",
      items: [
        { id: "d1f", name: "Butter Naan", description: "Soft naan brushed with butter", price: 59, isVeg: true, restaurantId: "r1", rating: 4.3 },
        { id: "d1g", name: "Garlic Naan", description: "Naan topped with fresh garlic and cilantro", price: 79, isVeg: true, restaurantId: "r1", rating: 4.4 },
      ],
    },
  ],
};

// Fallback menu for any restaurant
export const defaultMenu: MenuCategory[] = restaurantMenus["spice-orchid"];

void img;
