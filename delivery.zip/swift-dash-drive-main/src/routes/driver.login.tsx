import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { Phone } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/driver/login")({
  head: () => ({ meta: [{ title: "Login — eets Partner" }] }),
  component: LoginScreen,
});

function LoginScreen() {
  const [step, setStep] = useState<"phone" | "otp">("phone");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const navigate = useNavigate();

  return (
    <div className="min-h-screen w-full flex justify-center bg-background">
      <div className="w-full max-w-[430px] min-h-screen px-6 pt-16 pb-8 flex flex-col safe-top safe-bottom">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary text-primary-foreground font-black text-2xl">
            ee
          </div>
          <h1 className="mt-5 text-3xl font-bold">eets Partner</h1>
          <p className="mt-1 text-muted-foreground text-sm">Earn on your own schedule</p>
        </div>

        <div className="mt-12 flex-1">
          {step === "phone" ? (
            <>
              <label className="text-sm font-semibold">Mobile Number</label>
              <div className="mt-2 flex items-center gap-2 bg-card rounded-2xl h-14 px-4 border border-border focus-within:border-primary">
                <Phone size={18} className="text-muted-foreground" />
                <span className="text-sm text-muted-foreground">+91</span>
                <input
                  inputMode="numeric"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))}
                  placeholder="98765 43210"
                  className="flex-1 bg-transparent outline-none text-base"
                />
              </div>
              <p className="mt-3 text-xs text-muted-foreground">We'll send you a 6-digit code to verify.</p>
            </>
          ) : (
            <>
              <label className="text-sm font-semibold">Enter OTP</label>
              <p className="text-xs text-muted-foreground">Sent to +91 {phone}</p>
              <input
                inputMode="numeric"
                maxLength={6}
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
                placeholder="• • • • • •"
                className="mt-3 w-full h-16 text-center text-2xl tracking-[0.6em] bg-card rounded-2xl border border-border focus:border-primary outline-none"
              />
              <p className="mt-2 text-xs text-muted-foreground">Hint (demo): any 6 digits</p>
            </>
          )}
        </div>

        <motion.button
          whileTap={{ scale: 0.97 }}
          disabled={step === "phone" ? phone.length !== 10 : otp.length !== 6}
          onClick={() => {
            if (step === "phone") {
              toast.success("OTP sent");
              setStep("otp");
            } else {
              toast.success("Welcome back!");
              navigate({ to: "/driver/home" });
            }
          }}
          className="w-full h-14 rounded-2xl bg-primary text-primary-foreground font-bold disabled:opacity-40"
        >
          {step === "phone" ? "Send OTP" : "Verify & Continue"}
        </motion.button>

        <p className="mt-4 text-center text-sm text-muted-foreground">
          New partner?{" "}
          <Link to="/driver/register" className="text-primary font-semibold">Register here</Link>
        </p>
      </div>
    </div>
  );
}
