import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronRight, Package, Star } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { useDriverStore } from "@/store/driver.store";
import { useState } from "react";

export const Route = createFileRoute("/driver/orders/")({
  head: () => ({ meta: [{ title: "Delivery History" }] }),
  component: OrdersScreen,
});

function OrdersScreen() {
  const { history } = useDriverStore();
  const [filter, setFilter] = useState<"all" | "delivered" | "cancelled">("all");
  const list = history.filter((d) => filter === "all" || d.status === filter);

  return (
    <AppShell>
      <div className="px-5 pt-10 safe-top">
        <h1 className="text-2xl font-bold">Delivery History</h1>
        <div className="mt-4 flex gap-2 bg-card p-1 rounded-2xl">
          {(["all", "delivered", "cancelled"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`flex-1 h-10 rounded-xl text-sm font-semibold capitalize transition-colors ${
                filter === f ? "bg-primary text-primary-foreground" : "text-muted-foreground"
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        <div className="mt-5 space-y-3">
          {list.map((d) => (
            <Link
              to="/driver/orders/$id"
              params={{ id: d.id }}
              key={d.id}
              className="block bg-card rounded-2xl p-4"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                  <Package size={18} className="text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{d.restaurant.name}</p>
                  <p className="text-xs text-muted-foreground truncate">→ {d.customer.name} · {d.distanceKm} km</p>
                </div>
                <ChevronRight size={16} className="text-muted-foreground" />
              </div>
              <div className="mt-3 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">{new Date(d.createdAt).toLocaleDateString()}</span>
                <div className="flex items-center gap-3">
                  {d.rating && (
                    <span className="flex items-center gap-1 text-[color:var(--pin-customer)]">
                      <Star size={12} fill="currentColor" /> {d.rating}
                    </span>
                  )}
                  <span className={`font-bold ${d.status === "delivered" ? "text-[color:var(--income)]" : "text-destructive"}`}>
                    {d.status === "delivered" ? `+₹${d.earning}` : "Cancelled"}
                  </span>
                </div>
              </div>
            </Link>
          ))}
          {list.length === 0 && (
            <div className="text-center text-muted-foreground py-12">No deliveries yet</div>
          )}
        </div>
      </div>
    </AppShell>
  );
}
