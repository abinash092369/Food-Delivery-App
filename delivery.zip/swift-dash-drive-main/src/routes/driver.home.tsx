import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Bell, ChevronRight, Star, Package, IndianRupee } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { useDriverStore, generateMockDelivery } from "@/store/driver.store";
import { toast } from "sonner";

export const Route = createFileRoute("/driver/home")({
  head: () => ({ meta: [{ title: "eets Partner — Home" }] }),
  component: HomeScreen,
});

function HomeScreen() {
  const { isOnline, setOnline, profile, setIncomingDelivery, history } = useDriverStore();
  const navigate = useNavigate();
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!isOnline) {
      if (timerRef.current) clearTimeout(timerRef.current);
      return;
    }
    // Simulate incoming delivery 8-15s after going online
    timerRef.current = setTimeout(() => {
      const delivery = generateMockDelivery();
      setIncomingDelivery(delivery);
      navigate({ to: "/driver/incoming" });
    }, 8000 + Math.random() * 7000);
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [isOnline, navigate, setIncomingDelivery]);

  const handleToggle = async () => {
    if (!isOnline) {
      if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(
          () => toast.success("You're online — listening for orders"),
          () => toast.success("You're online (location skipped)")
        );
      }
      setOnline(true);
    } else {
      setOnline(false);
      toast("You're offline");
    }
  };

  const todayEarnings = history.filter(h => h.status === "delivered").reduce((s, h) => s + h.earning, 0);
  const todayDeliveries = history.filter(h => h.status === "delivered").length;

  return (
    <AppShell>
      <div className="px-5 pt-8 safe-top">
        {/* Greeting */}
        <div className="flex items-center justify-between">
          <div>
            <p className="text-muted-foreground text-sm">Good morning,</p>
            <h1 className="text-2xl font-bold">{profile.name.split(" ")[0]} 👋</h1>
          </div>
          <div className="relative">
            <button className="w-11 h-11 rounded-full bg-card flex items-center justify-center">
              <Bell size={20} />
            </button>
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-destructive" />
          </div>
        </div>

        {/* Online Toggle */}
        <div className="mt-10 flex flex-col items-center">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleToggle}
            className="relative"
          >
            <AnimatePresence>
              {isOnline && (
                <motion.div
                  key="ring"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 rounded-full pulse-ring"
                />
              )}
            </AnimatePresence>
            <div
              className={`relative w-[140px] h-[140px] rounded-full flex items-center justify-center shadow-2xl transition-colors ${
                isOnline ? "bg-primary shadow-primary/40" : "bg-card border border-border"
              }`}
            >
              <div className="text-center">
                <div className={`text-xs uppercase tracking-widest font-bold ${isOnline ? "text-primary-foreground" : "text-muted-foreground"}`}>
                  {isOnline ? "Online" : "Offline"}
                </div>
                <div className={`mt-1 text-[10px] font-medium ${isOnline ? "text-primary-foreground/80" : "text-muted-foreground"}`}>
                  TAP TO {isOnline ? "STOP" : "START"}
                </div>
              </div>
            </div>
          </motion.button>
          <p className="mt-5 text-center text-sm text-muted-foreground max-w-[260px]">
            {isOnline ? "You're online — new orders will appear here" : "Go online to receive delivery requests"}
          </p>
        </div>

        {/* Today summary */}
        <div className="mt-8">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Today's Summary</h2>
          </div>
          <div className="flex gap-3 overflow-x-auto no-scrollbar -mx-5 px-5 snap-x">
            <SummaryCard icon={<Package size={18} />} label="Deliveries" value={todayDeliveries.toString()} />
            <SummaryCard icon={<IndianRupee size={18} />} label="Earnings" value={`₹${todayEarnings}`} accent />
            <SummaryCard icon={<Star size={18} />} label="Avg Rating" value={profile.rating.toFixed(1)} />
          </div>
        </div>

        {/* Recent deliveries */}
        <div className="mt-8">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Recent Deliveries</h2>
          <div className="space-y-2">
            {history.slice(0, 5).map((d) => (
              <div key={d.id} className="bg-card rounded-2xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                  <Package size={18} className="text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{d.restaurant.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{d.orderNumber} · {d.distanceKm} km</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-[color:var(--income)]">₹{d.earning}</p>
                  <p className="text-[10px] text-muted-foreground capitalize">{d.status}</p>
                </div>
                <ChevronRight size={16} className="text-muted-foreground" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function SummaryCard({ icon, label, value, accent }: { icon: React.ReactNode; label: string; value: string; accent?: boolean }) {
  return (
    <div className="snap-start min-w-[140px] bg-card rounded-2xl p-4 flex flex-col gap-2">
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${accent ? "bg-primary/15 text-primary" : "bg-secondary text-muted-foreground"}`}>
        {icon}
      </div>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className={`text-xl font-bold ${accent ? "text-[color:var(--income)]" : ""}`}>{value}</p>
      </div>
    </div>
  );
}
