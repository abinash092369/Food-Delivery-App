import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Star, ChevronRight, LogOut, FileCheck2, FileClock, FileX2, Bike } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { useDriverStore } from "@/store/driver.store";
import { toast } from "sonner";

export const Route = createFileRoute("/driver/profile")({
  head: () => ({ meta: [{ title: "Profile" }] }),
  component: ProfileScreen,
});

const ratingBreakdown = [
  { stars: 5, pct: 78 },
  { stars: 4, pct: 16 },
  { stars: 3, pct: 4 },
  { stars: 2, pct: 1 },
  { stars: 1, pct: 1 },
];

function ProfileScreen() {
  const { profile, setOnline } = useDriverStore();
  const navigate = useNavigate();

  return (
    <AppShell>
      <div className="px-5 pt-10 safe-top">
        {/* Header card */}
        <div className="bg-card rounded-2xl p-5 flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center text-primary text-2xl font-bold">
            {profile.name.split(" ").map(n => n[0]).join("")}
          </div>
          <div className="flex-1">
            <p className="font-bold text-lg">{profile.name}</p>
            <p className="text-xs text-muted-foreground">{profile.phone}</p>
            <p className="text-xs text-muted-foreground">{profile.email}</p>
          </div>
        </div>

        {/* Rating card */}
        <div className="mt-4 bg-card rounded-2xl p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs uppercase text-muted-foreground">Your Rating</p>
              <p className="text-3xl font-bold flex items-center gap-2">
                {profile.rating} <Star size={22} className="text-[color:var(--pin-customer)]" fill="currentColor" />
              </p>
              <p className="text-xs text-muted-foreground">{profile.totalDeliveries} deliveries</p>
            </div>
            <div className="flex-1 ml-6 space-y-1">
              {ratingBreakdown.map((r) => (
                <div key={r.stars} className="flex items-center gap-2 text-[10px]">
                  <span className="w-3 text-muted-foreground">{r.stars}</span>
                  <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full bg-primary" style={{ width: `${r.pct}%` }} />
                  </div>
                  <span className="w-7 text-right text-muted-foreground">{r.pct}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Vehicle */}
        <div className="mt-4 bg-card rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/15 text-primary flex items-center justify-center">
              <Bike size={18} />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Vehicle</p>
              <p className="font-semibold">{profile.vehicle.make} {profile.vehicle.model}</p>
              <p className="text-xs text-muted-foreground">{profile.vehicle.reg}</p>
            </div>
          </div>
        </div>

        {/* Documents */}
        <div className="mt-5">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Documents</h2>
          <div className="bg-card rounded-2xl divide-y divide-border">
            {profile.documents.map((doc) => {
              const Icon = doc.status === "verified" ? FileCheck2 : doc.status === "pending" ? FileClock : FileX2;
              const color = doc.status === "verified" ? "text-[color:var(--income)]" : doc.status === "pending" ? "text-[color:var(--pin-customer)]" : "text-destructive";
              return (
                <div key={doc.name} className="p-4 flex items-center gap-3">
                  <Icon size={18} className={color} />
                  <p className="flex-1 text-sm font-medium">{doc.name}</p>
                  <span className={`text-xs font-semibold capitalize ${color}`}>{doc.status}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Actions */}
        <div className="mt-5 space-y-2">
          <button className="w-full bg-card rounded-2xl p-4 flex items-center justify-between">
            <span className="font-semibold">Update Bank Details</span>
            <ChevronRight size={18} className="text-muted-foreground" />
          </button>
          <button
            onClick={() => { setOnline(false); toast("Logged out"); navigate({ to: "/driver/login" }); }}
            className="w-full bg-card rounded-2xl p-4 flex items-center justify-between text-destructive"
          >
            <span className="font-semibold flex items-center gap-2"><LogOut size={16} /> Logout</span>
          </button>
        </div>
      </div>
    </AppShell>
  );
}
