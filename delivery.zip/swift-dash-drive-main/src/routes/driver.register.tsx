import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { Check, Upload, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/driver/register")({
  head: () => ({ meta: [{ title: "Register — eets Partner" }] }),
  component: RegisterScreen,
});

const steps = ["Personal", "Vehicle", "Documents", "Bank", "Review"];

function RegisterScreen() {
  const [step, setStep] = useState(0);
  const navigate = useNavigate();

  return (
    <div className="min-h-screen w-full flex justify-center bg-background">
      <div className="w-full max-w-[430px] min-h-screen px-5 pt-10 pb-8 flex flex-col safe-top safe-bottom">
        <div className="flex items-center gap-3">
          <Link to="/driver/login" className="w-10 h-10 rounded-full bg-card flex items-center justify-center">
            <ArrowLeft size={18} />
          </Link>
          <div>
            <p className="text-xs text-muted-foreground">Step {step + 1} of {steps.length}</p>
            <h1 className="text-xl font-bold">{steps[step]} Details</h1>
          </div>
        </div>

        {/* Progress */}
        <div className="mt-5 flex gap-1.5">
          {steps.map((_, i) => (
            <div key={i} className={`flex-1 h-1.5 rounded-full ${i <= step ? "bg-primary" : "bg-secondary"}`} />
          ))}
        </div>

        <div className="mt-6 flex-1 space-y-3">
          {step === 0 && <>
            <Field label="Full Name" placeholder="Rahul Sharma" />
            <Field label="Phone" placeholder="+91 98765 12345" />
            <Field label="Email" placeholder="you@email.com" />
            <Field label="Date of Birth" placeholder="DD/MM/YYYY" />
          </>}
          {step === 1 && <>
            <Field label="Vehicle Type" placeholder="Bike / Scooter / Bicycle" />
            <Field label="Make" placeholder="Honda" />
            <Field label="Model" placeholder="Activa 6G" />
            <Field label="Registration Number" placeholder="KA-01-AB-1234" />
          </>}
          {step === 2 && <>
            {["Aadhaar Front", "Aadhaar Back", "Driving License", "Vehicle RC", "Profile Selfie"].map((d) => (
              <button key={d} className="w-full bg-card rounded-2xl p-4 flex items-center gap-3 border-2 border-dashed border-border">
                <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                  <Upload size={18} className="text-primary" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm font-semibold">{d}</p>
                  <p className="text-xs text-muted-foreground">Tap to upload photo</p>
                </div>
              </button>
            ))}
          </>}
          {step === 3 && <>
            <Field label="Account Number" placeholder="•••• •••• 1234" />
            <Field label="IFSC Code" placeholder="HDFC0001234" />
            <Field label="UPI ID" placeholder="rahul@upi" />
          </>}
          {step === 4 && (
            <div className="bg-card rounded-2xl p-5 text-center">
              <div className="w-16 h-16 mx-auto rounded-full bg-primary/15 flex items-center justify-center">
                <Check size={28} className="text-primary" />
              </div>
              <h2 className="mt-4 font-bold">Ready to submit</h2>
              <p className="mt-2 text-sm text-muted-foreground">Verification typically takes 24-48 hours. You'll be notified by SMS.</p>
            </div>
          )}
        </div>

        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => {
            if (step < steps.length - 1) setStep(step + 1);
            else {
              toast.success("Application submitted — under review");
              navigate({ to: "/driver/onboarding" });
            }
          }}
          className="w-full h-14 rounded-2xl bg-primary text-primary-foreground font-bold mt-4"
        >
          {step === steps.length - 1 ? "Submit Application" : "Continue"}
        </motion.button>
      </div>
    </div>
  );
}

function Field({ label, placeholder }: { label: string; placeholder: string }) {
  return (
    <div>
      <label className="text-xs uppercase text-muted-foreground tracking-wider">{label}</label>
      <input
        placeholder={placeholder}
        className="mt-1 w-full h-14 px-4 bg-card rounded-2xl border border-border focus:border-primary outline-none text-base"
      />
    </div>
  );
}
