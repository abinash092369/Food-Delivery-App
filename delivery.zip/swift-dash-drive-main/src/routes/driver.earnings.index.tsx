import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { AreaChart, Area, BarChart, Bar, XAxis, ResponsiveContainer, Tooltip } from "recharts";
import { TrendingUp, Gift, ChevronRight } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";

export const Route = createFileRoute("/driver/earnings/")({
  head: () => ({ meta: [{ title: "Earnings" }] }),
  component: EarningsScreen,
});

const data = [
  { day: "Mon", earn: 420, deliv: 7 },
  { day: "Tue", earn: 580, deliv: 9 },
  { day: "Wed", earn: 340, deliv: 5 },
  { day: "Thu", earn: 690, deliv: 11 },
  { day: "Fri", earn: 820, deliv: 13 },
  { day: "Sat", earn: 1120, deliv: 17 },
  { day: "Sun", earn: 940, deliv: 14 },
];

const incentives = [
  { tier: "5 deliveries", bonus: 50, status: "completed" },
  { tier: "10 deliveries", bonus: 150, status: "in_progress", progress: 7, of: 10 },
  { tier: "20 deliveries", bonus: 400, status: "locked" },
  { tier: "30 deliveries", bonus: 700, status: "locked" },
];

export function EarningsScreen() {
  const [range, setRange] = useState<"today" | "week" | "month">("week");
  const total = data.reduce((s, d) => s + d.earn, 0);
  const deliveries = data.reduce((s, d) => s + d.deliv, 0);

  return (
    <AppShell>
      <div className="px-5 pt-10 safe-top">
        <h1 className="text-2xl font-bold">Earnings</h1>

        <div className="mt-4 flex gap-2 bg-card p-1 rounded-2xl">
          {(["today", "week", "month"] as const).map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`flex-1 h-10 rounded-xl text-sm font-semibold capitalize ${
                range === r ? "bg-primary text-primary-foreground" : "text-muted-foreground"
              }`}
            >
              {r === "today" ? "Today" : r === "week" ? "This Week" : "This Month"}
            </button>
          ))}
        </div>

        <div className="mt-5 bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/30 rounded-2xl p-5">
          <p className="text-xs uppercase text-muted-foreground tracking-wider">Net Earnings</p>
          <p className="mt-1 text-4xl font-bold text-[color:var(--income)]">₹{total.toLocaleString()}</p>
          <div className="mt-4 grid grid-cols-3 gap-3 text-center">
            <KV label="Deliveries" value={deliveries.toString()} />
            <KV label="Gross" value={`₹${(total * 0.9).toFixed(0)}`} />
            <KV label="Incentives" value={`₹${(total * 0.1).toFixed(0)}`} />
          </div>
        </div>

        {/* Incentive progress */}
        <div className="mt-5 bg-card rounded-2xl p-5">
          <div className="flex items-center gap-2">
            <Gift size={18} className="text-primary" />
            <h2 className="font-bold">Daily Bonus</h2>
          </div>
          <p className="mt-2 text-sm">Complete <span className="text-primary font-bold">3 more</span> deliveries to earn <span className="text-[color:var(--income)] font-bold">₹150</span></p>
          <div className="mt-3 h-3 bg-secondary rounded-full overflow-hidden">
            <div className="h-full bg-primary rounded-full" style={{ width: "70%" }} />
          </div>
          <p className="mt-1 text-xs text-muted-foreground text-right">7 / 10</p>
        </div>

        {/* Area chart */}
        <div className="mt-5 bg-card rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp size={16} className="text-primary" />
            <h2 className="text-sm font-semibold">Daily Earnings</h2>
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <AreaChart data={data}>
              <defs>
                <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00C9B1" stopOpacity={0.6} />
                  <stop offset="100%" stopColor="#00C9B1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="day" stroke="#8FA3C4" fontSize={10} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ background: "#162847", border: "none", borderRadius: 12 }} />
              <Area type="monotone" dataKey="earn" stroke="#00C9B1" strokeWidth={2} fill="url(#g1)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Bar chart */}
        <div className="mt-4 bg-card rounded-2xl p-5">
          <h2 className="text-sm font-semibold mb-3">Deliveries per Day</h2>
          <ResponsiveContainer width="100%" height={120}>
            <BarChart data={data}>
              <XAxis dataKey="day" stroke="#8FA3C4" fontSize={10} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ background: "#162847", border: "none", borderRadius: 12 }} />
              <Bar dataKey="deliv" fill="#00C9B1" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Incentive tiers */}
        <div className="mt-5">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Incentive Tiers</h2>
          <div className="bg-card rounded-2xl divide-y divide-border">
            {incentives.map((t) => (
              <div key={t.tier} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-semibold text-sm">{t.tier}</p>
                  <p className="text-xs text-muted-foreground">Earn ₹{t.bonus} bonus</p>
                </div>
                <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                  t.status === "completed" ? "bg-[color:var(--income)]/15 text-[color:var(--income)]" :
                  t.status === "in_progress" ? "bg-primary/15 text-primary" :
                  "bg-secondary text-muted-foreground"
                }`}>
                  {t.status === "completed" ? "Done" : t.status === "in_progress" ? `${t.progress}/${t.of}` : "Locked"}
                </span>
              </div>
            ))}
          </div>
        </div>

        <Link to="/driver/earnings/history" className="mt-5 block bg-card rounded-2xl p-4 flex items-center justify-between">
          <span className="font-semibold">Payout History</span>
          <ChevronRight size={18} className="text-muted-foreground" />
        </Link>
      </div>
    </AppShell>
  );
}

function KV({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-[10px] uppercase text-muted-foreground">{label}</p>
      <p className="text-sm font-bold">{value}</p>
    </div>
  );
}
