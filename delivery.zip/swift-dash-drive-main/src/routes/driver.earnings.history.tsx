import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, CheckCircle2 } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";

export const Route = createFileRoute("/driver/earnings/history")({
  head: () => ({ meta: [{ title: "Payout History" }] }),
  component: PayoutHistory,
});

const payouts = [
  { id: "p1", date: "2026-05-30", amount: 4820, status: "Paid", method: "UPI" },
  { id: "p2", date: "2026-05-23", amount: 5610, status: "Paid", method: "UPI" },
  { id: "p3", date: "2026-05-16", amount: 4350, status: "Paid", method: "Bank Transfer" },
  { id: "p4", date: "2026-05-09", amount: 3980, status: "Paid", method: "UPI" },
];

function PayoutHistory() {
  const navigate = useNavigate();
  return (
    <AppShell>
      <div className="px-5 pt-10 safe-top">
        <button onClick={() => navigate({ to: "/driver/earnings" })} className="flex items-center gap-2 text-sm text-muted-foreground">
          <ArrowLeft size={16} /> Earnings
        </button>
        <h1 className="mt-3 text-2xl font-bold">Payout History</h1>

        <div className="mt-5 space-y-3">
          {payouts.map((p) => (
            <div key={p.id} className="bg-card rounded-2xl p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[color:var(--income)]/15 flex items-center justify-center">
                <CheckCircle2 size={18} className="text-[color:var(--income)]" />
              </div>
              <div className="flex-1">
                <p className="font-semibold">₹{p.amount.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">{p.date} · {p.method}</p>
              </div>
              <span className="text-xs font-bold text-[color:var(--income)]">{p.status}</span>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
