import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { MapPin, Store, Clock, Navigation2, IndianRupee } from "lucide-react";
import { useDriverStore } from "@/store/driver.store";
import { toast } from "sonner";

const TIMER_SEC = 30;

export const Route = createFileRoute("/driver/incoming")({
  head: () => ({ meta: [{ title: "New Delivery Request" }] }),
  component: IncomingScreen,
});

function IncomingScreen() {
  const navigate = useNavigate();
  const { incomingDelivery, setIncomingDelivery, setActiveDelivery } = useDriverStore();
  const [remaining, setRemaining] = useState(TIMER_SEC);

  useEffect(() => {
    if (!incomingDelivery) {
      navigate({ to: "/driver/home" });
      return;
    }
    // Audio chime (Howler optional — using WebAudio for zero-dep)
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.frequency.value = 880; g.gain.value = 0.15;
      o.start(); setTimeout(() => { o.frequency.value = 1320; }, 150);
      setTimeout(() => { o.stop(); ctx.close(); }, 400);
    } catch { /* ignore */ }
  }, [incomingDelivery, navigate]);

  useEffect(() => {
    if (!incomingDelivery) return;
    const t = setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          clearInterval(t);
          handleReject(true);
          return 0;
        }
        return r - 1;
      });
    }, 1000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [incomingDelivery]);

  if (!incomingDelivery) return null;
  const d = incomingDelivery;

  function handleAccept() {
    setActiveDelivery({ ...d, status: "assigned" });
    setIncomingDelivery(null);
    toast.success("Delivery accepted — heading to restaurant");
    navigate({ to: "/driver/active" });
  }

  function handleReject(auto = false) {
    setIncomingDelivery(null);
    if (auto) toast("Request expired");
    else toast("Delivery rejected");
    navigate({ to: "/driver/home" });
  }

  const pct = (remaining / TIMER_SEC) * 100;

  return (
    <div className="min-h-screen w-full flex justify-center bg-background">
      <div className="w-full max-w-[430px] min-h-screen bg-background px-5 pt-10 pb-8 flex flex-col safe-top safe-bottom">
        <div className="flex items-center gap-2">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
            <span className="relative inline-flex rounded-full h-3 w-3 bg-primary" />
          </span>
          <h1 className="text-xl font-bold">New Delivery Request!</h1>
        </div>

        {/* Countdown bar */}
        <div className="mt-5 h-2 rounded-full bg-secondary overflow-hidden">
          <motion.div
            className="h-full"
            style={{
              width: `${pct}%`,
              background: pct > 50 ? "var(--primary)" : pct > 25 ? "#FAC775" : "var(--destructive)",
            }}
            transition={{ ease: "linear" }}
          />
        </div>
        <p className="mt-1 text-xs text-muted-foreground text-right">{remaining}s to respond</p>

        {/* Delivery card */}
        <div className="mt-5 bg-card rounded-2xl p-5 space-y-4">
          <div className="flex gap-3">
            <div className="w-10 h-10 rounded-xl bg-[color:var(--pin-restaurant)]/15 flex items-center justify-center shrink-0">
              <Store size={18} className="text-[color:var(--pin-restaurant)]" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wider">Pickup</p>
              <p className="font-semibold">{d.restaurant.name}</p>
              <p className="text-sm text-muted-foreground">{d.restaurant.address}</p>
            </div>
          </div>

          <div className="border-t border-dashed border-border" />

          <div className="flex gap-3">
            <div className="w-10 h-10 rounded-xl bg-[color:var(--pin-customer)]/15 flex items-center justify-center shrink-0">
              <MapPin size={18} className="text-[color:var(--pin-customer)]" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wider">Drop</p>
              <p className="font-semibold">{d.customer.name}</p>
              <p className="text-sm text-muted-foreground">{d.customer.address}</p>
            </div>
          </div>

          <div className="border-t border-dashed border-border" />

          <div className="grid grid-cols-3 gap-3 pt-1">
            <Stat icon={<Navigation2 size={14} />} label="Distance" value={`${d.distanceKm} km`} />
            <Stat icon={<Clock size={14} />} label="Est. Time" value={`${d.etaMin} min`} />
            <Stat icon={<IndianRupee size={14} />} label="Earning" value={`₹${d.earning}`} highlight />
          </div>
        </div>

        <div className="flex-1" />

        <div className="space-y-3 mt-6">
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={handleAccept}
            className="w-full h-14 rounded-2xl bg-primary text-primary-foreground font-bold text-base shadow-lg shadow-primary/30"
          >
            Accept Delivery
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => handleReject(false)}
            className="w-full h-14 rounded-2xl bg-transparent border border-border text-foreground font-semibold"
          >
            Reject
          </motion.button>
        </div>
      </div>
    </div>
  );
}

function Stat({ icon, label, value, highlight }: { icon: React.ReactNode; label: string; value: string; highlight?: boolean }) {
  return (
    <div className="bg-secondary/60 rounded-xl px-2 py-2 text-center">
      <div className="flex items-center justify-center gap-1 text-muted-foreground text-[10px] uppercase">{icon}{label}</div>
      <p className={`mt-1 text-sm font-bold ${highlight ? "text-[color:var(--income)]" : ""}`}>{value}</p>
    </div>
  );
}
