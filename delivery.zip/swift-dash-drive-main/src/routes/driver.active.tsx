import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Phone, ExternalLink, Store, MapPin, Navigation2 } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { useDriverStore } from "@/store/driver.store";
import { toast } from "sonner";

export const Route = createFileRoute("/driver/active")({
  head: () => ({ meta: [{ title: "Active Delivery" }] }),
  component: ActiveScreen,
});

function ActiveScreen() {
  const navigate = useNavigate();
  const { activeDelivery, setActiveDelivery, location, setLocation, history } = useDriverStore();
  const [phase, setPhase] = useState<"pickup" | "drop">("pickup");
  const [otpInput, setOtpInput] = useState("");

  // Sync phase with delivery status
  useEffect(() => {
    if (activeDelivery?.status === "picked_up") setPhase("drop");
  }, [activeDelivery?.status]);

  // Simulate live location updates every 5s
  useEffect(() => {
    if (!activeDelivery) return;
    const i = setInterval(() => {
      setLocation({
        lat: location.lat + (Math.random() - 0.5) * 0.001,
        lng: location.lng + (Math.random() - 0.5) * 0.001,
      });
      // eslint-disable-next-line no-console
      console.log("[socket] driver_location emit", { driverId: "drv_001", lat: location.lat, lng: location.lng });
    }, 5000);
    return () => clearInterval(i);
  }, [activeDelivery, location, setLocation]);

  if (!activeDelivery) {
    return (
      <AppShell>
        <div className="px-5 pt-10 text-center">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-card flex items-center justify-center">
            <Navigation2 size={28} className="text-muted-foreground" />
          </div>
          <h1 className="mt-5 text-xl font-bold">No active delivery</h1>
          <p className="mt-2 text-sm text-muted-foreground">Go online from Home to start receiving orders.</p>
          <button onClick={() => navigate({ to: "/driver/home" })} className="mt-6 h-12 px-6 rounded-2xl bg-primary text-primary-foreground font-semibold">
            Back to Home
          </button>
        </div>
      </AppShell>
    );
  }

  const d = activeDelivery;

  function handlePickedUp() {
    setActiveDelivery({ ...d, status: "picked_up" });
    setPhase("drop");
    toast.success("Pickup confirmed — head to customer");
  }

  function handleConfirmDelivery() {
    if (otpInput !== d.dropOtp) {
      toast.error("Invalid OTP — ask customer for the correct code");
      return;
    }
    const delivered = { ...d, status: "delivered" as const };
    useDriverStore.setState({
      activeDelivery: null,
      history: [delivered, ...history],
    });
    toast.success(`Delivered! +₹${d.earning} added to earnings`);
    navigate({ to: "/driver/home" });
  }

  const target = phase === "pickup" ? d.restaurant : d.customer;
  const gmaps = `https://www.google.com/maps/dir/?api=1&destination=${target.lat},${target.lng}`;

  return (
    <div className="min-h-screen w-full flex justify-center bg-background">
      <div className="relative w-full max-w-[430px] min-h-screen bg-background overflow-hidden">
        {/* Fake map */}
        <FakeMap phase={phase} />

        {/* ETA overlay */}
        <div className="absolute top-12 right-4 bg-card/95 backdrop-blur rounded-2xl px-4 py-2 shadow-lg">
          <p className="text-[10px] text-muted-foreground uppercase">ETA</p>
          <p className="text-sm font-bold">{d.etaMin} min</p>
        </div>
        <button
          onClick={() => navigate({ to: "/driver/home" })}
          className="absolute top-12 left-4 w-10 h-10 rounded-full bg-card/95 backdrop-blur flex items-center justify-center"
        >
          ←
        </button>

        {/* Bottom sheet */}
        <motion.div
          drag="y"
          dragConstraints={{ top: 0, bottom: 200 }}
          dragElastic={0.2}
          initial={{ y: 0 }}
          className="absolute bottom-0 left-0 right-0 bg-card rounded-t-3xl px-5 pt-3 pb-6 safe-bottom shadow-2xl"
        >
          <div className="mx-auto w-12 h-1.5 rounded-full bg-muted-foreground/30 mb-4" />

          {phase === "pickup" ? (
            <>
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Store size={20} className="text-[color:var(--pin-restaurant)]" />
                Go to Restaurant
              </h2>
              <div className="mt-3 bg-secondary/60 rounded-2xl p-4">
                <p className="font-semibold">{d.restaurant.name}</p>
                <p className="text-sm text-muted-foreground">{d.restaurant.address}</p>
                <p className="mt-2 text-xs text-muted-foreground">Order {d.orderNumber}</p>
                <p className="text-xs">{d.items.length} items — {d.items.join(", ")}</p>
                <div className="mt-3 bg-background/60 rounded-xl p-3 flex items-center justify-between">
                  <div>
                    <p className="text-[10px] uppercase text-muted-foreground">Pickup OTP</p>
                    <p className="text-2xl font-bold tracking-[0.5em] text-primary">{d.pickupOtp}</p>
                  </div>
                  <Store size={28} className="text-[color:var(--pin-restaurant)]" />
                </div>
              </div>
              <a href={gmaps} target="_blank" rel="noreferrer" className="mt-3 flex items-center justify-center gap-2 text-sm text-primary py-2">
                <ExternalLink size={14} /> Open in Google Maps
              </a>
              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={handlePickedUp}
                className="mt-2 w-full h-14 rounded-2xl bg-primary text-primary-foreground font-bold text-base"
              >
                I've Picked Up the Order
              </motion.button>
            </>
          ) : (
            <>
              <h2 className="text-xl font-bold flex items-center gap-2">
                <MapPin size={20} className="text-[color:var(--pin-customer)]" />
                Deliver to Customer
              </h2>
              <div className="mt-3 bg-secondary/60 rounded-2xl p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-semibold">{d.customer.name}</p>
                    <p className="text-sm text-muted-foreground">{d.customer.address}</p>
                  </div>
                  <a href={`tel:${d.customer.phone}`} className="w-10 h-10 rounded-xl bg-primary/15 text-primary flex items-center justify-center">
                    <Phone size={16} />
                  </a>
                </div>
                <div className="mt-3">
                  <p className="text-[10px] uppercase text-muted-foreground mb-1">Enter delivery OTP from customer</p>
                  <input
                    inputMode="numeric"
                    maxLength={4}
                    value={otpInput}
                    onChange={(e) => setOtpInput(e.target.value.replace(/\D/g, ""))}
                    placeholder="• • • •"
                    className="w-full h-14 text-center text-2xl tracking-[0.5em] bg-background rounded-xl border border-border focus:border-primary outline-none"
                  />
                  <p className="text-[10px] text-muted-foreground mt-1">Hint (demo): {d.dropOtp}</p>
                </div>
              </div>
              <a href={gmaps} target="_blank" rel="noreferrer" className="mt-3 flex items-center justify-center gap-2 text-sm text-primary py-2">
                <ExternalLink size={14} /> Open in Google Maps
              </a>
              <motion.button
                whileTap={{ scale: 0.97 }}
                disabled={otpInput.length !== 4}
                onClick={handleConfirmDelivery}
                className="mt-2 w-full h-14 rounded-2xl bg-primary text-primary-foreground font-bold text-base disabled:opacity-40"
              >
                Confirm Delivery
              </motion.button>
            </>
          )}
        </motion.div>
      </div>
    </div>
  );
}

function FakeMap({ phase }: { phase: "pickup" | "drop" }) {
  return (
    <div className="absolute inset-0">
      {/* Stylized grid map */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(circle at 50% 40%, #1a2f55 0%, #0F1F3D 60%, #06122A 100%)",
        }}
      />
      <svg className="absolute inset-0 w-full h-full opacity-30" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="grid" width="32" height="32" patternUnits="userSpaceOnUse">
            <path d="M 32 0 L 0 0 0 32" fill="none" stroke="#2a4878" strokeWidth="0.5" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
      </svg>
      {/* Route polyline */}
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 430 800" preserveAspectRatio="none">
        <path
          d="M 80 600 Q 200 450 180 300 T 320 120"
          stroke="var(--primary)"
          strokeWidth="4"
          fill="none"
          strokeLinecap="round"
          strokeDasharray="2 8"
        />
      </svg>
      {/* Pins */}
      <Pin x="18%" y="74%" color="var(--pin-driver)" label="You" pulse />
      {phase === "pickup" ? (
        <Pin x="75%" y="15%" color="var(--pin-restaurant)" label="Pickup" />
      ) : (
        <Pin x="75%" y="15%" color="var(--pin-customer)" label="Drop" />
      )}
    </div>
  );
}

function Pin({ x, y, color, label, pulse }: { x: string; y: string; color: string; label: string; pulse?: boolean }) {
  return (
    <div className="absolute -translate-x-1/2 -translate-y-full" style={{ left: x, top: y }}>
      <div className="relative flex flex-col items-center">
        {pulse && (
          <span className="absolute top-2 w-8 h-8 rounded-full animate-ping" style={{ background: color, opacity: 0.4 }} />
        )}
        <div className="w-8 h-8 rounded-full border-4 border-white shadow-lg" style={{ background: color }} />
        <div className="w-1 h-3" style={{ background: color }} />
        <span className="mt-1 px-2 py-0.5 rounded-full bg-card text-[10px] font-semibold">{label}</span>
      </div>
    </div>
  );
}
