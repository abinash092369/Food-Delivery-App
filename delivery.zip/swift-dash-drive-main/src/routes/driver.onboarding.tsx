import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock4 } from "lucide-react";

export const Route = createFileRoute("/driver/onboarding")({
  head: () => ({ meta: [{ title: "Under Review" }] }),
  component: Onboarding,
});

function Onboarding() {
  return (
    <div className="min-h-screen w-full flex justify-center bg-background">
      <div className="w-full max-w-[430px] min-h-screen px-6 pt-20 pb-8 flex flex-col items-center text-center safe-top safe-bottom">
        <div className="w-24 h-24 rounded-3xl bg-primary/15 flex items-center justify-center">
          <Clock4 size={42} className="text-primary" />
        </div>
        <h1 className="mt-6 text-2xl font-bold">Application Under Review</h1>
        <p className="mt-3 text-muted-foreground max-w-[300px]">
          We're verifying your documents. This usually takes <span className="text-primary font-semibold">24–48 hours</span>. We'll notify you on SMS once you're approved to start earning.
        </p>

        <div className="mt-10 w-full bg-card rounded-2xl p-5 space-y-3 text-left">
          <Row label="Personal Details" status="done" />
          <Row label="Vehicle Info" status="done" />
          <Row label="Document Verification" status="pending" />
          <Row label="Background Check" status="pending" />
        </div>

        <Link to="/driver/login" className="mt-auto w-full h-14 rounded-2xl bg-primary text-primary-foreground font-bold flex items-center justify-center">
          Back to Login
        </Link>
      </div>
    </div>
  );
}

function Row({ label, status }: { label: string; status: "done" | "pending" }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm">{label}</span>
      <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
        status === "done" ? "bg-[color:var(--income)]/15 text-[color:var(--income)]" : "bg-[color:var(--pin-customer)]/15 text-[color:var(--pin-customer)]"
      }`}>
        {status === "done" ? "Completed" : "In Progress"}
      </span>
    </div>
  );
}
