import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, MapPin, Store, Clock, Navigation2, IndianRupee, Star } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { useDriverStore } from "@/store/driver.store";

export const Route = createFileRoute("/driver/orders/$id")({
  head: () => ({ meta: [{ title: "Delivery Detail" }] }),
  component: OrderDetail,
});

function OrderDetail() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { history } = useDriverStore();
  const d = history.find((x) => x.id === id);

  if (!d) {
    return (
      <AppShell>
        <div className="px-5 pt-10">
          <p>Delivery not found.</p>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="px-5 pt-10 safe-top">
        <button onClick={() => navigate({ to: "/driver/orders" })} className="flex items-center gap-2 text-sm text-muted-foreground">
          <ArrowLeft size={16} /> Back
        </button>
        <h1 className="mt-3 text-xl font-bold">{d.orderNumber}</h1>
        <p className="text-sm text-muted-foreground">{new Date(d.createdAt).toLocaleString()}</p>

        <div className="mt-5 bg-card rounded-2xl p-5 space-y-4">
          <Row icon={<Store size={18} className="text-[color:var(--pin-restaurant)]" />} title="Pickup" name={d.restaurant.name} addr={d.restaurant.address} />
          <div className="border-t border-dashed border-border" />
          <Row icon={<MapPin size={18} className="text-[color:var(--pin-customer)]" />} title="Drop" name={d.customer.name} addr={d.customer.address} />
        </div>

        <div className="mt-4 grid grid-cols-3 gap-3">
          <Stat icon={<Navigation2 size={14} />} label="Distance" value={`${d.distanceKm} km`} />
          <Stat icon={<Clock size={14} />} label="Duration" value={`${d.etaMin} min`} />
          <Stat icon={<IndianRupee size={14} />} label="Earned" value={`₹${d.earning}`} highlight />
        </div>

        {d.rating && (
          <div className="mt-4 bg-card rounded-2xl p-4 flex items-center justify-between">
            <p className="text-sm">Customer rating</p>
            <span className="flex items-center gap-1 text-[color:var(--pin-customer)] font-bold">
              <Star size={16} fill="currentColor" /> {d.rating}.0
            </span>
          </div>
        )}

        <div className="mt-4 bg-card rounded-2xl p-4">
          <p className="text-xs uppercase text-muted-foreground mb-2">Items</p>
          {d.items.map((it) => (
            <p key={it} className="text-sm">• {it}</p>
          ))}
        </div>
      </div>
    </AppShell>
  );
}

function Row({ icon, title, name, addr }: { icon: React.ReactNode; title: string; name: string; addr: string }) {
  return (
    <div className="flex gap-3">
      <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center shrink-0">{icon}</div>
      <div>
        <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{title}</p>
        <p className="font-semibold">{name}</p>
        <p className="text-sm text-muted-foreground">{addr}</p>
      </div>
    </div>
  );
}

function Stat({ icon, label, value, highlight }: { icon: React.ReactNode; label: string; value: string; highlight?: boolean }) {
  return (
    <div className="bg-card rounded-2xl px-2 py-3 text-center">
      <div className="flex items-center justify-center gap-1 text-muted-foreground text-[10px] uppercase">{icon}{label}</div>
      <p className={`mt-1 text-sm font-bold ${highlight ? "text-[color:var(--income)]" : ""}`}>{value}</p>
    </div>
  );
}
