import type { ReactNode } from "react";
import { BottomNav } from "./BottomNav";

export function AppShell({ children, hideNav = false }: { children: ReactNode; hideNav?: boolean }) {
  return (
    <div className="min-h-screen w-full flex justify-center bg-[#06122A]">
      <div className="relative w-full max-w-[430px] min-h-screen bg-background overflow-x-hidden">
        <div className={hideNav ? "" : "pb-28"}>{children}</div>
        {!hideNav && <BottomNav />}
      </div>
    </div>
  );
}
