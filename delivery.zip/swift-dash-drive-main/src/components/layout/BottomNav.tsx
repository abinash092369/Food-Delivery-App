import { Link, useRouterState } from "@tanstack/react-router";
import { Home, ListOrdered, Map, Wallet, User } from "lucide-react";

const items = [
  { to: "/driver/home", label: "Home", icon: Home },
  { to: "/driver/orders", label: "Orders", icon: ListOrdered },
  { to: "/driver/active", label: "Map", icon: Map },
  { to: "/driver/earnings", label: "Earnings", icon: Wallet },
  { to: "/driver/profile", label: "Profile", icon: User },
] as const;

export function BottomNav() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] bg-card/95 backdrop-blur-xl border-t border-border safe-bottom z-40">
      <ul className="flex items-stretch justify-between px-2 pt-2">
        {items.map((it) => {
          const active = path.startsWith(it.to);
          const Icon = it.icon;
          return (
            <li key={it.to} className="flex-1">
              <Link
                to={it.to}
                className={`flex flex-col items-center gap-1 py-2 min-h-[56px] rounded-xl transition-colors ${
                  active ? "text-primary" : "text-muted-foreground"
                }`}
              >
                <Icon size={22} strokeWidth={active ? 2.5 : 2} />
                <span className="text-[11px] font-medium">{it.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
