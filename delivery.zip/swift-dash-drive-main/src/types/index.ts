export type DeliveryStatus = "assigned" | "picked_up" | "delivered" | "cancelled";

export interface Delivery {
  id: string;
  orderNumber: string;
  restaurant: { name: string; address: string; lat: number; lng: number };
  customer: { name: string; address: string; phone: string; lat: number; lng: number };
  items: string[];
  pickupOtp: string;
  dropOtp: string;
  distanceKm: number;
  etaMin: number;
  earning: number;
  status: DeliveryStatus;
  createdAt: string;
  rating?: number;
}

export interface DriverProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  avatarUrl?: string;
  rating: number;
  totalDeliveries: number;
  vehicle: { type: string; make: string; model: string; reg: string };
  documents: { name: string; status: "verified" | "pending" | "rejected" }[];
}
