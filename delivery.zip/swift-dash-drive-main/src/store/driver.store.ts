import { create } from "zustand";
import type { Delivery, DriverProfile } from "@/types";

interface DriverState {
  isOnline: boolean;
  setOnline: (v: boolean) => void;
  profile: DriverProfile;
  activeDelivery: Delivery | null;
  setActiveDelivery: (d: Delivery | null) => void;
  incomingDelivery: Delivery | null;
  setIncomingDelivery: (d: Delivery | null) => void;
  location: { lat: number; lng: number };
  setLocation: (l: { lat: number; lng: number }) => void;
  history: Delivery[];
}

const sampleHistory: Delivery[] = [
  {
    id: "d_101", orderNumber: "EETS-9821",
    restaurant: { name: "Burger Junction", address: "MG Road, Bangalore", lat: 12.9716, lng: 77.5946 },
    customer: { name: "Priya S.", address: "HSR Layout Sector 2", phone: "+91 90000 12345", lat: 12.9081, lng: 77.6476 },
    items: ["Cheese Burger", "Fries"], pickupOtp: "4821", dropOtp: "7263",
    distanceKm: 4.1, etaMin: 22, earning: 78, status: "delivered",
    createdAt: new Date(Date.now() - 86400000).toISOString(), rating: 5,
  },
  {
    id: "d_100", orderNumber: "EETS-9799",
    restaurant: { name: "Pizza Palace", address: "Indiranagar 100ft Rd", lat: 12.9719, lng: 77.6412 },
    customer: { name: "Arjun K.", address: "Koramangala 5th Block", phone: "+91 98765 43210", lat: 12.9352, lng: 77.6245 },
    items: ["Margherita", "Garlic Bread"], pickupOtp: "1122", dropOtp: "3344",
    distanceKm: 3.2, etaMin: 18, earning: 65, status: "delivered",
    createdAt: new Date(Date.now() - 172800000).toISOString(), rating: 4,
  },
  {
    id: "d_099", orderNumber: "EETS-9745",
    restaurant: { name: "Sushi Bar", address: "UB City", lat: 12.9719, lng: 77.5937 },
    customer: { name: "Neha R.", address: "Richmond Town", phone: "+91 99999 88888", lat: 12.9606, lng: 77.6017 },
    items: ["Sushi Platter"], pickupOtp: "5511", dropOtp: "9988",
    distanceKm: 2.4, etaMin: 14, earning: 55, status: "cancelled",
    createdAt: new Date(Date.now() - 259200000).toISOString(),
  },
];

export const useDriverStore = create<DriverState>((set) => ({
  isOnline: false,
  setOnline: (v) => set({ isOnline: v }),
  profile: {
    id: "drv_001",
    name: "Rahul Sharma",
    phone: "+91 98765 12345",
    email: "rahul.s@eets.app",
    rating: 4.8,
    totalDeliveries: 1248,
    vehicle: { type: "Bike", make: "Honda", model: "Activa 6G", reg: "KA-01-AB-1234" },
    documents: [
      { name: "Aadhaar Card", status: "verified" },
      { name: "Driving License", status: "verified" },
      { name: "Vehicle RC", status: "verified" },
      { name: "Profile Photo", status: "pending" },
    ],
  },
  activeDelivery: null,
  setActiveDelivery: (d) => set({ activeDelivery: d }),
  incomingDelivery: null,
  setIncomingDelivery: (d) => set({ incomingDelivery: d }),
  location: { lat: 12.9716, lng: 77.5946 },
  setLocation: (l) => set({ location: l }),
  history: sampleHistory,
}));

let counter = 200;
export function generateMockDelivery(): Delivery {
  counter++;
  const restaurants = [
    { name: "Spice Route", address: "Brigade Road, Bangalore", lat: 12.9716, lng: 77.6063 },
    { name: "Taco Town", address: "Church Street", lat: 12.9756, lng: 77.6066 },
    { name: "Noodle House", address: "Commercial Street", lat: 12.9831, lng: 77.6094 },
  ];
  const customers = [
    { name: "Vikram M.", address: "Whitefield, ITPL Main Rd", phone: "+91 90011 22334", lat: 12.9698, lng: 77.7500 },
    { name: "Sneha P.", address: "JP Nagar 4th Phase", phone: "+91 98223 44556", lat: 12.9078, lng: 77.5852 },
  ];
  const r = restaurants[Math.floor(Math.random() * restaurants.length)];
  const c = customers[Math.floor(Math.random() * customers.length)];
  return {
    id: `d_${counter}`,
    orderNumber: `EETS-${9900 + counter}`,
    restaurant: r,
    customer: c,
    items: ["Special Combo", "Soft Drink"],
    pickupOtp: String(Math.floor(1000 + Math.random() * 9000)),
    dropOtp: String(Math.floor(1000 + Math.random() * 9000)),
    distanceKm: +(2 + Math.random() * 5).toFixed(1),
    etaMin: Math.floor(15 + Math.random() * 20),
    earning: Math.floor(55 + Math.random() * 80),
    status: "assigned",
    createdAt: new Date().toISOString(),
  };
}
